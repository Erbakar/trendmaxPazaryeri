<?php
/**
 * OzyConnect Panel — BrandMappingController
 * Marka ↔ pazaryeri markası eşleştirme yönetimi
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    1.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Container;
use App\Core\Request;
use App\Models\BrandMarketplaceMapping;
use App\Models\Marketplace;
use App\Services\BrandMappingService;

final class BrandMappingController extends BaseController
{
    private readonly BrandMappingService $brandMappingService;
    private readonly BrandMarketplaceMapping $mappingModel;
    private readonly Marketplace $marketplaceModel;

    public function __construct(Container $container)
    {
        parent::__construct($container);
        $this->brandMappingService = $container->get(BrandMappingService::class);
        $this->mappingModel        = $container->get(BrandMarketplaceMapping::class);
        $this->marketplaceModel    = $container->get(Marketplace::class);
    }

    /**
     * Eşleştirme listesi
     */
    public function index(Request $request): void
    {
        $marketplaces = $this->marketplaceModel->getActive();
        $marketplaceId = $request->integer('marketplace_id', 0);

        if ($marketplaceId === 0 && !empty($marketplaces)) {
            $marketplaceId = (int) $marketplaces[0]['id'];
        }

        $brands = [];
        $unmappedCount = 0;

        if ($marketplaceId > 0) {
            $brands = $this->brandMappingService->getBrandsWithMappingStatus($marketplaceId);
            $unmappedCount = $this->brandMappingService->getUnmappedProductCount($marketplaceId);
        }

        // Güven skoru DB'de tutulmaz; satır çizilirken hesaplanır.
        $finder = $this->container->get(\App\Services\Mapping\MappingCandidateFinder::class);

        foreach ($brands as $i => $b) {
            $brands[$i]['confidence'] = empty($b['mapping_id'])
                ? null
                : $finder->scoreBrand(
                    (string) ($b['name'] ?? ''),
                    (string) ($b['marketplace_brand_name'] ?? '')
                );
        }

        $catalogSize = $marketplaceId > 0
            ? $this->container->get(\App\Models\MarketplaceBrand::class)->countByMarketplace($marketplaceId)
            : 0;

        $this->view('brands.mapping', [
            'pageTitle'      => 'Marka Eşleştirme',
            'marketplaces'   => $marketplaces,
            'marketplaceId'  => $marketplaceId,
            'brands'         => $brands,
            'unmappedCount'  => $unmappedCount,
            'catalogSize'    => $catalogSize,
            'confidenceSafe' => \App\Services\Mapping\MappingCandidateFinder::CONFIDENCE_SAFE,
        ]);
    }

    /**
     * Eşleştirme kaydet
     */
    public function store(Request $request): void
    {
        $brandId = $request->integer('brand_id');
        $marketplaceId = $request->integer('marketplace_id');
        $mpBrandId = $request->post('marketplace_brand_id', '');
        $mpBrandName = $request->post('marketplace_brand_name');

        if ($brandId === 0 || $marketplaceId === 0 || $mpBrandId === '') {
            if ($request->isAjax()) {
                $this->error('Eksik alanlar');
            }
            $this->redirectWithError('/brands/mapping', 'Eksik alanlar');
        }

        $this->mappingModel->saveMapping($brandId, $marketplaceId, $mpBrandId, $mpBrandName);

        if ($request->isAjax()) {
            $this->success([], 'Eşleştirme kaydedildi');
        }

        $this->redirectWithSuccess('/brands/mapping?marketplace_id=' . $marketplaceId, 'Marka eşleştirmesi kaydedildi');
    }

    /**
     * Eşleştirme sil
     */
    public function delete(Request $request, int $id): void
    {
        $mapping = $this->mappingModel->find($id);
        if ($mapping === false) {
            $this->redirectWithError('/brands/mapping', 'Eşleştirme bulunamadı');
        }

        $marketplaceId = (int) $mapping['marketplace_id'];
        $this->mappingModel->delete($id);

        if ($request->isAjax()) {
            $this->success([], 'Eşleştirme silindi');
        }

        $this->redirectWithSuccess('/brands/mapping?marketplace_id=' . $marketplaceId, 'Eşleştirme silindi');
    }

    /**
     * AJAX: Trendyol marka arama
     */
    public function searchTrendyol(Request $request): void
    {
        $marketplaceId = $request->integer('marketplace_id');
        $query = $request->get('q', '');

        $brands = $this->brandMappingService->searchMarketplaceBrands($marketplaceId, $query);

        $this->success(['brands' => $brands]);
    }
}
