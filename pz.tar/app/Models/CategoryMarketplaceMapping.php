<?php
/**
 * OzyConnect Panel — CategoryMarketplaceMapping Model
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    1.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Models;

final class CategoryMarketplaceMapping extends BaseModel
{
    protected string $table = 'category_marketplace_mapping';

    /**
     * Eşleştirme bul
     *
     * @return array<string, mixed>|false
     */
    public function findMapping(int $categoryId, int $marketplaceId): array|false
    {
        return $this->findBy([
            'category_id'    => $categoryId,
            'marketplace_id' => $marketplaceId,
        ]);
    }

    /**
     * Pazaryeri kategori ID'si ile iç kategori bul
     *
     * @return array<string, mixed>|false
     */
    public function findByMarketplaceCategory(int $marketplaceId, string $mpCategoryId): array|false
    {
        return $this->findBy([
            'marketplace_id'          => $marketplaceId,
            'marketplace_category_id' => $mpCategoryId,
        ]);
    }

    /**
     * Cached marketplace category leaf state.
     *
     * Null means cache is not available for that marketplace category.
     *
     * @return array{is_leaf: bool, name: string, full_path: string}|null
     */
    public function getMarketplaceCategoryLeafStatus(int $marketplaceId, string $mpCategoryId): ?array
    {
        $row = $this->rawQueryOne(
            "SELECT name, full_path, is_leaf
             FROM marketplace_categories
             WHERE marketplace_id = :mid AND mp_category_id = :cid
             LIMIT 1",
            ['mid' => $marketplaceId, 'cid' => $mpCategoryId]
        );

        if ($row === false) {
            return null;
        }

        return [
            'is_leaf'   => (int) ($row['is_leaf'] ?? 0) === 1,
            'name'      => (string) ($row['name'] ?? ''),
            'full_path' => (string) ($row['full_path'] ?? ''),
        ];
    }

    public function mappingUsesLeafCategory(array $mapping): ?bool
    {
        $status = $this->getMarketplaceCategoryLeafStatus(
            (int) ($mapping['marketplace_id'] ?? 0),
            (string) ($mapping['marketplace_category_id'] ?? '')
        );

        return $status === null ? null : $status['is_leaf'];
    }

    /**
     * Pazaryerindeki eşleştirilmemiş kategorileri getir
     *
     * @return array<int, array<string, mixed>>
     */
    public function getMappedCategories(int $marketplaceId): array
    {
        return $this->rawQuery(
            "SELECT cmm.*, c.name as internal_name, c.full_path
             FROM category_marketplace_mapping cmm
             JOIN categories c ON cmm.category_id = c.id AND c.store_id = :store_id2
             WHERE cmm.marketplace_id = :mid
               AND cmm.store_id = :store_id
             ORDER BY c.name ASC",
            ['mid' => $marketplaceId, 'store_id' => $this->tenantId(), 'store_id2' => $this->tenantId()]
        );
    }

    /**
     * Eşleştirme kaydet veya güncelle
     */
    public function saveMapping(
        int $categoryId,
        int $marketplaceId,
        string $mpCategoryId,
        string $mpCategoryName,
        ?string $mpCategoryPath = null
    ): int {
        $this->assertMarketplaceCategoryIsLeaf($marketplaceId, $mpCategoryId);

        $existing = $this->findMapping($categoryId, $marketplaceId);

        if ($existing !== false) {
            $this->update((int) $existing['id'], [
                'marketplace_category_id'   => $mpCategoryId,
                'marketplace_category_name' => $mpCategoryName,
                'marketplace_category_path' => $mpCategoryPath,
            ]);
            return (int) $existing['id'];
        }

        return $this->create([
            'category_id'               => $categoryId,
            'marketplace_id'            => $marketplaceId,
            'marketplace_category_id'   => $mpCategoryId,
            'marketplace_category_name' => $mpCategoryName,
            'marketplace_category_path' => $mpCategoryPath,
        ]);
    }

    /**
     * Eşleştirilmemiş kategorilere sahip ürün sayısını getir
     */
    public function getUnmappedCategoryCount(int $marketplaceId): int
    {
        $row = $this->rawQueryOne(
            "SELECT COUNT(DISTINCT p.category_id) as cnt
             FROM products p
             WHERE p.category_id IS NOT NULL
               AND p.is_active = 1
               AND p.store_id = :store_id
               AND p.category_id NOT IN (
                   SELECT cmm.category_id
                   FROM category_marketplace_mapping cmm
                   WHERE cmm.marketplace_id = :mid
                     AND cmm.store_id = :store_id2
               )",
            ['mid' => $marketplaceId, 'store_id' => $this->tenantId(), 'store_id2' => $this->tenantId()]
        );
        return (int) ($row['cnt'] ?? 0);
    }

    /**
     * Tüm iç kategorileri eşleştirme durumuyla getir
     *
     * @return array<int, array<string, mixed>>
     */
    public function getCategoriesWithStatus(int $marketplaceId): array
    {
        return $this->rawQuery(
            "SELECT c.id, c.name, c.full_path, c.parent_id,
                    cmm.id as mapping_id,
                    cmm.marketplace_category_id,
                    cmm.marketplace_category_name,
                    mc.is_leaf as marketplace_category_is_leaf,
                    cmm.attribute_mapping_json,
                    (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.is_active = 1 AND p.store_id = :store_id3) as product_count
             FROM categories c
             LEFT JOIN category_marketplace_mapping cmm
                 ON c.id = cmm.category_id AND cmm.marketplace_id = :mid AND cmm.store_id = :store_id2
             LEFT JOIN marketplace_categories mc
                 ON mc.marketplace_id = cmm.marketplace_id
                AND mc.mp_category_id = cmm.marketplace_category_id
             WHERE c.is_active = 1
               AND c.store_id = :store_id
             ORDER BY c.name ASC",
            ['mid' => $marketplaceId, 'store_id' => $this->tenantId(), 'store_id2' => $this->tenantId(), 'store_id3' => $this->tenantId()]
        );
    }

    /**
     * Eşleştirilmemiş pazaryeri kategorilerini getir
     *
     * @return array<int, array<string, mixed>>
     */
    /**
     * Eşleştirilmemiş pazaryeri kategorilerini getir
     */
    public function getUnmappedMarketplaceCategories(int $marketplaceId): array
    {
        return $this->rawQuery(
            "SELECT
                COALESCE(mp.marketplace_category_id, 'unknown') as marketplace_category_id,
                COUNT(DISTINCT p.id) as product_count
             FROM products p
             JOIN marketplace_products mp ON p.id = mp.product_id AND mp.marketplace_id = :mid AND mp.store_id = :store_id2
             WHERE p.needs_category_mapping = 1
               AND p.is_active = 1
               AND p.store_id = :store_id
             GROUP BY mp.marketplace_category_id
             ORDER BY product_count DESC",
            ['mid' => $marketplaceId, 'store_id' => $this->tenantId(), 'store_id2' => $this->tenantId()]
        );
    }

    /**
     * Belirli kategorinin kaç pazaryeriyle eşleştirildiğini say
     */
    public function countMappings(int $categoryId): int
    {
        $row = $this->rawQueryOne(
            "SELECT COUNT(*) as cnt FROM category_marketplace_mapping WHERE category_id = :cid AND store_id = :store_id",
            ['cid' => $categoryId, 'store_id' => $this->tenantId()]
        );
        return (int)($row['cnt'] ?? 0);
    }

    /**
     * Belirli kategorinin tüm pazaryeri eşleştirmelerini getir
     */
    public function getMappingsForCategory(int $categoryId): array
    {
        return $this->rawQuery(
            "SELECT cmm.*, m.slug as marketplace_slug, m.display_name as marketplace_name,
                    mc.is_leaf as marketplace_category_is_leaf
             FROM category_marketplace_mapping cmm
             JOIN marketplaces m ON cmm.marketplace_id = m.id
             LEFT JOIN marketplace_categories mc
                 ON mc.marketplace_id = cmm.marketplace_id
                AND mc.mp_category_id = cmm.marketplace_category_id
             WHERE cmm.category_id = :cid
               AND cmm.store_id = :store_id
             ORDER BY m.display_name ASC",
            ['cid' => $categoryId, 'store_id' => $this->tenantId()]
        );
    }

    public function countByMarketplace(int $marketplaceId): int
    {
        $row = $this->rawQueryOne(
            "SELECT COUNT(*) as cnt FROM category_marketplace_mapping WHERE marketplace_id = :mid AND store_id = :store_id",
            ['mid' => $marketplaceId, 'store_id' => $this->tenantId()]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public function countMappedCategories(): int
    {
        $row = $this->rawQueryOne(
            "SELECT COUNT(DISTINCT category_id) as cnt FROM category_marketplace_mapping WHERE store_id = :store_id",
            ['store_id' => $this->tenantId()]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public function deleteByMarketplace(int $marketplaceId): int
    {
        $stmt = $this->db->query(
            "DELETE FROM category_marketplace_mapping WHERE marketplace_id = :mid AND store_id = :store_id",
            ['mid' => $marketplaceId, 'store_id' => $this->tenantId()]
        );
        return $stmt->rowCount();
    }

    private function assertMarketplaceCategoryIsLeaf(int $marketplaceId, string $mpCategoryId): void
    {
        $status = $this->getMarketplaceCategoryLeafStatus($marketplaceId, $mpCategoryId);
        if ($status === null || $status['is_leaf']) {
            return;
        }

        $label = $status['full_path'] !== '' ? $status['full_path'] : $status['name'];
        if ($label === '') {
            $label = $mpCategoryId;
        }

        throw new \RuntimeException(
            'Ara kategori secilemez. Lutfen en alt/final pazaryeri kategorisini secin: ' . $label
        );
    }
}
