<?php
// OzyConnect Panel — Cron: Sipariş Senkronizasyonu
// Kullanım: php cron/sync_orders.php
// Crontab: Her 5 dakikada bir
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/public/index.php';

use App\Services\Sync\OrderSyncService;

$container = $GLOBALS['container'] ?? null;
if ($container === null) {
    echo "[ERROR] Container yüklenemedi\n";
    exit(1);
}

$syncService = $container->get(OrderSyncService::class);
$cronRunner  = $container->get(\App\Services\TenantCronRunner::class);
$logger = $container->get(\App\Core\Logger::class);
$settings = $container->get(\App\Models\Setting::class);

// Ayar kontrolü
if (!($settings->get('sync_orders_enabled') ?? true)) {
    echo "[SKIP] Sipariş senkronizasyonu devre dışı.\n";
    exit(0);
}

echo "[" . date('Y-m-d H:i:s') . "] Sipariş sync başlıyor (per-store)...\n";

// Faz 4 — PER-STORE: her aktif mağaza kendi TenantContext'inde, entitlement'i olan
// pazaryerleri için. Bir mağaza hatası diğerlerini durdurmaz (TenantCronRunner izole eder).
$storeResults = $cronRunner->runForActiveStores(static function (int $storeId) use ($syncService): array {
    return $syncService->syncAll('cron');
});

foreach ($storeResults as $storeId => $sr) {
    if (!($sr['ok'] ?? false)) {
        echo "  store#{$storeId}: [HATA] " . ($sr['error'] ?? '?') . "\n";
        $logger->error("Cron sipariş sync store#{$storeId}: " . ($sr['error'] ?? '?'), 'Cron');
        continue;
    }
    foreach (($sr['result'] ?? []) as $slug => $result) {
        echo "  store#{$storeId} {$slug}: fetched={$result['fetched']}, processed={$result['processed']}, failed={$result['failed']}\n";
    }
}
echo "[OK] Sipariş sync tamamlandı (" . count($storeResults) . " mağaza).\n";
