<?php
/**
 * OzyConnect Panel — ProductPublishService (Marketplace-Agnostic)
 * Ürünleri pazaryerlerine gönderme (listeleme) servisi.
 * Doğrudan TrendyolService'e bağımlı DEĞİL — Container üzerinden dinamik çözümleme.
 *
 * İŞ KURALLARI:
 * - Batch size limiti: 50 ürün (otomatik bölünür)
 * - Retry: AbstractMarketplace TEK SAHİBİ — ProductPublishService retry YAPMAZ
 *   (AbstractMarketplace.httpRequest() zaten 429/5xx için exponential backoff retry uygular)
 * - Transaction: marketplace_products update DB transaction içinde
 * - API başarılı + DB başarısız senaryosu: hata loglanır, partial success olarak raporlanır,
 *   retry güvenli (upsert idempotent + Trendyol barcode bazlı create-or-update)
 * - broadcastStock izole: hatası publish sonucunu etkilemez
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    1.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Services;

use App\Core\Container;
use App\Core\Database;
use App\Core\Logger;
use App\Models\BrandMarketplaceMapping;
use App\Models\CategoryMarketplaceMapping;
use App\Models\Marketplace;
use App\Models\MarketplaceProduct;
use App\Models\Product;
use App\Models\ProductAttributeValue;
use App\Models\SyncLog;
use RuntimeException;

final class ProductPublishService
{
    private const BATCH_SIZE = 50;

    public function __construct(
        private readonly Container $container,
        private readonly Database $db,
        private readonly Product $productModel,
        private readonly MarketplaceProduct $mpProductModel,
        private readonly CategoryMarketplaceMapping $catMappingModel,
        private readonly BrandMarketplaceMapping $brandMappingModel,
        private readonly ProductAttributeValue $pAttrValueModel,
        private readonly PriceRuleEngine $priceEngine,
        private readonly SyncLog $syncLogModel,
        private readonly Marketplace $marketplaceModel,
        private readonly StockManager $stockManager,
        private readonly Logger $logger,
    ) {}

    /**
     * Tek ürünü pazaryerine gönder
     *
     * @return array{success: bool, error: ?string}
     */
    public function publishProduct(int $productId, int $marketplaceId): array
    {
        $result = $this->publishProducts([$productId], $marketplaceId);

        if ($result['success'] > 0) {
            return ['success' => true, 'error' => null];
        }

        $error = !empty($result['errors']) ? $result['errors'][0]['error'] ?? 'Bilinmeyen hata' : 'Bilinmeyen hata';
        return ['success' => false, 'error' => $error];
    }

    /**
     * Toplu ürün gönderimi (batch size max 50, otomatik bölünür)
     * marketplace_products update + sync_log write aynı transaction içinde
     * API hataları (429, 5xx) için exponential backoff retry (max 3)
     *
     * @param array<int> $productIds
     * @return array{success: int, failed: int, skipped: int, errors: array}
     */
    public function publishProducts(array $productIds, int $marketplaceId): array
    {
        $marketplace = $this->marketplaceModel->find($marketplaceId);
        if ($marketplace === false) {
            return ['success' => 0, 'failed' => 0, 'skipped' => 0, 'errors' => [['error' => 'Pazaryeri bulunamadı']]];
        }

        $marketplaceService = $this->resolveMarketplaceService($marketplace['slug']);

        $totalSuccess = 0;
        $totalFailed = 0;
        $totalSkipped = 0;
        $allErrors = [];
        $allBatchIds = [];

        // Batch'lere böl
        $batches = array_chunk($productIds, self::BATCH_SIZE);

        foreach ($batches as $batchIds) {
            $batchResult = $this->publishBatch($batchIds, $marketplaceId, $marketplace, $marketplaceService);
            $totalSuccess += $batchResult['success'];
            $totalFailed += $batchResult['failed'];
            $totalSkipped += $batchResult['skipped'];
            $allErrors = array_merge($allErrors, $batchResult['errors']);
            $allBatchIds = array_merge($allBatchIds, $batchResult['batch_ids'] ?? []);
        }

        // Sync log — transaction dışında (tüm batch'ler bittikten sonra)
        $this->logSyncResult($marketplaceId, $totalSuccess, $totalFailed, $totalSkipped, $allErrors);

        return [
            'success' => $totalSuccess,
            'failed'  => $totalFailed,
            'skipped' => $totalSkipped,
            'errors'  => $allErrors,
            'batch_ids' => array_values(array_unique(array_filter($allBatchIds))),
        ];
    }

    /**
     * Ürünün publish için hazır olup olmadığını kontrol et
     *
     * @return array{valid: bool, errors: array<string>}
     */
    public function validateForPublish(int $productId, int $marketplaceId): array
    {
        $errors = [];

        $product = $this->productModel->find($productId);
        if ($product === false) {
            return ['valid' => false, 'errors' => ['Ürün bulunamadı']];
        }

        // a) En az bir görsel
        if (!$this->productHasImage($product)) {
            $errors[] = 'Ürün görseli eksik (main_image boş)';
        }

        $marketplace = $this->marketplaceModel->find($marketplaceId);
        $marketplaceSlug = (string) ($marketplace['slug'] ?? '');
        if ($this->requiresPublicImages($marketplaceSlug)) {
            $privateImages = $this->findPrivateImageUrls($product);
            if (!empty($privateImages)) {
                $errors[] = 'Pazaryeri görselleri dışarıdan erişilebilir URL olmalı. localhost/özel ağ görseli kullanılamaz; görsel/APP_URL canlı domain olmalı: ' . $privateImages[0];
            }
        }

        // b) Geçerli fiyat
        if ((float) ($product['base_price'] ?? 0) <= 0) {
            $errors[] = 'Geçersiz fiyat (base_price > 0 olmalı)';
        }

        // c) Geçerli stok
        if ((int) ($product['stock_qty'] ?? -1) < 0) {
            $errors[] = 'Geçersiz stok (stock_qty >= 0 olmalı)';
        }

        // d) Barkod
        if (empty($product['barcode'])) {
            $errors[] = 'Barkod eksik';
        }

        // e) Kategori eşleştirmesi
        $categoryId = $product['category_id'] ?? null;
        if ($categoryId === null) {
            $errors[] = 'Kategori atanmamış';
        } else {
            $catMapping = $this->catMappingModel->findMapping((int) $categoryId, $marketplaceId);
            if ($catMapping === false) {
                $errors[] = 'Kategori pazaryeri eşleştirmesi yapılmamış';
            } else {
                $leafStatus = $this->catMappingModel->getMarketplaceCategoryLeafStatus(
                    $marketplaceId,
                    (string) ($catMapping['marketplace_category_id'] ?? '')
                );
                if ($leafStatus !== null && !$leafStatus['is_leaf']) {
                    $categoryLabel = $leafStatus['full_path'] !== ''
                        ? $leafStatus['full_path']
                        : ($leafStatus['name'] !== '' ? $leafStatus['name'] : (string) ($catMapping['marketplace_category_id'] ?? ''));
                    $errors[] = 'Kategori pazaryeri eslestirmesi ara kategoriye bagli. En alt/final kategori secin: ' . $categoryLabel;
                }

                // f) Zorunlu kategori özellikleri
                $attrMapping = json_decode($catMapping['attribute_mapping_json'] ?? '[]', true);
                if (is_array($attrMapping)) {
                    $requiredAttrs = array_filter($attrMapping, fn($a) => !empty($a['required']));
                    if (!empty($requiredAttrs)) {
                        $productAttrs = $this->pAttrValueModel->getByProduct($productId);
                        $filledAttrIds = array_column($productAttrs, 'attribute_id');

                        foreach ($requiredAttrs as $reqAttr) {
                            $attrId = $reqAttr['id'] ?? 0;
                            if ($attrId > 0 && !in_array($attrId, $filledAttrIds)) {
                                $errors[] = "Zorunlu özellik eksik: " . ($reqAttr['name'] ?? "ID:{$attrId}");
                            }
                        }
                    }
                }
            }
        }

        // g) Marka eşleştirmesi — yalnız payload'unda pazaryeri marka ID'si kullanan
        // pazaryerleri için zorunlu. N11/ÇiçekSepeti gibi pazaryerlerinde gerçek marka
        // API'si yok; oralarda marka eşleştirmesi publish'i bloklamasın.
        if ($this->requiresBrandMapping($marketplaceSlug)) {
            $brandId = $product['brand_id'] ?? null;
            if ($brandId === null) {
                $errors[] = 'Marka atanmamış';
            } else {
                $brandMapping = $this->brandMappingModel->findMapping((int) $brandId, $marketplaceId);
                if ($brandMapping === false) {
                    $errors[] = 'Marka pazaryeri eşleştirmesi yapılmamış';
                }
            }
        }

        return ['valid' => empty($errors), 'errors' => $errors];
    }

    /**
     * Ürün payload'unda pazaryeri marka ID'si zorunlu olan pazaryerleri
     */
    private function requiresBrandMapping(string $marketplaceSlug): bool
    {
        return in_array($marketplaceSlug, ['trendyol', 'pazarama', 'oziygo', 'idefix'], true);
    }

    /**
     * Marka eşleştirmesi pazaryeri marka ID'si yerine marka ADI içeriyorsa
     * (import sırasında ada göre oluşan eski eşleştirmeler) marketplace_brands
     * katalogundan gerçek ID'ye çevir. Trendyol SAYISAL marka ID'si zorunlar;
     * metin gönderilirse (int) cast 0 olur ve batch her seferinde reddedilir.
     *
     * @param array<string, mixed>|false $brandMapping
     * @return array<string, mixed>|false
     */
    private function resolveBrandMappingId(array|false $brandMapping, int $marketplaceId, string $slug): array|false
    {
        if ($brandMapping === false) {
            return false;
        }

        $value = trim((string) ($brandMapping['marketplace_brand_id'] ?? ''));
        if ($value === '') {
            return $brandMapping;
        }

        // Trendyol: sayısal marka ID zorunlu — metinse katalogdan adıyla çöz
        if ($slug === 'trendyol' && !ctype_digit($value)) {
            try {
                $mpBrandModel = $this->container->get(\App\Models\MarketplaceBrand::class);
                $found = $mpBrandModel->findExactMatch($value, $marketplaceId);
                if ($found !== false && ctype_digit((string) $found['mp_brand_id'])) {
                    $brandMapping['marketplace_brand_id'] = (string) $found['mp_brand_id'];
                    return $brandMapping;
                }
            } catch (\Throwable $e) {
                $this->logger->warning('Marka ID çözümleme hatası: ' . $e->getMessage(), 'ProductPublish');
            }

            $this->logger->warning(
                "Trendyol marka eşleştirmesi sayısal değil ve katalogda bulunamadı: '{$value}' — batch reddedilebilir",
                'ProductPublish'
            );
        }

        // Pazarama: marka ID System.Guid zorunlu — GUID değilse (md5/ad) gerçek
        // katalogdan adıyla arayıp GUID'e çevir
        $isGuid = (bool) preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $value);
        if ($slug === 'pazarama' && !$isGuid) {
            try {
                $pazarama = $this->container->get(\App\Services\Marketplace\PazaramaService::class);
                // Eşleştirme değeri çoğu kurulumda marka ADI veya md5'idir;
                // md5 ise sistem marka adına düş
                $searchName = str_contains($value, ' ') || !ctype_xdigit($value)
                    ? $value
                    : (string) ($brandMapping['brand_name'] ?? $value);
                $guid = $pazarama->findBrandGuidByName($searchName);
                if ($guid !== null) {
                    $brandMapping['marketplace_brand_id'] = $guid;
                    return $brandMapping;
                }
                $this->logger->warning(
                    "Pazarama marka GUID'i bulunamadı: '{$searchName}' — Pazarama'da marka onayı gerekebilir",
                    'ProductPublish'
                );
            } catch (\Throwable $e) {
                $this->logger->warning('Pazarama marka GUID çözümleme hatası: ' . $e->getMessage(), 'ProductPublish');
            }
        }

        return $brandMapping;
    }

    /**
     * Tek batch'i işle
     *
     * @param array<int> $productIds
     * @param array<string, mixed> $marketplace
     * @param object $marketplaceService
     * @return array{success: int, failed: int, skipped: int, errors: array}
     */
    private function publishBatch(array $productIds, int $marketplaceId, array $marketplace, object $marketplaceService): array
    {
        $success = 0;
        $failed = 0;
        $skipped = 0;
        $errors = [];
        $validItems = [];
        $validProductMap = []; // productId => product data
        $publishMeta = []; // productId => item + mapping data

        // 1. Validasyon — API çağrısından ÖNCE
        foreach ($productIds as $productId) {
            $validation = $this->validateForPublish($productId, $marketplaceId);

            if (!$validation['valid']) {
                $skipped++;
                $validationError = 'Validasyon hatası: ' . implode(', ', $validation['errors']);
                $errors[] = [
                    'product_id' => $productId,
                    'error'      => $validationError,
                ];

                // Hata ürün-pazaryeri kaydına da yazılsın — liste rozetinde görünsün
                try {
                    $this->mpProductModel->upsertByProductAndMarketplace($productId, $marketplaceId, [
                        'sync_error'     => mb_substr($validationError, 0, 500),
                        'last_synced_at' => date('Y-m-d H:i:s'),
                    ]);
                } catch (\Throwable $badgeEx) {
                    $this->logger->warning('Validasyon rozeti yazılamadı: ' . $badgeEx->getMessage(), 'ProductPublish');
                }
                continue;
            }

            $product = $this->productModel->find($productId);
            if ($product === false) {
                $skipped++;
                continue;
            }

            $price = $this->priceEngine->calculatePrice($product, $marketplaceId);
            $catMapping = $this->catMappingModel->findMapping((int) $product['category_id'], $marketplaceId);
            $brandMapping = $this->brandMappingModel->findMapping((int) $product['brand_id'], $marketplaceId);
            $brandMapping = $this->resolveBrandMappingId($brandMapping, $marketplaceId, (string) $marketplace['slug']);

            // Pazaryerine özel ürün formatı
            $item = $this->buildMarketplaceItem($product, $price, $catMapping, $brandMapping, $marketplace['slug'], $marketplace);

            $validItems[] = $item;
            $validProductMap[$productId] = $product;
            $publishMeta[$productId] = [
                'item' => $item,
                'price' => $price,
                'category_mapping' => $catMapping,
                'brand_mapping' => $brandMapping,
            ];
        }

        if (empty($validItems)) {
            return ['success' => 0, 'failed' => $failed, 'skipped' => $skipped, 'errors' => $errors, 'batch_ids' => []];
        }

        // 1.5 BEKLEYEN BATCH ÇÖZÜMÜ — daha önce gönderilmiş ve sonucu bekleyen
        //     ürün için YENİ create atma. (Trendyol art arda create isteklerini
        //     satıcı bazında "recurring" hatasıyla engeller; kullanıcı tekrar
        //     Yayınla'ya bastığında önce önceki batch'in sonucuna bakılır.)
        if (method_exists($marketplaceService, 'getBatchStatus')) {
            foreach (array_keys($validProductMap) as $pendingProductId) {
                $mpRow = $this->mpProductModel->findByProductAndMarketplace($pendingProductId, $marketplaceId);
                $syncError = $mpRow !== false ? (string) ($mpRow['sync_error'] ?? '') : '';
                if (!str_starts_with($syncError, 'Batch kontrol bekliyor: ')) {
                    continue;
                }

                $pendingBatchId = trim(substr($syncError, strlen('Batch kontrol bekliyor: ')));
                if ($pendingBatchId === '') {
                    continue;
                }

                $statuses = $this->checkBatchStatus($marketplaceService, $pendingBatchId);
                $pendingProduct = $validProductMap[$pendingProductId];
                $barcode = trim((string) ($pendingProduct['barcode'] ?? ''));
                $batchStatus = $statuses[$barcode] ?? null;

                if ($batchStatus !== null && ($batchStatus['status'] ?? '') === 'SUCCESS') {
                    // Önceki gönderim başarıyla tamamlanmış — listelendi işaretle, create'e gerek yok
                    $this->mpProductModel->update((int) $mpRow['id'], [
                        'is_listed'      => 1,
                        'sync_error'     => null,
                        'last_synced_at' => date('Y-m-d H:i:s'),
                    ]);
                    $success++;
                    unset($validProductMap[$pendingProductId], $publishMeta[$pendingProductId]);
                } elseif ($batchStatus !== null && ($batchStatus['status'] ?? '') === 'FAILED') {
                    // Önceki batch reddedilmiş — yeniden gönderime (create) devam et,
                    // eski hata mesajı yeni denemenin sonucuna göre güncellenecek
                    continue;
                } else {
                    // Hâlâ işleniyor — bu turda tekrar gönderme, kullanıcıyı bilgilendir
                    $skipped++;
                    $errors[] = [
                        'product_id' => $pendingProductId,
                        'error'      => "Önceki gönderim (batch {$pendingBatchId}) pazaryerinde hâlâ işleniyor — "
                            . 'tekrar göndermeye gerek yok, sonuç birkaç dakika içinde otomatik netleşir.',
                    ];
                    unset($validProductMap[$pendingProductId], $publishMeta[$pendingProductId]);
                }
            }

            // Kalan ürünlerle gönderi listesini yeniden kur
            $validItems = array_values(array_map(
                fn(int $pid) => $publishMeta[$pid]['item'],
                array_keys($validProductMap)
            ));

            if (empty($validItems)) {
                return ['success' => $success, 'failed' => $failed, 'skipped' => $skipped, 'errors' => $errors, 'batch_ids' => []];
            }
        }

        // 2. API çağrısı — tek çağrı, retry AbstractMarketplace'in sorumluluğunda
        $apiResult = $this->callCreateProducts($marketplaceService, $validItems);

        // 3. Sonuçları kaydet — her ürün kendi transaction'ında
        //    API başarılı + DB başarısız senaryosu: hata loglanır, partial success olarak raporlanır
        //    Retry güvenli: upsert idempotent + Trendyol barcode bazlı create-or-update
        if ($apiResult['success']) {
            foreach ($validProductMap as $productId => $product) {
                try {
                    $meta = $publishMeta[$productId] ?? [];
                    $batchStatus = $this->batchStatusForProduct($apiResult, $product);
                    if ($batchStatus !== null && ($batchStatus['status'] ?? '') === 'FAILED') {
                        $failed++;
                        $errorText = (string) ($batchStatus['message'] ?? 'Batch reddedildi');
                        $errors[] = ['product_id' => $productId, 'error' => $errorText];
                        $meta['batch_failure'] = $errorText;
                        $this->db->transaction(function () use ($productId, $marketplaceId, $product, $meta): void {
                            $this->mpProductModel->upsertByProductAndMarketplace(
                                $productId,
                                $marketplaceId,
                                $this->buildMarketplaceProductState($product, $meta)
                            );
                        });
                        continue;
                    }

                    $batchRequestId = (string) ($apiResult['batchRequestId'] ?? '');
                    if ($batchRequestId !== '' && ($batchStatus['status'] ?? '') !== 'SUCCESS') {
                        $meta['pending_batch_id'] = $batchRequestId;
                    }

                    $this->db->transaction(function () use ($productId, $marketplaceId, $product, $meta): void {
                        $this->mpProductModel->upsertByProductAndMarketplace(
                            $productId,
                            $marketplaceId,
                            $this->buildMarketplaceProductState($product, $meta)
                        );
                    });
                    $success++;
                } catch (\Throwable $e) {
                    // API başarılı ama DB başarısız — ürün pazaryerinde listelendi ama lokal kayıt güncellenemedi
                    // Bu partial success olarak raporlanır
                    // Retry güvenli: upsertByProductAndMarketplace idempotent (composite unique key)
                    // Trendyol tarafında duplicate yok: aynı barcode ile tekrar gönderim güncelleme olarak işlenir
                    $failed++;
                    $dbError = 'API başarılı ama DB kayıt hatası: ' . $e->getMessage()
                             . ' — Ürün pazaryerinde listelendi, lokal durum güncellenemedi. Tekrar gönderim güvenlidir.';
                    $errors[] = ['product_id' => $productId, 'error' => $dbError];

                    $this->logger->error(
                        "Publish DB tutarsızlığı (ürün #{$productId}): API başarılı, DB başarısız: " . $e->getMessage(),
                        'ProductPublish'
                    );

                    // sync_error olarak da kaydetmeyi dene (bu da başarısız olabilir ama en azından dene)
                    try {
                        $mpExisting = $this->mpProductModel->findByProductAndMarketplace($productId, $marketplaceId);
                        if ($mpExisting !== false) {
                            $this->mpProductModel->setSyncError((int) $mpExisting['id'], 'DB güncelleme hatası — pazaryerinde listelendi');
                        }
                    } catch (\Throwable $innerEx) {
                        // DB tamamen erişilemez — sadece logla
                        $this->logger->error("sync_error yazılamadı: " . $innerEx->getMessage(), 'ProductPublish');
                    }
                }
            }
        } else {
            // API başarısız — tüm ürünleri hatalı olarak işaretle
            $apiError = !empty($apiResult['errors']) ? $apiResult['errors'][0]['error'] ?? 'API hatası' : 'API hatası';
            foreach ($validProductMap as $productId => $product) {
                $failed++;
                $errors[] = ['product_id' => $productId, 'error' => $apiError];

                // sync_error kaydet
                $mpExisting = $this->mpProductModel->findByProductAndMarketplace($productId, $marketplaceId);
                if ($mpExisting !== false) {
                    $this->mpProductModel->setSyncError((int) $mpExisting['id'], $apiError);
                }
            }
        }

        return [
            'success' => $success,
            'failed' => $failed,
            'skipped' => $skipped,
            'errors' => $errors,
            'batch_ids' => array_values(array_filter([(string) ($apiResult['batchRequestId'] ?? '')])),
        ];
    }

    /**
     * API çağrısı — tek çağrı, retry AbstractMarketplace'in sorumluluğunda
     *
     * RETRY SAHİPLİĞİ: AbstractMarketplace.httpRequest() zaten 429/5xx için
     * exponential backoff retry uygular (maxRetries=3, retryBaseDelayMs=1000).
     * ProductPublishService ek retry YAPMAZ — duplicate retry loop önlenir.
     *
     * TrendyolService.createProducts() kendi try/catch'i ile sarılıdır ve
     * AbstractMarketplace'in fırlattığı exception'ları yakalar. Bu yüzden
     * burada sadece result kontrolü yapılır.
     *
     * @return array{success: bool, errors: array, batchRequestId?: ?string, batch_status_by_barcode?: array<string, array<string, string>>}
     */
    private function callCreateProducts(object $marketplaceService, array $items): array
    {
        if (!method_exists($marketplaceService, 'createProducts')) {
            return ['success' => false, 'errors' => [['error' => 'Pazaryeri servisi createProducts desteklemiyor']]];
        }

        try {
            $result = $marketplaceService->createProducts($items);

            if ($result['success'] ?? false) {
                $batchId = $result['batchRequestId']
                    ?? $result['batchId']
                    ?? $result['taskId']
                    ?? $result['trackingId']
                    ?? null;

                return [
                    'success' => true,
                    'errors' => [],
                    'batchRequestId' => $batchId !== null ? (string) $batchId : null,
                    'batch_status_by_barcode' => $batchId !== null
                        ? $this->checkBatchStatus($marketplaceService, (string) $batchId)
                        : [],
                ];
            }

            $apiErrors = $result['errors'] ?? [['error' => 'Bilinmeyen API hatası']];

            $this->logger->warning(
                'Publish API başarısız',
                'ProductPublish',
                ['errors' => $apiErrors]
            );

            return ['success' => false, 'errors' => $apiErrors, 'batchRequestId' => null];

        } catch (\Throwable $e) {
            $this->logger->error(
                'Publish exception: ' . $e->getMessage(),
                'ProductPublish'
            );

            return ['success' => false, 'errors' => [['error' => $e->getMessage()]], 'batchRequestId' => null];
        }
    }

    /**
     * Marketplace servisini dinamik olarak çöz (Container üzerinden)
     */
    private function resolveMarketplaceService(string $slug): object
    {
        $serviceMap = [
            'trendyol' => \App\Services\Marketplace\TrendyolService::class,
            'n11'      => \App\Services\Marketplace\N11Service::class,
            'pazarama' => \App\Services\Marketplace\PazaramaService::class,
            'pttavm'   => \App\Services\Marketplace\PttavmService::class,
            'ciceksepeti' => \App\Services\Marketplace\CiceksepetiService::class,
            'hepsiburada' => \App\Services\Marketplace\HepsiburadaService::class,
            'idefix'      => \App\Services\Marketplace\IdefixService::class,
            'oziygo'      => \App\Services\Marketplace\OziygoService::class,
            // Amazon bu haritada YOKTU: AmazonService::createProducts() yazılmış olmasına
            // rağmen yayınlama akışı "Desteklenmeyen pazaryeri: amazon" ile duruyordu.
            'amazon'      => \App\Services\Marketplace\AmazonService::class,
        ];

        $serviceClass = $serviceMap[$slug] ?? null;

        if ($serviceClass === null) {
            throw new RuntimeException("Desteklenmeyen pazaryeri: {$slug}");
        }

        return $this->container->get($serviceClass);
    }

    /**
     * Pazaryerine gönderilecek ürün verisini oluştur
     *
     * @return array<string, mixed>
     */
    private function buildMarketplaceItem(
        array $product,
        array $price,
        array|false $catMapping,
        array|false $brandMapping,
        string $slug,
        array $marketplace = []
    ): array {
        $extraConfig = json_decode((string) ($marketplace['extra_config_json'] ?? '{}'), true) ?: [];

        // Açıklama boş string olabilir — "?? " yalnız NULL'u yakalar; pazaryerleri
        // (ör. Trendyol "Açıklama alanı boş olamaz") boş açıklamayı reddeder.
        $description = trim((string) ($product['description'] ?? ''));
        if ($description === '') {
            $description = (string) $product['name'];
        }

        // Trendyol formatı
        if ($slug === 'trendyol') {
            $images = $this->buildImageList($product);

            $attributes = [];
            $productAttrs = $this->pAttrValueModel->getByProduct((int) $product['id']);
            foreach ($productAttrs as $pa) {
                if (!empty($pa['custom_value'])) {
                    $attributes[] = [
                        'attributeId' => (int) $pa['attribute_id'],
                        'customAttributeValue' => $pa['custom_value'],
                    ];
                } elseif (!empty($pa['attribute_value_id'])) {
                    $attributes[] = [
                        'attributeId' => (int) $pa['attribute_id'],
                        'attributeValueId' => (int) $pa['attribute_value_id'],
                    ];
                }
            }

            return [
                'barcode'    => $product['barcode'],
                'title'      => $product['name'],
                'productMainId' => $product['sku'],
                'brandId'    => (int) ($brandMapping['marketplace_brand_id'] ?? 0),
                'categoryId' => (int) ($catMapping['marketplace_category_id'] ?? 0),
                'quantity'   => max(0, (int) $product['stock_qty']),
                'stockCode'  => $product['sku'],
                'dimensionalWeight' => (float) ($product['desi'] ?? 1),
                'description' => $description,
                'currencyType' => 'TRY',
                'listPrice'  => $price['list_price'],
                'salePrice'  => $price['sale_price'],
                'vatRate'    => (int) ($product['tax_rate'] ?? 20),
                // Trendyol ürün açmada zorunlu: satıcının anlaşmalı kargo firması.
                // Pazaryeri ayarlarındaki cargo_company_id kullanılır; girilmemişse
                // 17 = Trendyol Express (çoğu satıcıda varsayılan anlaşma).
                'cargoCompanyId' => (int) ($extraConfig['cargo_company_id'] ?? 17),
                'images'     => $images,
                'attributes' => $attributes,
            ];
        }

        // Hepsiburada formatı (mpop import şeması — HepsiburadaService::createProducts)
        if ($slug === 'hepsiburada') {
            $images = $this->buildImageList($product);

            return [
                'categoryId'     => (int) ($catMapping['marketplace_category_id'] ?? 0),
                'merchant_sku'   => $product['sku'],
                'stockCode'      => $product['sku'],
                'barcode'        => $product['barcode'] ?? '',
                'HepsiburadaSku' => $product['barcode'] ?? '',
                'productName'    => $product['name'],
                'title'          => $product['name'],
                'description'    => $description,
                'price'          => $price['sale_price'],
                'salePrice'      => $price['sale_price'],
                'listPrice'      => $price['list_price'],
                'quantity'       => max(0, (int) $product['stock_qty']),
                'availableStock' => max(0, (int) $product['stock_qty']),
                'vatRate'        => (int) ($product['tax_rate'] ?? 20),
                'images'         => $images,
                // HB kategoriye özel kendi attribute setini ister; sistemdeki
                // Trendyol-ID'li özellikler gönderilmez
                'attributes'     => [],
            ];
        }

        // ÇiçekSepeti formatı (POST /Products şeması)
        if ($slug === 'ciceksepeti') {
            $images = $this->buildImageList($product);

            // NOT: Sistemdeki ürün özellikleri Trendyol ID'leriyle tutulur;
            // ÇiçekSepeti kendi attribute ID/valueId'lerini bekler. Yanlış ID
            // göndermek batch'i reddettirir — bu yüzden özellik gönderilmez.
            // ÇS'de zorunlu (varyant) özellikli kategoriler için özellikler
            // ÇiçekSepeti panelinden tamamlanmalıdır.
            return [
                'productName'         => $product['name'],
                'mainProductCode'     => $product['sku'],
                'stockCode'           => $product['sku'],
                'barcode'             => $product['barcode'] ?? '',
                'categoryId'          => (int) ($catMapping['marketplace_category_id'] ?? 0),
                'description'         => $description,
                'stockQuantity'       => max(0, (int) $product['stock_qty']),
                'salesPrice'          => $price['sale_price'],
                'listPrice'           => $price['list_price'],
                // deliveryType 2 = kargo; deliveryMessageType 5 = "yarın kargoda"
                // (kargolu kategorilerde ÇS yalnız kargo gönderim türünü kabul eder)
                'deliveryType'        => (int) ($extraConfig['delivery_type'] ?? 2),
                'deliveryMessageType' => (int) ($extraConfig['delivery_message_type'] ?? 5),
                'images'              => $images,
                'attributes'          => [],
            ];
        }

        // N11 formatı
        if ($slug === 'n11') {
            $images = $this->buildImageList($product, true);

            $attributes = [];
            $productAttrs = $this->pAttrValueModel->getByProduct((int) $product['id']);
            foreach ($productAttrs as $pa) {
                if (!empty($pa['custom_value'])) {
                    $attributes[] = [
                        'attributeId' => (int) $pa['attribute_id'],
                        'customAttributeValue' => $pa['custom_value'],
                    ];
                } elseif (!empty($pa['attribute_value_id'])) {
                    $attributes[] = [
                        'attributeId' => (int) $pa['attribute_id'],
                        'attributeValueId' => (int) $pa['attribute_value_id'],
                    ];
                }
            }

            return [
                'barcode'         => $product['barcode'] ?? '',
                'title'           => $product['name'],
                'productMainId'   => $product['sku'],
                'categoryId'      => (int) ($catMapping['marketplace_category_id'] ?? 0),
                'quantity'        => max(0, (int) $product['stock_qty']),
                'stockCode'       => $product['sku'],
                'description'     => $description,
                'currencyType'    => 'TL',
                'listPrice'       => $price['list_price'],
                'salePrice'       => $price['sale_price'],
                'vatRate'         => (int) ($product['tax_rate'] ?? 20),
                'images'          => $images,
                'attributes'      => $attributes,
                'preparingDay'    => 3,
                'shipmentTemplate' => '1',
            ];
        }

        // Pazarama formatı
        if ($slug === 'pazarama') {
            $images = $this->buildImageList($product, true);

            // Pazarama attributeId/attributeValueId olarak kendi GUID'lerini bekler.
            // Sistemdeki özellik ID'leri Trendyol kaynaklı sayısal ID'lerdir — bunları
            // göndermek MER_30 (System.Guid çevrilemedi) hatası üretir. Bu yüzden
            // yalnızca GUID formatındaki özellikler gönderilir.
            $attributes = [];
            $productAttrs = $this->pAttrValueModel->getByProduct((int) $product['id']);
            foreach ($productAttrs as $pa) {
                $attrId = (string) ($pa['attribute_id'] ?? '');
                $valueId = (string) ($pa['attribute_value_id'] ?? '');
                $guidRe = '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i';
                if (preg_match($guidRe, $attrId) && preg_match($guidRe, $valueId)) {
                    $attributes[] = [
                        'attributeId'      => $attrId,
                        'attributeValueId' => $valueId,
                    ];
                }
            }

            return [
                'barcode'           => $product['barcode'] ?? '',
                'title'             => $product['name'],
                'productMainId'     => $product['sku'],
                // Pazarama marka/kategori ID'leri GUID'dir — int cast edilirse 0 olur
                'brandId'           => (string) ($brandMapping['marketplace_brand_id'] ?? ''),
                'categoryId'        => (string) ($catMapping['marketplace_category_id'] ?? ''),
                'quantity'          => max(0, (int) $product['stock_qty']),
                'stockCode'         => $product['sku'],
                'description'       => $description,
                'currencyType'      => 'TL',
                'listPrice'         => $price['list_price'],
                'salePrice'         => $price['sale_price'],
                'vatRate'           => (int) ($product['tax_rate'] ?? 20),
                'dimensionalWeight' => (float) ($product['desi'] ?? 1),
                'images'            => $images,
                'attributes'        => $attributes,
            ];
        }

        if ($slug === 'oziygo') {
            $images = $this->buildImageList($product, true);

            return [
                'sku'               => $product['sku'],
                'barcode'           => $product['barcode'],
                'name'              => $product['name'],
                'title'             => $product['name'],
                'description'       => $description,
                'short_description' => $product['short_description'] ?? '',
                'categoryId'        => (string) ($catMapping['marketplace_category_id'] ?? ''),
                'brandId'           => (string) ($brandMapping['marketplace_brand_id'] ?? ''),
                'quantity'          => max(0, (int) $product['stock_qty']),
                'stock'             => max(0, (int) $product['stock_qty']),
                'listPrice'         => $price['list_price'],
                'salePrice'         => $price['sale_price'],
                'price'             => $price['sale_price'],
                'vatRate'           => (int) ($product['tax_rate'] ?? 20),
                'images'            => $images,
            ];
        }

        // Amazon formatı (SP-API Listings Items — PUT /listings/2021-08-01/items/...)
        // ASIN biliniyorsa mevcut ürüne teklif, bilinmiyorsa barkodla eşleştirme denenir.
        if ($slug === 'amazon') {
            $images = $this->buildImageList($product);

            $eslesenTip = trim((string) ($catMapping['marketplace_category_id'] ?? ''));
            $amazonProductType = $eslesenTip !== ''
                ? $eslesenTip
                : (string) ($extraConfig['product_type'] ?? 'PRODUCT');

            // ASIN daha önce eşleşmişse marketplace_products'ta durur; yoksa barkodla denenir
            $asin = '';
            $mpId = (int) ($marketplace['id'] ?? 0);
            if ($mpId > 0) {
                $mevcut = $this->mpProductModel->findByProductAndMarketplace((int) $product['id'], $mpId);
                if ($mevcut !== false) {
                    $asin = (string) ($mevcut['marketplace_product_id'] ?? '');
                }
            }

            return [
                'sku'         => (string) $product['sku'],
                'title'       => (string) $product['name'],
                'barcode'     => (string) ($product['barcode'] ?? ''),
                'asin'        => $asin,
                'brand'       => (string) ($brandMapping['marketplace_brand_name'] ?? ''),
                'price'       => $price['sale_price'],
                'quantity'    => max(0, (int) $product['stock_qty']),
                'currency'    => 'TRY',
                // Amazon'da "kategori" = product type. validateForPublish() kategori
                // eşleştirmesini zorunlu tutuyordu ama burada kullanılmıyordu; artık
                // eşleştirilen değer gönderilir, yoksa mağaza ayarına düşülür.
                'productType' => $amazonProductType,
                'images'      => $images,
            ];
        }

        // PttAVM formatı (POST /api/v1/products/upsert)
        // KDV yalnız 0/1/10/20 olabilir; KDV dahil fiyat gönderildiği için oran > 0 olmalı.
        if ($slug === 'pttavm') {
            $images = $this->buildImageList($product);
            $kdv = (int) ($product['tax_rate'] ?? 20);
            if (!in_array($kdv, [0, 1, 10, 20], true)) {
                $kdv = 20;
            }
            if ($kdv === 0) {
                $kdv = 20; // KDV dahil fiyat gönderiliyor → oran 0 olamaz (PttAVM kuralı)
            }

            return [
                'categoryId'       => (int) ($catMapping['marketplace_category_id'] ?? 0),
                'barcode'          => (string) ($product['barcode'] ?? ''),
                'name'             => mb_substr((string) $product['name'], 0, 200),
                'productCode'      => (string) $product['sku'],
                'brand'            => (string) ($brandMapping['marketplace_brand_name'] ?? ''),
                'priceWithVat'     => $price['sale_price'],
                'vatRate'          => $kdv,
                'quantity'         => max(0, (int) $product['stock_qty']),
                'desi'             => (float) ($product['desi'] ?? 0),
                'shortDescription' => mb_substr(strip_tags((string) ($product['short_description'] ?? $description)), 0, 500),
                'longDescription'  => $description,
                'images'           => $images,
                'active'           => true,
                'cargoProfileId'   => (int) ($extraConfig['cargo_profile_id'] ?? 0),
            ];
        }

        // İdefix formatı (hızlı ürün ekleme — POST /pim/catalog/{vendorId}/fast-listing)
        // Alanlar dokümandaki adlarla birebir: barcode, title, vendorStockCode,
        // price, comparePrice, inventoryQuantity
        if ($slug === 'idefix') {
            return [
                'barcode'           => (string) ($product['barcode'] ?? ''),
                'title'             => (string) $product['name'],
                'vendorStockCode'   => (string) $product['sku'],
                'price'             => $price['sale_price'],
                'comparePrice'      => $price['list_price'] > 0 ? $price['list_price'] : $price['sale_price'],
                'inventoryQuantity' => max(0, (int) $product['stock_qty']),
            ];
        }

        // Gelecek pazaryerleri için generic format
        return [
            'sku'       => $product['sku'],
            'barcode'   => $product['barcode'],
            'name'      => $product['name'],
            'price'     => $price['sale_price'],
            'stock'     => (int) $product['stock_qty'],
        ];
    }

    /**
     * @param array<string, mixed> $product
     * @param array<string, mixed> $meta
     * @return array<string, mixed>
     */
    private function buildMarketplaceProductState(array $product, array $meta): array
    {
        $item = $meta['item'] ?? [];
        $price = $meta['price'] ?? [];
        $catMapping = is_array($meta['category_mapping'] ?? null) ? $meta['category_mapping'] : [];
        $brandMapping = is_array($meta['brand_mapping'] ?? null) ? $meta['brand_mapping'] : [];
        $firstImage = $this->firstImageUrl($item);
        $pendingBatchId = trim((string) ($meta['pending_batch_id'] ?? ''));
        $batchFailure = trim((string) ($meta['batch_failure'] ?? ''));

        return [
            'is_listed'                 => ($pendingBatchId === '' && $batchFailure === '') ? 1 : 0,
            'sync_error'                => $batchFailure !== ''
                ? 'Batch reddedildi: ' . $batchFailure
                : ($pendingBatchId === '' ? null : 'Batch kontrol bekliyor: ' . $pendingBatchId),
            'last_synced_at'            => date('Y-m-d H:i:s'),
            'marketplace_sku'           => (string) ($item['stockCode'] ?? $item['sku'] ?? $product['sku'] ?? ''),
            'marketplace_product_id'    => (string) ($item['productMainId'] ?? $item['id'] ?? $product['sku'] ?? ''),
            'marketplace_barcode'       => (string) ($item['barcode'] ?? $product['barcode'] ?? ''),
            'marketplace_category_id'   => (string) ($catMapping['marketplace_category_id'] ?? $item['categoryId'] ?? ''),
            'marketplace_category_name' => (string) ($catMapping['marketplace_category_name'] ?? ''),
            'marketplace_brand_id'      => (string) ($brandMapping['marketplace_brand_id'] ?? $item['brandId'] ?? ''),
            'marketplace_brand_name'    => (string) ($brandMapping['marketplace_brand_name'] ?? ''),
            'product_name'              => (string) ($item['title'] ?? $product['name'] ?? ''),
            'main_image'                => $firstImage,
            'last_price_sent'           => (float) ($item['salePrice'] ?? $price['sale_price'] ?? $product['base_price'] ?? 0),
            'last_stock_sent'           => (int) ($item['quantity'] ?? $product['stock_qty'] ?? 0),
        ];
    }

    /**
     * @param array<string, mixed> $apiResult
     * @param array<string, mixed> $product
     * @return array<string, string>|null
     */
    private function batchStatusForProduct(array $apiResult, array $product): ?array
    {
        $barcode = trim((string) ($product['barcode'] ?? ''));
        if ($barcode === '') {
            return null;
        }

        $statuses = $apiResult['batch_status_by_barcode'] ?? [];
        if (!is_array($statuses) || !isset($statuses[$barcode]) || !is_array($statuses[$barcode])) {
            return null;
        }

        return $statuses[$barcode];
    }

    /**
     * @return array<string, array<string, string>>
     */
    private function checkBatchStatus(object $marketplaceService, string $batchId): array
    {
        if ($batchId === '' || !method_exists($marketplaceService, 'getBatchStatus')) {
            return [];
        }

        $status = [];
        for ($attempt = 0; $attempt < 4; $attempt++) {
            if ($attempt > 0) {
                usleep(1500000);
            }

            try {
                $status = $marketplaceService->getBatchStatus($batchId);
            } catch (\Throwable $e) {
                return [];
            }

            // Trendyol üst seviye status döner (PROCESSING → COMPLETED);
            // ÇiçekSepeti gibi servislerde üst status yoktur — items geldiyse tamam say
            $topStatus = strtoupper((string) ($status['status'] ?? ''));
            if ($topStatus === 'COMPLETED' || ($topStatus === '' && !empty($status['items']))) {
                break;
            }
        }

        $byBarcode = [];
        foreach (($status['items'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }

            // Trendyol: items[].requestItem.barcode — ÇiçekSepeti: items[].data.barcode
            $requestItem = is_array($item['requestItem'] ?? null) ? $item['requestItem'] : [];
            $requestProduct = is_array($requestItem['product'] ?? null) ? $requestItem['product'] : [];
            $dataItem = is_array($item['data'] ?? null) ? $item['data'] : [];
            $barcode = trim((string) (
                $requestItem['barcode']
                ?? $requestProduct['barcode']
                ?? $dataItem['barcode']
                ?? $item['barcode']
                ?? ''
            ));
            if ($barcode === '') {
                continue;
            }

            $itemStatus = strtoupper((string) ($item['status'] ?? ''));
            $reasons = $item['failureReasons'] ?? [];
            if (is_array($reasons)) {
                $message = implode(', ', array_map(
                    static fn($r) => is_array($r)
                        ? (string) ($r['message'] ?? json_encode($r, JSON_UNESCAPED_UNICODE))
                        : (string) $r,
                    $reasons
                ));
            } else {
                $message = (string) $reasons;
            }
            if ($message === '') {
                $message = $itemStatus === 'SUCCESS' ? 'Batch basarili' : 'Batch kontrol sonucu bekleniyor';
            }

            $byBarcode[$barcode] = [
                'status' => $itemStatus,
                'message' => $message,
            ];
        }

        return $byBarcode;
    }

    /**
     * @param array<string, mixed> $product
     */
    private function productHasImage(array $product): bool
    {
        return !empty($this->buildImageList($product));
    }

    private function requiresPublicImages(string $marketplaceSlug): bool
    {
        return in_array($marketplaceSlug, [
            'trendyol',
            'n11',
            'hepsiburada',
            'pazarama',
            'pttavm',
            'ciceksepeti',
            'idefix',
            'amazon',
        ], true);
    }

    /**
     * @param array<string, mixed> $product
     * @return array<int, string>
     */
    private function findPrivateImageUrls(array $product): array
    {
        $private = [];
        foreach ($this->buildImageList($product) as $image) {
            $url = (string) ($image['url'] ?? '');
            if ($url !== '' && !$this->isPublicHttpUrl($url)) {
                $private[] = $url;
            }
        }

        return $private;
    }

    private function isPublicHttpUrl(string $url): bool
    {
        $parts = parse_url($url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return false;
        }

        $scheme = strtolower((string) $parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return false;
        }

        $host = strtolower((string) $parts['host']);
        if (in_array($host, ['localhost', '127.0.0.1', '::1'], true) || str_ends_with($host, '.local')) {
            return false;
        }

        $ip = filter_var($host, FILTER_VALIDATE_IP);
        if ($ip !== false) {
            return filter_var(
                $ip,
                FILTER_VALIDATE_IP,
                FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
            ) !== false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $product
     * @return array<int, array<string, mixed>>
     */
    private function buildImageList(array $product, bool $withOrder = false): array
    {
        $urls = [];
        $imagesJson = json_decode($product['images_json'] ?? '[]', true);
        if (is_array($imagesJson)) {
            foreach ($imagesJson as $img) {
                $url = is_array($img) ? ($img['url'] ?? ($img['src'] ?? '')) : (string) $img;
                $url = $this->normalizeImageUrl((string) $url);
                if ($url !== '') {
                    $urls[] = $url;
                }
            }
        }

        $mainImage = $this->normalizeImageUrl((string) ($product['main_image'] ?? ''));
        if ($mainImage !== '') {
            array_unshift($urls, $mainImage);
        }

        $urls = array_values(array_unique(array_filter($urls)));
        $images = [];
        foreach ($urls as $i => $url) {
            $entry = ['url' => $url];
            if ($withOrder) {
                $entry['order'] = $i;
            }
            $images[] = $entry;
        }

        return $images;
    }

    private function normalizeImageUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        if (str_starts_with($url, '//')) {
            return 'https:' . $url;
        }

        if (preg_match('~^https?://~i', $url) === 1) {
            return $url;
        }

        $baseUrl = function_exists('app_base_url')
            ? app_base_url()
            : rtrim((string) env('APP_URL', 'http://localhost'), '/');

        $path = ltrim(str_replace('\\', '/', $url), '/');
        if (str_starts_with($path, 'public/')) {
            return rtrim($baseUrl, '/') . '/' . $path;
        }
        if (str_starts_with($path, 'uploads/')) {
            return rtrim($baseUrl, '/') . '/public/' . $path;
        }

        return rtrim($baseUrl, '/') . '/' . $path;
    }

    /**
     * @param array<string, mixed> $item
     */
    private function firstImageUrl(array $item): string
    {
        $images = $item['images'] ?? [];
        if (!is_array($images) || empty($images)) {
            return '';
        }

        $first = reset($images);
        return is_array($first) ? (string) ($first['url'] ?? '') : '';
    }

    /**
     * Sync log kaydı oluştur
     */
    private function logSyncResult(int $marketplaceId, int $success, int $failed, int $skipped, array $errors): void
    {
        $total = $success + $failed + $skipped;
        $status = $failed === 0 ? 'success' : ($success > 0 ? 'partial' : 'failed');

        $errorDetails = !empty($errors) ? json_encode(array_slice($errors, 0, 50), JSON_UNESCAPED_UNICODE) : null;

        $this->syncLogModel->create([
            'marketplace_id'    => $marketplaceId,
            'sync_type'         => 'products_push',
            'status'            => $status,
            'records_fetched'   => $total,
            'records_processed' => $success,
            'records_failed'    => $failed + $skipped,
            'error_details'     => $errorDetails,
            'started_at'        => date('Y-m-d H:i:s'),
            'finished_at'       => date('Y-m-d H:i:s'),
            'triggered_by'      => 'manual',
        ]);
    }
}
