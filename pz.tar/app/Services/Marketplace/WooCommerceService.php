<?php
/**
 * OzyConnect Panel — WooCommerceService (WooCommerce REST API v3 entegrasyonu)
 *
 * Kimlik: mağaza URL (extra_config.store_url) + Consumer Key (api_key_encrypted, ck_…)
 * + Consumer Secret (api_secret_encrypted, cs_…). Auth: query string (?consumer_key=&consumer_secret=)
 * — Authorization header'ı bazı sunucular düşürdüğü için en uyumlu yöntem. Base URL mağaza başına:
 * {store_url}/wp-json/wc/{version}. Sayfalama: page+per_page (X-WP-TotalPages yerine "tam sayfa" sezgisi).
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    1.0.0
 */
declare(strict_types=1);

namespace App\Services\Marketplace;

use App\Core\Logger;
use App\Services\CryptoService;
use App\Models\Marketplace;
use RuntimeException;

final class WooCommerceService extends AbstractMarketplace
{
    private const SLUG = 'woocommerce';

    private string $consumerKey = '';
    private string $consumerSecret = '';
    private string $storeUrl = '';
    private string $apiVersion = 'v3';
    /** @var array<string, mixed> */
    private array $extraConfig = [];
    /** @var array<string, mixed> */
    private array $config;

    private bool $credsLoaded = false;
    /** @var array<string, array{product_id:int, variation_id:int, parent_id:int}>|null SKU → kimlikler (cache) */
    private ?array $skuMap = null;

    public function __construct(
        Logger $logger,
        private readonly CryptoService $crypto,
        private readonly Marketplace $marketplaceModel,
    ) {
        parent::__construct($logger);

        $marketplacesConfig = require BASE_PATH . '/config/marketplaces.php';
        $this->config = $marketplacesConfig[self::SLUG] ?? [];

        $this->apiVersion         = (string) ($this->config['api_version'] ?? 'v3');
        $this->timeout            = $this->config['api']['timeout_seconds'] ?? 30;
        $this->maxRetries         = $this->config['api']['max_retries'] ?? 3;
        $this->retryBaseDelayMs   = $this->config['api']['retry_base_delay_ms'] ?? 1000;
        $this->rateLimitPerSecond = $this->config['api']['rate_limit_per_second'] ?? 3;
    }

    public function loadCredentials(): void
    {
        if ($this->credsLoaded) {
            return;
        }
        $marketplace = $this->marketplaceModel->findBySlug(self::SLUG);
        if ($marketplace === false) {
            throw new RuntimeException('WooCommerce pazaryeri kaydı bulunamadı');
        }
        if (empty($marketplace['api_key_encrypted']) || empty($marketplace['api_secret_encrypted'])) {
            throw new RuntimeException('WooCommerce Consumer Key / Secret henüz girilmemiş');
        }

        $this->consumerKey    = $this->crypto->decrypt($marketplace['api_key_encrypted']);
        $this->consumerSecret = $this->crypto->decrypt($marketplace['api_secret_encrypted']);
        $this->extraConfig    = json_decode($marketplace['extra_config_json'] ?? '{}', true) ?: [];

        $url = trim((string) ($this->extraConfig['store_url'] ?? ''));
        if ($url === '') {
            throw new RuntimeException('WooCommerce mağaza adresi (store_url) girilmemiş');
        }
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        $url = rtrim($url, '/');
        $this->storeUrl    = $url;
        $this->baseUrl     = "{$url}/wp-json/wc/{$this->apiVersion}";
        $this->credsLoaded = true;
    }

    /** ck/cs query-string auth ile tam URL üret. @param array<string,mixed> $params */
    private function url(string $path, array $params = []): string
    {
        $params['consumer_key']    = $this->consumerKey;
        $params['consumer_secret'] = $this->consumerSecret;
        return $this->baseUrl . $path . '?' . http_build_query($params);
    }

    /** Sayfa-tabanlı toplama (per_page dolu geldiği sürece devam). @return array<int,array<string,mixed>> */
    private function paginate(string $path, array $params = [], int $perPage = 100, int $maxPages = 20): array
    {
        $all = [];
        $page = 1;
        do {
            $p = $params;
            $p['per_page'] = $perPage;
            $p['page'] = $page;
            $rows = $this->httpGet($this->url($path, $p));
            $count = 0;
            foreach ($rows as $r) {
                if (is_array($r)) { $all[] = $r; $count++; }
            }
            $page++;
        } while ($count === $perPage && $page <= $maxPages);
        return $all;
    }

    // ═══════════════════════════════════════════════════════
    // BAĞLANTI TESTİ
    // ═══════════════════════════════════════════════════════

    public function testConnection(): array
    {
        try {
            $this->loadCredentials();
            // Yetkili bir uç (auth doğrulaması) — index public olduğu için ürün listesi kullanılır.
            $this->httpGet($this->url('/products', ['per_page' => 1]));
            $name = '';
            try {
                $ss = $this->httpGet($this->url('/system_status'));
                $name = (string) ($ss['environment']['home_url'] ?? '');
            } catch (\Throwable) {
                // system_status yetkisi yoksa sorun değil — bağlantı zaten doğrulandı.
            }
            return [
                'success' => true,
                'message' => $name !== '' ? "WooCommerce bağlantısı başarılı: {$name}" : 'WooCommerce bağlantısı başarılı!',
            ];
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => 'Bağlantı hatası: ' . $e->getMessage()];
        }
    }

    // ═══════════════════════════════════════════════════════
    // SİPARİŞ ÇEKME
    // ═══════════════════════════════════════════════════════

    /** @return array<int, array<string, mixed>> */
    public function fetchOrders(array $filters = []): array
    {
        $this->loadCredentials();
        $params = ['status' => $filters['status'] ?? 'any', 'orderby' => 'date', 'order' => 'asc'];
        if (!empty($filters['after'])) {
            $params['after'] = $filters['after'];
        } else {
            $days = (int) ($filters['days'] ?? ($this->config['api']['order_history_days'] ?? 60));
            if ($days > 0) {
                $params['after'] = date('c', strtotime("-{$days} days"));
            }
        }
        $orders = $this->paginate('/orders', $params, 100, 30);
        $out = [];
        foreach ($orders as $o) {
            $out[] = $this->normalizeOrder($o);
        }
        return $out;
    }

    /** @return array<string, mixed> */
    private function normalizeOrder(array $o): array
    {
        $statusKey = (string) ($o['status'] ?? '');
        $status = $this->config['status_mapping'][$statusKey] ?? 'yeni';

        $bill = $o['billing'] ?? [];
        $ship = $o['shipping'] ?? [];
        // shipping boşsa (dijital ürün vb.) billing'e düş
        $shipName = trim(((string) ($ship['first_name'] ?? '')) . ' ' . ((string) ($ship['last_name'] ?? '')));
        $billName = trim(((string) ($bill['first_name'] ?? '')) . ' ' . ((string) ($bill['last_name'] ?? '')));

        $cargoCompany = (string) (($o['shipping_lines'][0]['method_title'] ?? '') ?: '');
        $trackingNo = '';
        foreach ($o['meta_data'] ?? [] as $m) {
            $k = (string) ($m['key'] ?? '');
            if (in_array($k, ['_tracking_number', '_wc_shipment_tracking_items', 'tracking_number'], true)) {
                $v = $m['value'] ?? '';
                $trackingNo = is_array($v) ? (string) ($v[0]['tracking_number'] ?? '') : (string) $v;
                if ($trackingNo !== '') { break; }
            }
        }

        $items = [];
        $subtotal = 0.0;
        foreach ($o['line_items'] ?? [] as $li) {
            $qty = (int) ($li['quantity'] ?? 0);
            $lineSubtotal = (float) ($li['subtotal'] ?? 0);
            $lineTotal = (float) ($li['total'] ?? 0);
            $unit = $qty > 0 ? $lineSubtotal / $qty : (float) ($li['price'] ?? 0);
            $subtotal += $lineSubtotal;
            $items[] = [
                'marketplace_item_id' => (string) ($li['id'] ?? ''),
                'sku'                 => (string) ($li['sku'] ?? ''),
                'barcode'             => (string) ($li['sku'] ?? ''),
                'name'                => (string) ($li['name'] ?? ''),
                'qty'                 => $qty,
                'unit_price'          => $unit,
                'discount'            => max(0.0, $lineSubtotal - $lineTotal),
                'tax_rate'            => 0.0,
                'line_total'          => $lineTotal,
            ];
        }

        return [
            // Yazma-geri (/orders/{id}) tamsayı id gerektirir; 'number' eklentilerle ('ORD-1001') sapabilir → id öncelikli
            'marketplace_order_id' => (string) ($o['id'] ?? (string) ($o['number'] ?? '')),
            'status'               => $status,
            'customer_name'        => $billName ?: $shipName,
            'customer_email'       => (string) ($bill['email'] ?? ''),
            'customer_phone'       => (string) ($bill['phone'] ?? ''),
            'customer_id_no'       => '',
            'customer_tax_office'  => '',
            'notes'                => (string) ($o['customer_note'] ?? ''),
            'billing_address' => [
                'name'        => $billName,
                'address'     => trim(((string) ($bill['address_1'] ?? '')) . ' ' . ((string) ($bill['address_2'] ?? ''))),
                'city'        => (string) ($bill['state'] ?? $bill['city'] ?? ''),
                'district'    => (string) ($bill['city'] ?? ''),
                'postal_code' => (string) ($bill['postcode'] ?? ''),
                'company'     => (string) ($bill['company'] ?? ''),
                'tax_office'  => '',
                'tax_number'  => '',
            ],
            'shipping_address' => [
                'name'         => $shipName ?: $billName,
                'address'      => trim(((string) ($ship['address_1'] ?? $bill['address_1'] ?? '')) . ' ' . ((string) ($ship['address_2'] ?? $bill['address_2'] ?? ''))),
                'city'         => (string) ($ship['state'] ?? $ship['city'] ?? $bill['state'] ?? ''),
                'district'     => (string) ($ship['city'] ?? $bill['city'] ?? ''),
                'postal_code'  => (string) ($ship['postcode'] ?? $bill['postcode'] ?? ''),
                'phone'        => (string) ($ship['phone'] ?? $bill['phone'] ?? ''),
                'neighborhood' => '',
            ],
            'subtotal'         => $subtotal,
            'tax_total'        => (float) ($o['total_tax'] ?? 0),
            'discount_total'   => (float) ($o['discount_total'] ?? 0),
            'total_amount'     => (float) ($o['total'] ?? 0),
            'cargo_company'    => $cargoCompany,
            'cargo_tracking_no'=> $trackingNo,
            'cargo_sent_at'    => null,
            'ordered_at'       => $this->toMysqlDate($o['date_created_gmt'] ?? null, true) ?? ($this->toMysqlDate($o['date_created'] ?? null) ?? ''),
            'items'            => $items,
            'raw_data'         => $o,
        ];
    }

    public function updateOrderStatus(string $orderId, string $status, array $extra = []): bool
    {
        $this->loadCredentials();
        $id = $this->numericId($orderId);
        if ($id === 0) { return false; }

        $wooStatus = null;
        $s = strtolower($status);
        if (in_array($s, ['cancelled', 'canceled', 'iptal'], true)) {
            $wooStatus = 'cancelled';
        } elseif (in_array($s, ['completed', 'teslim_edildi', 'delivered'], true)) {
            $wooStatus = 'completed';
        } elseif (in_array($s, ['processing', 'hazirlaniyor'], true)) {
            $wooStatus = 'processing';
        } elseif (in_array($s, ['refunded', 'iade'], true)) {
            $wooStatus = 'refunded';
        }
        if ($wooStatus === null) { return true; } // bilinmeyen → no-op (yanlış geçiş yapma)

        try {
            $this->httpPut($this->url("/orders/{$id}"), ['status' => $wooStatus]);
            return true;
        } catch (\Throwable $e) {
            $this->logger->warning('WooCommerce updateOrderStatus hatası: ' . $e->getMessage(), 'MarketplaceAPI', ['order' => $orderId]);
            return false;
        }
    }

    public function updateCargoInfo(string $orderId, string $trackingNo, string $cargoCompany): bool
    {
        $this->loadCredentials();
        $id = $this->numericId($orderId);
        if ($id === 0) { return false; }
        try {
            // Woo core'da kargo takibi yok → meta_data (tracking eklentileri okur) + müşteri notu.
            $this->httpPut($this->url("/orders/{$id}"), [
                'meta_data' => [
                    ['key' => '_tracking_number', 'value' => $trackingNo],
                    ['key' => '_tracking_provider', 'value' => $cargoCompany],
                ],
            ]);
            $this->httpPost($this->url("/orders/{$id}/notes"), [
                'note'          => "Kargo: {$cargoCompany} — Takip No: {$trackingNo}",
                'customer_note' => true,
            ]);
            return true;
        } catch (\Throwable $e) {
            $this->logger->warning('WooCommerce updateCargoInfo hatası: ' . $e->getMessage(), 'MarketplaceAPI', ['order' => $orderId]);
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════
    // ÜRÜN ÇEKME / İÇE AKTARMA
    // ═══════════════════════════════════════════════════════

    /** @return array<string, mixed> */
    public function fetchProducts(int $page = 0, int $size = 100): array
    {
        return $this->importProducts($page, $size);
    }

    /** @return array{products: array, totalPages: int, totalElements: int} */
    public function importProducts(int $page = 0, int $size = 100): array
    {
        $this->loadCredentials();
        $perPage = min(100, max(1, $size));
        $wooPage = $page + 1; // dahili 0-tabanlı → Woo 1-tabanlı
        $products = $this->httpGet($this->url('/products', ['per_page' => $perPage, 'page' => $wooPage, 'status' => 'any']));
        $products = is_array($products) ? $products : [];

        $normalized = [];
        foreach ($products as $p) {
            if (!is_array($p)) { continue; }
            $type = (string) ($p['type'] ?? 'simple');
            if ($type === 'variable') {
                $variations = [];
                try {
                    $pid = (int) ($p['id'] ?? 0);
                    $variations = $this->paginate("/products/{$pid}/variations", [], 100, 5);
                } catch (\Throwable $e) {
                    $this->logger->warning('WooCommerce varyasyon çekilemedi: ' . $e->getMessage(), 'MarketplaceAPI');
                }
                if ($variations === []) {
                    $normalized[] = $this->normalizeImportProduct($p, null);
                } else {
                    foreach ($variations as $v) {
                        $normalized[] = $this->normalizeImportProduct($p, $v);
                    }
                }
            } else {
                $normalized[] = $this->normalizeImportProduct($p, null);
            }
        }

        $hasMore = count($products) === $perPage;
        return [
            'products'      => $normalized,
            'totalPages'    => $hasMore ? $wooPage + 1 : $wooPage,
            'totalElements' => count($normalized),
            'nextPage'      => $hasMore ? $page + 1 : null,
            'done'          => !$hasMore,
        ];
    }

    /** @return array<string, mixed> */
    private function normalizeImportProduct(array $p, ?array $v): array
    {
        $isVar = $v !== null;
        // Varyasyonun kendi görseli (Woo'da tekil 'image' nesnesi) varsa onu kapak yap; yoksa ürün galerisi
        $srcImages = ($isVar && !empty($v['image']['src'])) ? [$v['image']] : ($p['images'] ?? []);
        $images = [];
        foreach ($srcImages as $i => $img) {
            $images[] = ['url' => (string) ($img['src'] ?? ''), 'is_cover' => $i === 0, 'sort' => $i];
        }
        $cat = $p['categories'][0] ?? [];
        // Varyasyon adı: ürün adı + öznitelik değerleri
        $varSuffix = '';
        if ($isVar && !empty($v['attributes'])) {
            $parts = [];
            foreach ($v['attributes'] as $a) { $parts[] = (string) ($a['option'] ?? ''); }
            $parts = array_filter($parts);
            if ($parts !== []) { $varSuffix = ' - ' . implode(' / ', $parts); }
        }

        // ?? iç ternary'yi korumadığı için her alan erişimini tek tek koru
        $sku       = $isVar ? (string) ($v['sku'] ?? '') : (string) ($p['sku'] ?? '');
        $mpId      = $isVar ? (string) ($v['id'] ?? '') : (string) ($p['id'] ?? '');
        $price     = $isVar ? (float) ($v['price'] ?? 0) : (float) ($p['price'] ?? 0);
        $listPrice = $isVar ? (float) ($v['regular_price'] ?? $v['price'] ?? 0) : (float) ($p['regular_price'] ?? $p['price'] ?? 0);
        $stockRaw  = $isVar ? ($v['stock_quantity'] ?? null) : ($p['stock_quantity'] ?? null);

        return [
            'marketplace_sku'        => $sku,
            'marketplace_product_id' => $mpId,
            'barcode'                => $sku,
            'name'                   => (string) ($p['name'] ?? '') . $varSuffix,
            'category_name'          => (string) ($cat['name'] ?? ''),
            'category_id'            => (string) ($cat['id'] ?? ''),
            'brand_name'             => '',
            'brand_id'               => '',
            'price'                  => $price,
            'list_price'             => $listPrice,
            'stock'                  => $stockRaw !== null ? (int) $stockRaw : null,
            'group_id'               => (string) ($p['id'] ?? ''),
            'attributes'             => [],
            'images'                 => $images,
            'raw'                    => $isVar ? ['product' => $p, 'variation' => $v] : ['product' => $p],
        ];
    }

    // ═══════════════════════════════════════════════════════
    // KATEGORİ & MARKA
    // ═══════════════════════════════════════════════════════

    /** @return array<int, array<string, mixed>> */
    public function fetchCategories(int $parentId = 0): array
    {
        $this->loadCredentials();
        $rows = $this->paginate('/products/categories', ['orderby' => 'name', 'order' => 'asc'], 100, 20);
        // Başka kategorinin parent'ı olarak geçen id'ler = yaprak değil (Woo kategorileri hiyerarşik)
        $parents = [];
        foreach ($rows as $c) {
            $pid = (int) ($c['parent'] ?? 0);
            if ($pid > 0) { $parents[$pid] = true; }
        }
        $out = [];
        foreach ($rows as $c) {
            $id = (int) ($c['id'] ?? 0);
            $out[] = [
                'marketplace_category_id' => (string) ($c['id'] ?? ''),
                'name'                    => (string) ($c['name'] ?? ''),
                'parent_id'               => (string) ($c['parent'] ?? '0'),
                'is_leaf'                 => !isset($parents[$id]),
            ];
        }
        return $out;
    }

    /** @return array<int, array<string, mixed>> */
    public function fetchBrands(string $search = ''): array
    {
        $this->loadCredentials();
        // Woo core'da marka yok — "Brands" eklentisi varsa /products/brands döner; yoksa boş.
        try {
            $rows = $this->paginate('/products/brands', ['orderby' => 'name', 'order' => 'asc'], 100, 10);
        } catch (\Throwable) {
            return [];
        }
        $out = [];
        foreach ($rows as $b) {
            $name = (string) ($b['name'] ?? '');
            if ($name === '') { continue; }
            if ($search !== '' && stripos($name, $search) === false) { continue; }
            $out[] = ['mp_brand_id' => (string) ($b['id'] ?? $name), 'name' => $name];
        }
        return $out;
    }

    /** @return array<int, array{id: int, name: string, required: bool, allowCustom: bool, values: array}> */
    public function fetchCategoryAttributes(string $marketplaceCategoryId): array
    {
        return []; // Woo'da öznitelikler kategoriye bağlı değil (global) — kategori bazlı şart yok.
    }

    // ═══════════════════════════════════════════════════════
    // STOK & FİYAT GÖNDERME
    // ═══════════════════════════════════════════════════════

    /** @param array<int, array{barcode?: string, sku?: string, quantity: int}> $items
     *  @return array{success: int, failed: int, errors: array} */
    public function updateStock(array $items): array
    {
        $this->loadCredentials();
        $ok = 0; $fail = 0; $errors = [];
        try {
            $map = $this->getSkuMap();
        } catch (\Throwable $e) {
            return ['success' => 0, 'failed' => count($items), 'errors' => ['WooCommerce stok hazırlık hatası: ' . $e->getMessage()]];
        }
        foreach ($items as $it) {
            $sku = (string) ($it['barcode'] ?? $it['sku'] ?? '');
            $qty = (int) ($it['quantity'] ?? 0);
            $m = $map[$sku] ?? null;
            if ($sku === '' || $m === null) { $fail++; $errors[] = "SKU eşleşmedi: {$sku}"; continue; }
            try {
                if (($m['variation_id'] ?? 0) > 0) {
                    $this->httpPut($this->url("/products/{$m['parent_id']}/variations/{$m['variation_id']}"), ['manage_stock' => true, 'stock_quantity' => $qty]);
                } else {
                    $this->httpPut($this->url("/products/{$m['product_id']}"), ['manage_stock' => true, 'stock_quantity' => $qty]);
                }
                $ok++;
            } catch (\Throwable $e) {
                $fail++; $errors[] = $sku . ': ' . $e->getMessage();
            }
        }
        return ['success' => $ok, 'failed' => $fail, 'errors' => $errors];
    }

    /** @param array<int, array{barcode?: string, sku?: string, salePrice?: float, listPrice?: float}> $items
     *  @return array{success: int, failed: int, errors: array} */
    public function updatePrice(array $items): array
    {
        $this->loadCredentials();
        $ok = 0; $fail = 0; $errors = [];
        try {
            $map = $this->getSkuMap();
        } catch (\Throwable $e) {
            return ['success' => 0, 'failed' => count($items), 'errors' => ['WooCommerce fiyat hazırlık hatası: ' . $e->getMessage()]];
        }
        foreach ($items as $it) {
            $sku = (string) ($it['barcode'] ?? $it['sku'] ?? '');
            $m = $map[$sku] ?? null;
            if ($sku === '' || $m === null) { $fail++; $errors[] = "SKU eşleşmedi: {$sku}"; continue; }
            $sale = (float) ($it['salePrice'] ?? $it['price'] ?? 0);
            $list = (float) ($it['listPrice'] ?? 0);
            $regular = $list > 0 ? $list : $sale;
            // WC v3: atlanan alan değişmeden kalır → sale_price'ı DAİMA gönder; indirim yoksa "" ile eski indirimi temizle
            $body = [
                'regular_price' => (string) $regular,
                'sale_price'    => ($list > 0 && $sale > 0 && $sale < $list) ? (string) $sale : '',
            ];
            try {
                if (($m['variation_id'] ?? 0) > 0) {
                    $this->httpPut($this->url("/products/{$m['parent_id']}/variations/{$m['variation_id']}"), $body);
                } else {
                    $this->httpPut($this->url("/products/{$m['product_id']}"), $body);
                }
                $ok++;
            } catch (\Throwable $e) {
                $fail++; $errors[] = $sku . ': ' . $e->getMessage();
            }
        }
        return ['success' => $ok, 'failed' => $fail, 'errors' => $errors];
    }

    // ═══════════════════════════════════════════════════════
    // İADE (Woo core'da iade API'si yok)
    // ═══════════════════════════════════════════════════════

    /** @return array<int, array<string, mixed>> */
    public function fetchReturns(array $filters = []): array
    {
        return [];
    }

    public function approveReturn(string $returnId): bool { return false; }
    public function rejectReturn(string $returnId, string $reason): bool { return false; }

    // ═══════════════════════════════════════════════════════
    // YARDIMCILAR
    // ═══════════════════════════════════════════════════════

    /** SKU → {product_id, variation_id, parent_id} eşlemesi (ürün+varyasyon taraması, cache). @return array<string, array{product_id:int, variation_id:int, parent_id:int}> */
    private function getSkuMap(): array
    {
        if ($this->skuMap !== null) { return $this->skuMap; }
        $products = $this->paginate('/products', ['status' => 'any'], 100, 20);
        $map = [];
        foreach ($products as $p) {
            $pid = (int) ($p['id'] ?? 0);
            $sku = (string) ($p['sku'] ?? '');
            if ($sku !== '') {
                $map[$sku] = ['product_id' => $pid, 'variation_id' => 0, 'parent_id' => $pid];
            }
            if ((string) ($p['type'] ?? 'simple') === 'variable') {
                try {
                    $vars = $this->paginate("/products/{$pid}/variations", [], 100, 5);
                    foreach ($vars as $v) {
                        $vsku = (string) ($v['sku'] ?? '');
                        if ($vsku !== '') {
                            $map[$vsku] = ['product_id' => $pid, 'variation_id' => (int) ($v['id'] ?? 0), 'parent_id' => $pid];
                        }
                    }
                } catch (\Throwable) {
                    // varyasyon çekilemezse bu ürünü atla
                }
            }
        }
        return $this->skuMap = $map;
    }

    // ═══════════════════════════════════════════════════════
    // WEBHOOK (anlık) — alıcı tarafı
    // ═══════════════════════════════════════════════════════

    /** Webhook payload'ı (tek ham sipariş) → normalize sipariş. @return array<string,mixed> */
    public function normalizeWebhookOrder(array $rawOrder): array
    {
        return $this->normalizeOrder($rawOrder);
    }

    /** WooCommerce webhook imzası: base64(hmac_sha256(rawBody, webhook_secret)) — X-WC-Webhook-Signature. */
    public function verifyWebhookHmac(string $rawBody, string $signatureHeader): bool
    {
        $secret = '';
        try {
            $this->loadCredentials();
            $secret = (string) ($this->extraConfig['webhook_secret'] ?? '');
        } catch (\Throwable) {
            return false;
        }
        if ($secret === '' || $signatureHeader === '') {
            return false;
        }
        $calc = base64_encode(hash_hmac('sha256', $rawBody, $secret, true));
        return hash_equals($calc, $signatureHeader);
    }

    /** ISO8601 → MySQL datetime (Y-m-d H:i:s), sunucu saat dilimine çevirir. GMT alanı ($isGmt=true) UTC kabul edilir
     *  (Woo date_created_gmt TZ eki taşımaz, çıplak strtotime sunucu-yerel sanıp kaydırır). Boş/geçersiz → null. */
    private function toMysqlDate(?string $iso, bool $isGmt = false): ?string
    {
        if ($iso === null || $iso === '') {
            return null;
        }
        try {
            $dt = new \DateTimeImmutable($iso, $isGmt ? new \DateTimeZone('UTC') : null);
            return $dt->setTimezone(new \DateTimeZone(date_default_timezone_get()))->format('Y-m-d H:i:s');
        } catch (\Throwable) {
            $ts = strtotime($iso);
            return $ts !== false ? date('Y-m-d H:i:s', $ts) : null;
        }
    }

    private function numericId(string $id): int
    {
        if (preg_match('/(\d+)/', $id, $m)) { return (int) $m[1]; }
        return (int) $id;
    }
}
