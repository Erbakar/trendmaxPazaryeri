<?php
/**
 * OzyConnect Panel — MarketplaceController
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    1.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Container;
use App\Core\Request;
use App\Models\Marketplace;
use App\Services\CryptoService;
use App\Services\Import\InitialImportService;
use App\Services\Marketplace\TrendyolService;
use App\Services\Marketplace\N11Service;
use App\Services\Marketplace\HepsiburadaService;
use App\Services\Marketplace\PazaramaService;
use App\Services\Marketplace\PttavmService;
use App\Services\Marketplace\CiceksepetiService;
use App\Services\Marketplace\AmazonService;
use App\Services\Marketplace\IdefixService;
use App\Services\Marketplace\OziygoService;
use App\Services\Marketplace\ShopifyService;
use App\Services\Marketplace\WooCommerceService;
use App\Services\Marketplace\OpenCartService;
use App\Services\Marketplace\MarketplacePurgeService;

final class MarketplaceController extends BaseController
{
    private readonly Marketplace $marketplaceModel;
    private readonly CryptoService $crypto;
    private readonly InitialImportService $initialImportService;
    private readonly TrendyolService $trendyolService;
    private readonly N11Service $n11Service;
    private readonly HepsiburadaService $hepsiburadaService;
    private readonly PazaramaService $pazaramaService;
    private readonly PttavmService $pttavmService;
    private readonly CiceksepetiService $ciceksepetiService;
    private readonly AmazonService $amazonService;
    private readonly IdefixService $idefixService;
    private readonly OziygoService $oziygoService;
    private readonly ShopifyService $shopifyService;
    private readonly WooCommerceService $wooCommerceService;
    private readonly OpenCartService $openCartService;

    public function __construct(Container $container)
    {
        parent::__construct($container);
        $this->marketplaceModel    = $container->get(Marketplace::class);
        $this->crypto              = $container->get(CryptoService::class);
        $this->initialImportService = $container->get(InitialImportService::class);
        $this->trendyolService     = $container->get(TrendyolService::class);
        $this->n11Service          = $container->get(N11Service::class);
        $this->hepsiburadaService  = $container->get(HepsiburadaService::class);
        $this->pazaramaService     = $container->get(PazaramaService::class);
        $this->pttavmService       = $container->get(PttavmService::class);
        $this->ciceksepetiService  = $container->get(CiceksepetiService::class);
        $this->amazonService       = $container->get(AmazonService::class);
        $this->idefixService       = $container->get(IdefixService::class);
        $this->oziygoService       = $container->get(OziygoService::class);
        $this->shopifyService      = $container->get(ShopifyService::class);
        $this->wooCommerceService  = $container->get(WooCommerceService::class);
        $this->openCartService     = $container->get(OpenCartService::class);
    }

    /** Aktif mağaza bu pazaryerine YETKİLİ mi? (store_marketplaces entitlement) — yetki yoksa bağlan/test/import yok. */
    private function isEntitled(int $marketplaceId): bool
    {
        return $this->container->get(\App\Services\EntitlementService::class)->canAccessMarketplace($marketplaceId);
    }

    public function index(Request $request): void
    {
        $marketplaces = $this->marketplaceModel->getAllWithStatus();
        $entitledIds  = $this->container->get(\App\Services\EntitlementService::class)->allowedMarketplaceIds();

        // Her pazaryeri için istatistik + mağaza yetkisi (entitlement)
        foreach ($marketplaces as &$mp) {
            $stats = $this->marketplaceModel->getStats((int) $mp['id']);
            $mp['active_products'] = $stats['active_products'];
            $mp['total_orders'] = $stats['total_orders'];
            $mp['monthly_orders'] = $stats['monthly_orders'];
            $mp['entitled'] = in_array((int) $mp['id'], $entitledIds, true);
        }
        unset($mp);

        $this->view('marketplaces.index', [
            'pageTitle'    => 'Pazaryerleri',
            'marketplaces' => $marketplaces,
        ]);
    }

    public function edit(Request $request, string $id): void
    {
        $marketplace = $this->marketplaceModel->find((int) $id);
        if ($marketplace === false) {
            $this->response->notFound('Pazaryeri bulunamadı');
        }

        if (!$this->isEntitled((int) $id)) {
            $this->redirectWithError('/marketplaces', 'Bu pazaryeri paketinizde bulunmuyor; önce eklenti olarak eklenmeli.');
            return;
        }

        $viewData = [
            'pageTitle'   => $marketplace['display_name'] . ' Ayarları',
            'marketplace' => $marketplace,
        ];
        // OpenCart: bağlantı token'ını connector'a yapıştırmak için çöz ve görünüme geçir
        if (($marketplace['slug'] ?? '') === 'opencart' && !empty($marketplace['api_secret_encrypted'])) {
            try { $viewData['opencartToken'] = $this->crypto->decrypt($marketplace['api_secret_encrypted']); }
            catch (\Throwable) { $viewData['opencartToken'] = ''; }
        }
        $this->view('marketplaces.edit', $viewData);
    }

    public function update(Request $request, string $id): void
    {
        $mp = $this->marketplaceModel->find((int) $id);
        if ($mp === false) {
            $this->response->notFound('Pazaryeri bulunamadı');
        }

        if (!$this->isEntitled((int) $id)) {
            $this->redirectWithError('/marketplaces', 'Bu pazaryeri paketinizde bulunmuyor; önce eklenti olarak eklenmeli.');
            return;
        }

        $apiKey    = $request->post('api_key', '');
        $apiSecret = $request->post('api_secret', '');

        $data = [
            'is_active'    => $request->boolean('is_active') ? 1 : 0,
            'display_name' => $request->post('display_name', $mp['display_name']),
        ];

        // Hepsiburada'da API Key yok, sadece şifre (servis anahtarı) var
        if ($mp['slug'] === 'hepsiburada') {
            if ($apiSecret !== '') {
                $data['api_secret_encrypted'] = $this->crypto->encrypt($apiSecret);
            }
        // Shopify: Admin API access token (api_secret) — ayrı API key yok
        } elseif ($mp['slug'] === 'shopify') {
            if ($apiSecret !== '') {
                $data['api_secret_encrypted'] = $this->crypto->encrypt($apiSecret);
            }
            $data['api_key_encrypted'] = null;
        // ÇiçekSepeti / İdefix: Secret opsiyonel, sadece API Key zorunlu
        } elseif ($mp['slug'] === 'pttavm') {
            if ($apiSecret !== '') {
                $data['api_secret_encrypted'] = $this->crypto->encrypt($apiSecret);
            }
            $data['api_key_encrypted'] = null;
        } elseif ($mp['slug'] === 'oziygo') {
            if ($apiKey !== '') {
                $data['api_key_encrypted'] = $this->crypto->encrypt($apiKey);
            }
            $data['api_secret_encrypted'] = null;
        } elseif (in_array($mp['slug'], ['ciceksepeti', 'idefix'], true)) {
            if ($apiKey !== '') {
                $data['api_key_encrypted'] = $this->crypto->encrypt($apiKey);
            }
            if ($apiSecret !== '') {
                $data['api_secret_encrypted'] = $this->crypto->encrypt($apiSecret);
            }
        } elseif ($apiKey !== '' && $apiSecret !== '') {
            $data['api_key_encrypted']    = $this->crypto->encrypt($apiKey);
            $data['api_secret_encrypted'] = $this->crypto->encrypt($apiSecret);
        } elseif ($apiKey !== '' || $apiSecret !== '') {
            // Yalnız biri doldurulduğunda hiçbiri kaydedilmiyor ama kullanıcı
            // "güncellendi" mesajı görüyordu → sonra "bilgiler girilmemiş" hatası.
            $this->redirectWithError(
                '/marketplaces/' . (int) $id . '/edit',
                'API Key ve API Secret alanlarının İKİSİ birden doldurulmalıdır — hiçbiri kaydedilmedi.'
            );
            return;
        }

        // Extra config (supplier_id, merchant_id, price_adjustment vs.)
        $extraConfig = json_decode($mp['extra_config_json'] ?? '{}', true) ?: [];
        $supplierId = $request->post('supplier_id', '');
        if ($supplierId !== '') {
            $extraConfig['supplier_id'] = $supplierId;
        }

        // Hepsiburada Merchant ID
        $merchantId = $request->post('merchant_id', '');
        if ($merchantId !== '') {
            $extraConfig['merchant_id'] = $merchantId;
        }

        if ($mp['slug'] === 'oziygo') {
            $apiUrl = trim($request->post('api_url', ''));
            if ($apiUrl !== '') {
                $extraConfig['api_url'] = rtrim($apiUrl, '/');
            }
        }

        // Hepsiburada Entegratör Kullanıcı Adı
        if ($mp['slug'] === 'hepsiburada') {
            $marketplacesConfig = require BASE_PATH . '/config/marketplaces.php';
            $extraConfig['integrator_username'] = $marketplacesConfig['hepsiburada']['developer_username'] ?? 'oziyweb_dev';
        } else {
            $integratorUsername = $request->post('integrator_username', '');
            if ($integratorUsername !== '') {
                $extraConfig['integrator_username'] = $integratorUsername;
            }
        }

        // Fiyat farkı yüzdesi
        $priceAdj = $request->post('price_adjustment_percent');
        if ($priceAdj !== null && $priceAdj !== '') {
            $extraConfig['price_adjustment_percent'] = (float) $priceAdj;
        } else {
            $extraConfig['price_adjustment_percent'] = 0;
        }

        // Kargo ayarları (Trendyol)
        if ($mp['slug'] === 'trendyol') {
            $extraConfig['ty_cargo_payment']  = $request->boolean('ty_cargo_payment') ? 1 : 0;
            $extraConfig['ty_auto_label']     = $request->boolean('ty_auto_label') ? 1 : 0;

            // ty_default_cargo formda YOK; koşulsuz yazıldığında her kayıtta boşa
            // eziliyordu (sipariş ekranında seçilen varsayılan kargo kayboluyordu).
            $varsayilanKargo = $request->post('ty_default_cargo');
            if ($varsayilanKargo !== null && $varsayilanKargo !== '') {
                $extraConfig['ty_default_cargo']  = $varsayilanKargo;
                $extraConfig['ty_cargo_provider'] = $varsayilanKargo;
            }
        }

        // Pazarama: Satıcı ID + panel adresi (fatura bağlantısı için)
        if ($mp['slug'] === 'pazarama') {
            $saticiId = trim((string) $request->post('seller_id', ''));
            if ($saticiId !== '') {
                $extraConfig['seller_id'] = $saticiId;
            }
            $panelAdresi = trim((string) $request->post('app_url', ''));
            if ($panelAdresi !== '') {
                $extraConfig['app_url'] = rtrim($panelAdresi, '/');
            }
        }

        // PttAVM özel ayarları
        if ($mp['slug'] === 'pttavm') {
            $shopId = $request->post('shop_id', '');
            if ($shopId !== '') {
                $extraConfig['shop_id'] = (int) $shopId;
            }
        }

        // ÇiçekSepeti özel ayarları
        if ($mp['slug'] === 'ciceksepeti') {
            $sellerId = $request->post('seller_id', '');
            if ($sellerId !== '') {
                $extraConfig['seller_id'] = $sellerId;
            }
        }

        // İdefix özel ayarları
        if ($mp['slug'] === 'idefix') {
            $vendorId = $request->post('vendor_id', '');
            if ($vendorId !== '') {
                $extraConfig['vendor_id'] = $vendorId;
            }
        }

        // Shopify mağaza alan adı + webhook ayarları (anlık sipariş)
        if ($mp['slug'] === 'shopify') {
            $shopDomain = trim($request->post('shop_domain', ''));
            if ($shopDomain !== '') {
                $shopDomain = (string) preg_replace('#^https?://#i', '', $shopDomain);
                $extraConfig['shop_domain'] = rtrim($shopDomain, '/');
            }
            $webhookSecret = trim($request->post('webhook_secret', ''));
            if ($webhookSecret !== '') {
                $extraConfig['webhook_secret'] = $webhookSecret;
            }
            // Webhook token yoksa üret (anlık webhook URL'si için)
            if (empty($mp['webhook_token'])) {
                $data['webhook_token'] = bin2hex(random_bytes(16));
            }
        }

        // WooCommerce mağaza adresi + webhook ayarları (anlık sipariş)
        if ($mp['slug'] === 'woocommerce') {
            $storeUrl = trim($request->post('store_url', ''));
            if ($storeUrl !== '') {
                if (!preg_match('#^https?://#i', $storeUrl)) {
                    $storeUrl = 'https://' . $storeUrl;
                }
                $extraConfig['store_url'] = rtrim($storeUrl, '/');
            }
            $webhookSecret = trim($request->post('webhook_secret', ''));
            if ($webhookSecret !== '') {
                $extraConfig['webhook_secret'] = $webhookSecret;
            }
            if (empty($mp['webhook_token'])) {
                $data['webhook_token'] = bin2hex(random_bytes(16));
            }
        }

        // OpenCart connector ayarları (token korumalı DB-direkt köprü)
        if ($mp['slug'] === 'opencart') {
            $connectorUrl = trim($request->post('connector_url', ''));
            if ($connectorUrl !== '') {
                if (!preg_match('#^https?://#i', $connectorUrl)) {
                    $connectorUrl = 'https://' . $connectorUrl;
                }
                $extraConfig['connector_url'] = rtrim($connectorUrl, '/');
            }
            // Bağlantı token'ı yoksa otomatik üret (merchant ozyconnect.php'ye yapıştırır)
            if (empty($mp['api_secret_encrypted'])) {
                $data['api_secret_encrypted'] = $this->crypto->encrypt(bin2hex(random_bytes(20)));
            }
            // Anlık sipariş bildirimi (OpenCart event) tercihleri
            $extraConfig['oc_version'] = (int) $request->post('oc_version', (string) ($extraConfig['oc_version'] ?? 3));
            $extraConfig['oc_instant'] = $request->boolean('oc_instant') ? 1 : 0;
            // Webhook URL'si için token gerekli (anlık bildirim)
            if (empty($mp['webhook_token'])) {
                $data['webhook_token'] = bin2hex(random_bytes(16));
            }
        }

        // Amazon SP-API özel ayarları
        if ($mp['slug'] === 'amazon') {
            $amzSellerId = $request->post('seller_id', '');
            if ($amzSellerId !== '') {
                $extraConfig['seller_id'] = $amzSellerId;
            }
            $amzRefreshToken = $request->post('refresh_token', '');
            if ($amzRefreshToken !== '') {
                $extraConfig['refresh_token'] = $amzRefreshToken;
            }
            $amzAppId = $request->post('app_id', '');
            if ($amzAppId !== '') {
                $extraConfig['app_id'] = $amzAppId;
            }
        }

        $data['extra_config_json'] = json_encode($extraConfig, JSON_UNESCAPED_UNICODE);

        // Bağlantı bilgileri MAĞAZAYA yazılır. (Önceden global `marketplaces` satırına
        // yazılıyordu; bu yüzden bir bayinin girdiği anahtarları TÜM bayiler kullanıyordu.)
        $this->marketplaceModel->saveStoreConfig((int) $id, [
            'is_enabled'           => (bool) $data['is_active'],
            'display_name'         => $data['display_name'] ?? null,
            'extra_config_json'    => $data['extra_config_json'],
        ] + array_intersect_key($data, array_flip([
            'api_key_encrypted',
            'api_secret_encrypted',
            'webhook_token',
        ])));

        // OpenCart anlık sipariş bildirimi: event'i kur/kaldır (en iyi çaba — connector kuruluysa)
        $eventNote = '';
        if ($mp['slug'] === 'opencart') {
            $token  = (string) ($data['webhook_token'] ?? $mp['webhook_token'] ?? '');
            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host   = (string) ($_SERVER['HTTP_HOST'] ?? '');
            $webhookUrl = ($host !== '' && $token !== '') ? "{$scheme}://{$host}/webhooks/opencart/{$token}" : '';
            try {
                if (!empty($extraConfig['oc_instant']) && $webhookUrl !== '') {
                    $this->openCartService->installEvent($webhookUrl, (int) ($extraConfig['oc_version'] ?? 3));
                    $eventNote = ' Anlık sipariş bildirimi kuruldu.';
                } elseif (empty($extraConfig['oc_instant'])) {
                    $this->openCartService->uninstallEvent();
                }
            } catch (\Throwable $e) {
                $eventNote = ' (Anlık bildirim kurulamadı — önce connector\'ı yükleyip "Test Et" yapın: ' . $e->getMessage() . ')';
            }
        }

        $this->redirectWithSuccess('/marketplaces', 'Pazaryeri ayarları güncellendi.' . $eventNote);
    }

    public function testConnection(Request $request, string $id): void
    {
        $mp = $this->marketplaceModel->find((int) $id);
        if ($mp === false) {
            $this->error('Pazaryeri bulunamadı', 404);
        }

        if (!$this->isEntitled((int) $id)) {
            $this->json(['success' => false, 'message' => 'Bu pazaryeri paketinizde bulunmuyor. Abonelik › Eklenti Ekle üzerinden ekleyebilirsiniz.']);
            return;
        }

        $result = match ($mp['slug']) {
            'trendyol'    => $this->trendyolService->testConnection(),
            'n11'         => $this->n11Service->testConnection(),
            'hepsiburada' => $this->hepsiburadaService->testConnection(),
            'pazarama'    => $this->pazaramaService->testConnection(),
            'pttavm'      => $this->pttavmService->testConnection(),
            'ciceksepeti' => $this->ciceksepetiService->testConnection(),
            'amazon'      => $this->amazonService->testConnection(),
            'idefix'      => $this->idefixService->testConnection(),
            'oziygo'      => $this->oziygoService->testConnection(),
            'shopify'     => $this->shopifyService->testConnection(),
            'woocommerce' => $this->wooCommerceService->testConnection(),
            'opencart'    => $this->openCartService->testConnection(),
            default       => ['success' => false, 'message' => 'Bu pazaryeri henüz desteklenmiyor'],
        };

        if ($result['success']) {
            // Bağlantı başarılı olunca pazaryerini aktif et
            $this->marketplaceModel->update((int) $id, [
                'is_active' => 1,
                'last_connected_at' => date('Y-m-d H:i:s'),
            ]);
            
            $result['marketplace_id'] = (int) $id;
            $result['slug'] = $mp['slug'];
            $result['display_name'] = $mp['display_name'] ?? $mp['slug'];
        }

        $this->json($result);
    }

    /**
     * İlk Verileri Çek — Markalar + Kategoriler + Ürünler (tek buton)
     */
    public function initialImport(Request $request, string $id): void
    {
        $mp = $this->marketplaceModel->find((int) $id);
        if ($mp === false) {
            $this->json(['success' => false, 'message' => 'Pazaryeri bulunamadı']);
            return;
        }

        if (!$this->isEntitled((int) $id)) {
            $this->json(['success' => false, 'message' => 'Bu pazaryeri paketinizde bulunmuyor.']);
            return;
        }

        $slug = $mp['slug'] ?? '';
        $userId = $this->session->get('user_id');

        try {
            $result = $this->initialImportService->runFullImport((int) $id, $slug, $userId ? (int) $userId : null);

            $hasErrors = !empty($result['errors']);
            $message = sprintf(
                '%s: %d marka, %d kategori, %d ürün çekildi%s',
                htmlspecialchars($mp['display_name'] ?? $slug),
                $result['brands'],
                $result['categories'],
                $result['products']['created'] + $result['products']['updated'],
                $hasErrors ? ' (bazı hatalar oluştu)' : ''
            );

            $this->json([
                'success' => !$hasErrors,
                'message' => $message,
                'data'    => $result,
            ]);
        } catch (\Throwable $e) {
            $this->json([
                'success' => false,
                'message' => 'Import hatası: ' . $e->getMessage(),
            ]);
        }
    }

    /**
     * Adım adım import — AJAX progress (brands → categories → products → orders → returns → finance)
     */
    /**
     * Pazaryeri verisi silme — ÖNİZLEME.
     *
     * Yalnız sayım yapar, hiçbir şey silmez. Onay penceresi bunu gösterir.
     */
    public function purgePreview(Request $request, string $id): void
    {
        if (!$this->isEntitled((int) $id)) {
            $this->json(['success' => false, 'message' => 'Bu pazaryeri paketinizde bulunmuyor.']);
            return;
        }

        try {
            $servis = $this->container->get(MarketplacePurgeService::class);
            $this->json(['success' => true, 'data' => $servis->preview((int) $id)]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Pazaryeri verisi silme — UYGULA.
     *
     * Parçalı çalışır: süre bütçesi dolunca done=false döner, istemci tekrar
     * çağırır. 9.000 ürünlük bir pazaryeri tek istekte silinemez.
     */
    public function purge(Request $request, string $id): void
    {
        @set_time_limit(0);

        if (!$this->isEntitled((int) $id)) {
            $this->json(['success' => false, 'message' => 'Bu pazaryeri paketinizde bulunmuyor.']);
            return;
        }

        try {
            $servis = $this->container->get(MarketplacePurgeService::class);
            $this->json(['success' => true, 'data' => $servis->run((int) $id, 20.0)]);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function initialImportStep(Request $request, string $id): void
    {
        $mp = $this->marketplaceModel->find((int) $id);
        if ($mp === false) {
            $this->json(['success' => false, 'message' => 'Pazaryeri bulunamadı']);
            return;
        }

        if (!$this->isEntitled((int) $id)) {
            $this->json(['success' => false, 'message' => 'Bu pazaryeri paketinizde bulunmuyor.']);
            return;
        }

        $slug = $mp['slug'] ?? '';
        $step = $request->post('step', 'brands');
        $page = (int) $request->post('page', '0');
        $days = (int) $request->post('days', '0');

        // Uzun süren importlar için timeout kaldır + bellek tavanını yükselt
        // (sipariş/ürün listeleri işlenirken varsayılan 128M yetmiyordu)
        set_time_limit(0);
        @ini_set('memory_limit', '512M');

        try {
            $result = match ($step) {
                'brands' => $this->initialImportService->importBrandsPage((int) $id, $slug, $page),
                'categories' => [
                    'step'    => 'categories',
                    'count'   => $this->initialImportService->importCategories((int) $id, $slug),
                    'next'    => 'products',
                    'nextPage'=> 0,
                    'done'    => false,
                ],
                'products' => $this->initialImportService->importProductPage((int) $id, $slug, $page),
                // Siparişler artık BLOK BLOK çekilir ('page' = blok numarası).
                // Tek istekte 60 günlük çekim zaman/bellek sınırına takılıp 500 veriyordu.
                'orders' => $this->initialImportService->importOrdersBlock((int) $id, $slug, $days, $page)
                    + ['next' => 'returns'],
                'returns' => [
                    'step'    => 'returns',
                    'data'    => $this->initialImportService->importReturns((int) $id, $slug, $days),
                    'next'    => 'questions',
                    'done'    => false,
                ],
                'questions' => [
                    'step'    => 'questions',
                    'data'    => $this->initialImportService->importQuestions((int) $id, $slug, $days),
                    'next'    => null,
                    'done'    => true,
                ],
                default => ['success' => false, 'message' => 'Geçersiz adım'],
            };

            // Ürün adımında tamamlanma kontrolü — sonraki adım orders
            if ($step === 'products') {
                // İmleç tabanlı servisler (Shopify since_id) bir sonraki sayfayı
                // KENDİSİ bildirir; sayfa numarasını +1 artırmak imleci bozar ve
                // ilk sayfadan sonrası hiç çekilemez.
                $serviceSaysDone     = array_key_exists('done', $result) ? (bool) $result['done'] : null;
                $serviceNextPage     = array_key_exists('nextPage', $result) ? $result['nextPage'] : null;
                $emptyOrLastByNumber = (($result['pageSize'] ?? 0) === 0)
                    || (($result['page'] ?? 0) >= (($result['totalPages'] ?? 1) - 1));

                $done = $serviceSaysDone ?? $emptyOrLastByNumber;
                if ($serviceSaysDone === null && $serviceNextPage !== null) {
                    $done = false;
                }

                $result['done'] = $done;
                $result['next'] = $done ? 'orders' : 'products';
                $result['nextPage'] = $done
                    ? null
                    : ($serviceNextPage !== null ? (int) $serviceNextPage : $page + 1);
            }

            $this->json(array_merge(['success' => true], $result));
        } catch (\Throwable $e) {
            $this->json([
                'success' => false,
                'message' => $e->getMessage(),
                'step'    => $step,
            ]);
        }
    }

    /**
     * Amazon OAuth Callback — müşteri yetkilendirme sonrası Amazon buraya yönlendirir
     */
    public function amazonOAuthCallback(Request $request): void
    {
        $authCode = $request->get('spapi_oauth_code', '');
        $state    = $request->get('state', '');
        $error    = $request->get('error', '');

        if ($error !== '') {
            $this->redirectWithError('/marketplaces', 'Amazon yetkilendirme reddedildi: ' . $error);
            return;
        }

        if ($authCode === '') {
            $this->redirectWithError('/marketplaces', 'Amazon yetkilendirme kodu alınamadı');
            return;
        }

        // State doğrula
        $expectedState = $this->session->get('amazon_oauth_state', '');
        if ($expectedState !== '' && $state !== $expectedState) {
            $this->redirectWithError('/marketplaces', 'Amazon OAuth güvenlik doğrulaması başarısız');
            return;
        }

        try {
            // Auth code → refresh_token
            $refreshToken = $this->amazonService->exchangeAuthCode($authCode);

            // DB'ye kaydet
            $mp = $this->marketplaceModel->findBySlug('amazon');
            if ($mp !== false) {
                $extraConfig = json_decode($mp['extra_config_json'] ?? '{}', true) ?: [];
                $extraConfig['refresh_token'] = $refreshToken;
                $this->marketplaceModel->update((int) $mp['id'], [
                    'extra_config_json' => json_encode($extraConfig, JSON_UNESCAPED_UNICODE),
                ]);
            }

            $this->redirectWithSuccess('/marketplaces', 'Amazon yetkilendirme başarılı! Refresh Token kaydedildi.');
        } catch (\Throwable $e) {
            $this->redirectWithError('/marketplaces', 'Amazon token alınamadı: ' . $e->getMessage());
        }
    }
}
