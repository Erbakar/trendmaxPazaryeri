<?php
/**
 * OzyConnect Panel — JobRunner (Faz 6)
 *
 * Bir kuyruk işini ÇALIŞTIRIR. Tenant + entitlement güvenliğinin uygulandığı yer burası:
 *  1. Job'ın store_id'sinden TenantContext KURULUR (worker içinde).
 *  2. ENTITLEMENT doğrulanır: pazaryeri-özel job ise canAccessMarketplace; entitlement
 *     yoksa JobEntitlementException (TERMİNAL → dead, retry edilmez). Per-store job'larda
 *     iç syncAll zaten getActiveForStore ile entitlement-filtreli → revoke edilmiş
 *     pazaryeri senkronize EDİLMEZ.
 *  3. job_type'a göre ilgili servise DISPATCH edilir (Container'dan tembel çözümlenir).
 *  4. finally → TenantContext TEMİZLENİR (uzun ömürlü worker'da tenant SIZINTISI olmaz).
 *
 * @package OzyConnect
 */
declare(strict_types=1);

namespace App\Services\Queue;

use App\Core\Container;
use App\Core\TenantContext;
use App\Services\EntitlementService;
use App\Services\Sync\OrderSyncService;
use App\Services\Sync\ReturnSyncService;
use App\Services\Sync\StockSyncService;
use App\Services\Sync\PriceSyncService;
use App\Services\Sync\QuestionSyncService;
use App\Services\Import\ProductImportService;

final class JobRunner
{
    /** @var array<string, callable(int,array):mixed> Override edilmiş handler'lar (test/özel). */
    private array $handlers = [];

    public function __construct(
        private readonly TenantContext $tenant,
        private readonly EntitlementService $entitlement,
        private readonly Container $container,
    ) {}

    /**
     * Bir job_type için handler'ı değiştir (test/özel kullanım).
     * @param callable(int $storeId, array $job):mixed $handler
     */
    public function registerHandler(string $jobType, callable $handler): void
    {
        $this->handlers[$jobType] = $handler;
    }

    /**
     * Job'ı tenant + entitlement güvenliğiyle çalıştırır.
     *
     * @param array<string,mixed> $job  sync_jobs satırı
     * @return mixed handler dönüşü
     * @throws JobEntitlementException pazaryeri entitlement yoksa (terminal)
     * @throws \Throwable handler hatası (worker retry/backoff uygular)
     */
    public function run(array $job): mixed
    {
        $storeId = (int) ($job['store_id'] ?? 0);
        if ($storeId <= 0) {
            // FAIL-CLOSED: store_id taşımayan job çalıştırılmaz (tenant bağlamı kurulamaz).
            throw new \InvalidArgumentException('Job store_id taşımıyor — tenant bağlamı kurulamaz');
        }
        $jobType       = (string) ($job['job_type'] ?? '');
        $marketplaceId = isset($job['marketplace_id']) && $job['marketplace_id'] !== null
            ? (int) $job['marketplace_id'] : null;

        $this->tenant->setStoreId($storeId);   // ← worker'ın bu işe ait tenant bağlamı
        try {
            // Pazaryeri-özel job → entitlement ZORUNLU. Revoke edilmişse TERMİNAL hata.
            if ($marketplaceId !== null && !$this->entitlement->canAccessMarketplace($marketplaceId)) {
                throw new JobEntitlementException(
                    "store#{$storeId} için pazaryeri#{$marketplaceId} entitlement YOK — job çalıştırılmadı"
                );
            }

            return $this->handlerFor($jobType)($storeId, $job);
        } finally {
            $this->tenant->clear();             // ← ZORUNLU: tenant sızıntısı önleme
        }
    }

    /**
     * job_type → handler. Önce override, yoksa varsayılan (Container'dan servis çözer).
     * @return callable(int,array):mixed
     */
    private function handlerFor(string $jobType): callable
    {
        if (isset($this->handlers[$jobType])) {
            return $this->handlers[$jobType];
        }

        return match ($jobType) {
            'order_sync'    => fn(int $s, array $j) => $this->container->get(OrderSyncService::class)->syncAll('queue'),
            'return_sync'   => fn(int $s, array $j) => $this->container->get(ReturnSyncService::class)->syncAll('queue'),
            'stock_sync'    => fn(int $s, array $j) => $this->container->get(StockSyncService::class)->syncAll('queue'),
            'price_sync'    => fn(int $s, array $j) => $this->container->get(PriceSyncService::class)->syncAll('queue'),
            'question_sync' => fn(int $s, array $j) => $this->container->get(QuestionSyncService::class)->syncAll('queue'),
            'import'        => fn(int $s, array $j) => $this->runImport($j),
            'saas_invoice_earsiv' => fn(int $s, array $j) => $this->container->get(\App\Services\SubscriptionInvoiceService::class)
                ->issue((int) ((json_decode((string) ($j['payload_json'] ?? '{}'), true) ?: [])['invoice_id'] ?? 0)),
            default         => throw new \InvalidArgumentException("Bilinmeyen job_type: {$jobType}"),
        };
    }

    /** Import job'ı: payload'tan marketplace slug/mode okunur (marketplace_id zorunlu). */
    private function runImport(array $job): array
    {
        $mpId = isset($job['marketplace_id']) ? (int) $job['marketplace_id'] : 0;
        if ($mpId <= 0) {
            throw new \InvalidArgumentException('import job marketplace_id taşımalı');
        }
        $payload = [];
        if (!empty($job['payload_json'])) {
            $decoded = json_decode((string) $job['payload_json'], true);
            if (is_array($decoded)) {
                $payload = $decoded;
            }
        }
        $slug = (string) ($payload['slug'] ?? '');
        $mode = (string) ($payload['mode'] ?? 'full');
        if ($slug === '') {
            throw new \InvalidArgumentException('import job payload.slug zorunlu');
        }
        return $this->container->get(ProductImportService::class)
            ->importFromMarketplace($mpId, $slug, $mode)
            ->toArray();
    }
}
