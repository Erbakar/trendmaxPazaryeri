<?php
/**
 * OzyConnect Panel — CategoryMappingController
 * Kategori ↔ pazaryeri kategorisi eşleştirme yönetimi
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    1.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Container;
use App\Core\Request;
use App\Models\CategoryMarketplaceMapping;
use App\Models\Marketplace;
use App\Services\CategoryMappingService;
use App\Services\Marketplace\TrendyolService;
use App\Services\Marketplace\N11Service;
use App\Services\Marketplace\PazaramaService;

final class CategoryMappingController extends BaseController
{
    private readonly CategoryMappingService $categoryMappingService;
    private readonly CategoryMarketplaceMapping $mappingModel;
    private readonly Marketplace $marketplaceModel;
    private readonly TrendyolService $trendyolService;
    private readonly N11Service $n11Service;
    private readonly PazaramaService $pazaramaService;

    public function __construct(Container $container)
    {
        parent::__construct($container);
        $this->categoryMappingService = $container->get(CategoryMappingService::class);
        $this->mappingModel           = $container->get(CategoryMarketplaceMapping::class);
        $this->marketplaceModel       = $container->get(Marketplace::class);
        $this->trendyolService        = $container->get(TrendyolService::class);
        $this->n11Service             = $container->get(N11Service::class);
        $this->pazaramaService        = $container->get(PazaramaService::class);
    }

    /**
     * Eşleştirme listesi
     */
    public function index(Request $request): void
    {
        $marketplaces = $this->marketplaceModel->getActive();
        $marketplaceId = $request->integer('marketplace_id', 0);

        // İlk aktif pazaryerini varsayılan olarak seç
        if ($marketplaceId === 0 && !empty($marketplaces)) {
            $marketplaceId = (int) $marketplaces[0]['id'];
        }

        $categories = [];
        $unmappedCount = 0;

        if ($marketplaceId > 0) {
            $categories = $this->categoryMappingService->getCategoriesWithMappingStatus($marketplaceId);
            $unmappedCount = $this->categoryMappingService->getUnmappedProductCount($marketplaceId);
        }

        // Güven skoru DB'de tutulmaz; satır çizilirken hesaplanır. Böylece şema
        // değişmez ve uyarı elle yapılmış eşleştirmelerde de çalışır.
        $finder = $this->container->get(\App\Services\Mapping\MappingCandidateFinder::class);

        foreach ($categories as $i => $c) {
            $categories[$i]['confidence'] = empty($c['mapping_id'])
                ? null
                : $finder->confidenceFor(
                    (string) ($c['name'] ?? ''),
                    (string) ($c['full_path'] ?? ''),
                    (string) ($c['marketplace_category_name'] ?? '')
                );
        }

        // Katalog neredeyse boşsa hiçbir skorlama iyileştirmesi yardımcı olmaz
        // (ör. ÇiçekSepeti'nin kategori API'si yok, katalog ürünlerden toplanıyor).
        $catalogSize = $marketplaceId > 0
            ? $this->container->get(\App\Models\MarketplaceCategory::class)->countByMarketplace($marketplaceId)
            : 0;

        $this->view('categories.mapping', [
            'pageTitle'      => 'Kategori Eşleştirme',
            'marketplaces'   => $marketplaces,
            'marketplaceId'  => $marketplaceId,
            'categories'     => $categories,
            'unmappedCount'  => $unmappedCount,
            'catalogSize'    => $catalogSize,
            'confidenceSafe' => \App\Services\Mapping\MappingCandidateFinder::CONFIDENCE_SAFE,
        ]);
    }

    /**
     * Eşleştirme kaydet
     */
    public function store(Request $request): void
    {
        $categoryId = $request->integer('category_id');
        $marketplaceId = $request->integer('marketplace_id');
        $mpCategoryId = $request->post('marketplace_category_id', '');
        $mpCategoryName = $request->post('marketplace_category_name', '');
        $mpCategoryPath = $request->post('marketplace_category_path');

        if ($categoryId === 0 || $marketplaceId === 0 || $mpCategoryId === '') {
            if ($request->isAjax()) {
                $this->error('Eksik alanlar');
            }
            $this->redirectWithError('/categories/mapping', 'Eksik alanlar');
        }

        try {
            $this->mappingModel->saveMapping($categoryId, $marketplaceId, $mpCategoryId, $mpCategoryName, $mpCategoryPath);
        } catch (\Throwable $e) {
            if ($request->isAjax()) {
                $this->error($e->getMessage());
            }
            $this->redirectWithError('/categories/mapping?marketplace_id=' . $marketplaceId, 'Hata: ' . $e->getMessage());
        }

        // Kategori özelliklerini de kaydet
        $attributeJson = $request->post('attribute_mapping_json');
        if ($attributeJson !== null && $attributeJson !== '') {
            $mapping = $this->mappingModel->findMapping($categoryId, $marketplaceId);
            if ($mapping !== false) {
                $this->mappingModel->update((int) $mapping['id'], [
                    'attribute_mapping_json' => $attributeJson,
                ]);
            }
        }

        if ($request->isAjax()) {
            $this->success([], 'Eşleştirme kaydedildi');
        }

        $this->redirectWithSuccess('/categories/mapping?marketplace_id=' . $marketplaceId, 'Kategori eşleştirmesi kaydedildi');
    }

    /**
     * Eşleştirme sil
     */
    public function delete(Request $request, int $id): void
    {
        $mapping = $this->mappingModel->find($id);
        if ($mapping === false) {
            $this->redirectWithError('/categories/mapping', 'Eşleştirme bulunamadı');
        }

        $marketplaceId = (int) $mapping['marketplace_id'];
        $this->mappingModel->delete($id);

        if ($request->isAjax()) {
            $this->success([], 'Eşleştirme silindi');
        }

        $this->redirectWithSuccess('/categories/mapping?marketplace_id=' . $marketplaceId, 'Eşleştirme silindi');
    }

    /**
     * AJAX: Trendyol kategori arama
     */
    public function searchTrendyol(Request $request): void
    {
        $marketplaceId = $request->integer('marketplace_id');
        $query = $request->get('q', '');

        $categories = $this->categoryMappingService->searchMarketplaceCategories($marketplaceId, $query);

        $this->success(['categories' => $categories]);
    }

    /**
     * AJAX: Kategori özellikleri (marketplace-aware)
     */
    public function attributes(Request $request, string $categoryId): void
    {
        try {
            $marketplaceId = $request->integer('marketplace_id', 0);
            $slug = '';

            if ($marketplaceId > 0) {
                $mp = $this->marketplaceModel->find($marketplaceId);
                $slug = $mp !== false ? ($mp['slug'] ?? '') : '';
            }

            $attributes = match ($slug) {
                'n11' => $this->n11Service->fetchCategoryAttributes($categoryId),
                'pazarama' => (function () use ($categoryId) {
                    $this->pazaramaService->loadCredentials();
                    return $this->pazaramaService->fetchCategoryAttributes($categoryId);
                })(),
                'ciceksepeti' => [],
                default => (function () use ($categoryId) {
                    $this->trendyolService->loadCredentials();
                    return $this->trendyolService->fetchCategoryAttributes($categoryId);
                })(),
            };

            $this->success(['attributes' => $attributes]);
        } catch (\Throwable $e) {
            $this->error('Özellikler alınamadı: ' . $e->getMessage());
        }
    }
}
