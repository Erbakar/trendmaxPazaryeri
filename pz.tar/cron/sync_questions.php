<?php
// OzyConnect Panel — Cron: Soru & Cevap Senkronizasyonu
// Kullanım: php cron/sync_questions.php
// Crontab: Her 15 dakikada bir
// Faz 6: Mantık QuestionSyncService'e taşındı (cron + kuyruk tek kaynaktan çağırır).
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/public/index.php';

use App\Services\Sync\QuestionSyncService;

$container = $GLOBALS['container'] ?? null;
if ($container === null) {
    echo "[ERROR] Container yüklenemedi\n";
    exit(1);
}

$questionSync = $container->get(QuestionSyncService::class);
$cronRunner   = $container->get(\App\Services\TenantCronRunner::class);
$logger       = $container->get(\App\Core\Logger::class);
$settings     = $container->get(\App\Models\Setting::class);

if (!($settings->get('sync_questions_enabled') ?? true)) {
    echo "[SKIP] Soru senkronizasyonu devre dışı.\n";
    exit(0);
}

echo "[" . date('Y-m-d H:i:s') . "] Soru sync başlıyor (per-store)...\n";

// PER-STORE: her aktif mağaza kendi TenantContext + entitlement'li pazaryerleriyle; izole hata.
$storeResults = $cronRunner->runForActiveStores(static function (int $storeId) use ($questionSync): array {
    return $questionSync->syncAll('cron');
});

$grand = 0;
foreach ($storeResults as $storeId => $sr) {
    if (!($sr['ok'] ?? false)) {
        echo "  store#{$storeId}: [HATA] " . ($sr['error'] ?? '?') . "\n";
        $logger->error("Cron soru sync store#{$storeId}: " . ($sr['error'] ?? '?'), 'Cron');
        continue;
    }
    $storeTotal = array_sum($sr['result'] ?? []);
    foreach (($sr['result'] ?? []) as $slug => $count) {
        echo "  store#{$storeId} {$slug}: {$count} soru\n";
    }
    $grand += $storeTotal;
}
echo "[OK] Toplam {$grand} soru senkronize edildi (" . count($storeResults) . " mağaza).\n";
