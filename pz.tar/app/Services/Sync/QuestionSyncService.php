<?php
/**
 * OzyConnect Panel — QuestionSyncService (Faz 6)
 *
 * Soru & cevap senkronizasyonu. Daha önce cron/sync_questions.php içinde INLINE'dı;
 * Faz 6'da servise taşındı ki hem cron hem KUYRUK (QuestionSyncJob) tek kaynaktan
 * çağırsın. Diğer sync servisleriyle simetrik: FAIL-CLOSED (TenantContext zorunlu) +
 * yalnız ENTITLEMENT'li pazaryerleri (getActiveForStore).
 *
 * @package OzyConnect
 */
declare(strict_types=1);

namespace App\Services\Sync;

use App\Core\Logger;
use App\Core\TenantContext;
use App\Models\Marketplace;
use App\Models\Question;
use App\Services\Marketplace\TrendyolService;
use App\Services\Marketplace\IdefixService;
use App\Services\Marketplace\PazaramaService;
use App\Services\Marketplace\HepsiburadaService;

final class QuestionSyncService
{
    public function __construct(
        private readonly Marketplace $marketplaceModel,
        private readonly Question $questionModel,
        private readonly TrendyolService $trendyolService,
        private readonly IdefixService $idefixService,
        private readonly PazaramaService $pazaramaService,
        private readonly HepsiburadaService $hepsiburadaService,
        private readonly Logger $logger,
        private readonly TenantContext $tenant,
    ) {}

    /**
     * Aktif (entitlement'li) pazaryerlerinden soruları senkronize eder.
     *
     * @return array<string,int>  slug => senkronize edilen soru sayısı
     */
    public function syncAll(string $triggeredBy = 'manual'): array
    {
        $storeId = $this->tenant->currentStoreId();              // FAIL-CLOSED
        $marketplaces = $this->marketplaceModel->getActiveForStore($storeId); // ENTITLEMENT-filtreli
        $result = [];

        foreach ($marketplaces as $mp) {
            $slug = $mp['slug'] ?? '';
            $mpId = (int) $mp['id'];
            try {
                $result[$slug] = match ($slug) {
                    'trendyol'    => $this->syncTrendyol($mpId),
                    'idefix'      => $this->syncIdefix($mpId),
                    'pazarama'    => $this->syncPazarama($mpId),
                    'hepsiburada' => $this->syncHepsiburada($mpId),
                    default       => 0,
                };
            } catch (\Throwable $e) {
                $this->logger->error("Soru sync hatası ({$slug}): " . $e->getMessage(), 'QuestionSync');
                $result[$slug] = 0;
            }
        }
        return $result;
    }

    private function upsert(int $mpId, string $qId, array $data): void
    {
        $existing = $this->questionModel->findByMarketplaceQuestionId($mpId, $qId);
        if ($existing) {
            $this->questionModel->update((int) $existing['id'], $data);
        } else {
            $this->questionModel->create($data);
        }
    }

    private function syncTrendyol(int $mpId): int
    {
        $this->trendyolService->loadCredentials();
        $questions = $this->trendyolService->getQuestions();
        $synced = 0;
        foreach ($questions as $q) {
            $this->upsert($mpId, (string) $q['id'], [
                'marketplace_id'          => $mpId,
                'marketplace_question_id' => (string) $q['id'],
                'marketplace_product_id'  => (string) ($q['productId'] ?? ''),
                'product_name'            => $q['productName'] ?? null,
                'product_image_url'       => $q['productImage'] ?? null,
                'question_text'           => $q['text'] ?? '',
                'question_date'           => isset($q['creationDate'])
                    ? date('Y-m-d H:i:s', (int) ($q['creationDate'] / 1000)) : date('Y-m-d H:i:s'),
                'customer_name'           => $q['customerFirstName'] ?? null,
                'status'                  => !empty($q['answers']) ? 'answered' : 'waiting',
                'answer_text'             => !empty($q['answers']) ? ($q['answers'][0]['text'] ?? null) : null,
                'answer_date'             => !empty($q['answers']) && isset($q['answers'][0]['creationDate'])
                    ? date('Y-m-d H:i:s', (int) ($q['answers'][0]['creationDate'] / 1000)) : null,
                'synced_at'               => date('Y-m-d H:i:s'),
            ]);
            $synced++;
        }
        return $synced;
    }

    private function syncIdefix(int $mpId): int
    {
        $this->idefixService->loadCredentials();
        $questions = $this->idefixService->fetchQuestions();
        $synced = 0;
        foreach ($questions as $q) {
            $qId = (string) ($q['id'] ?? '');
            if ($qId === '') continue;
            $hasAnswer = !empty($q['productQuestionAnswer']);
            $answerText = $hasAnswer ? ($q['productQuestionAnswer'][0]['answerBody'] ?? null) : null;
            $questionDate = $q['createdAt'] ?? null;
            if (is_string($questionDate)) {
                $ts = strtotime($questionDate);
                $questionDate = $ts !== false ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s');
            } else {
                $questionDate = date('Y-m-d H:i:s');
            }
            $this->upsert($mpId, $qId, [
                'marketplace_id'          => $mpId,
                'marketplace_question_id' => $qId,
                'marketplace_product_id'  => '',
                'product_name'            => $q['product'] ?? null,
                'product_image_url'       => null,
                'question_text'           => $q['question'] ?? '',
                'question_date'           => $questionDate,
                'customer_name'           => $q['customerName'] ?? null,
                'status'                  => $hasAnswer ? 'answered' : 'waiting',
                'answer_text'             => $answerText,
                'answer_date'             => $hasAnswer && isset($q['readAt'])
                    ? date('Y-m-d H:i:s', strtotime($q['readAt'])) : null,
                'synced_at'               => date('Y-m-d H:i:s'),
            ]);
            $synced++;
        }
        return $synced;
    }

    private function syncPazarama(int $mpId): int
    {
        $this->pazaramaService->loadCredentials();
        $synced = 0;
        foreach ([0, 1] as $statusFilter) {
            $page = 1;
            $pageSize = 100;
            do {
                $filters = ['page' => $page, 'page_size' => $pageSize];
                if ($statusFilter > 0) $filters['status'] = $statusFilter;
                $questions = $this->pazaramaService->fetchQuestions($filters);
                if (empty($questions)) break;
                foreach ($questions as $q) {
                    $qId = (string) ($q['questionId'] ?? $q['id'] ?? '');
                    if ($qId === '') continue;
                    $answerText = $q['answer'] ?? $q['answerText'] ?? null;
                    $hasAnswer = !empty($answerText);
                    $questionDate = $q['questionDate'] ?? $q['createdDate'] ?? null;
                    if (is_string($questionDate)) { $ts = strtotime($questionDate); $questionDate = $ts !== false ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s'); }
                    else { $questionDate = date('Y-m-d H:i:s'); }
                    $answerDate = $q['answerDate'] ?? $q['answerCreatedDate'] ?? null;
                    if (is_string($answerDate) && $answerDate !== '') { $ts = strtotime($answerDate); $answerDate = $ts !== false ? date('Y-m-d H:i:s', $ts) : null; }
                    else { $answerDate = null; }
                    $this->upsert($mpId, $qId, [
                        'marketplace_id' => $mpId, 'marketplace_question_id' => $qId,
                        'marketplace_product_id' => (string) ($q['productId'] ?? $q['productCode'] ?? ''),
                        'product_name' => $q['productName'] ?? $q['productTitle'] ?? null,
                        'product_image_url' => $q['productImage'] ?? $q['productImageUrl'] ?? null,
                        'question_text' => $q['questionText'] ?? $q['question'] ?? $q['text'] ?? '',
                        'question_date' => $questionDate, 'customer_name' => $q['customerName'] ?? $q['askerName'] ?? null,
                        'status' => $hasAnswer ? 'answered' : 'waiting',
                        'answer_text' => $hasAnswer ? $answerText : null,
                        'answer_date' => $hasAnswer ? $answerDate : null,
                        'synced_at' => date('Y-m-d H:i:s'),
                    ]);
                    $synced++;
                }
                $page++;
            } while (count($questions) >= $pageSize && $page <= 50);
        }
        return $synced;
    }

    private function syncHepsiburada(int $mpId): int
    {
        $this->hepsiburadaService->loadCredentials();
        $synced = 0;
        $offset = 0;
        $limit = 50;
        do {
            $questions = $this->hepsiburadaService->fetchQuestions(['offset' => $offset, 'limit' => $limit]);
            if (empty($questions)) break;
            foreach ($questions as $q) {
                $qId = (string) ($q['id'] ?? $q['questionId'] ?? '');
                if ($qId === '') continue;
                $answerText = $q['answer'] ?? $q['answerText'] ?? null;
                $hasAnswer = !empty($answerText);
                $questionDate = $q['createdDate'] ?? $q['questionDate'] ?? null;
                if (is_string($questionDate) && $questionDate !== '') { $ts = strtotime($questionDate); $questionDate = $ts !== false ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s'); }
                else { $questionDate = date('Y-m-d H:i:s'); }
                $answerDate = $q['answerDate'] ?? null;
                if (is_string($answerDate) && $answerDate !== '') { $ts = strtotime($answerDate); $answerDate = $ts !== false ? date('Y-m-d H:i:s', $ts) : null; }
                else { $answerDate = null; }
                $this->upsert($mpId, $qId, [
                    'marketplace_id' => $mpId, 'marketplace_question_id' => $qId,
                    'marketplace_product_id' => (string) ($q['productId'] ?? ''),
                    'product_name' => $q['productName'] ?? null,
                    'product_image_url' => $q['productImageUrl'] ?? $q['productImage'] ?? null,
                    'question_text' => $q['text'] ?? $q['question'] ?? $q['questionText'] ?? '',
                    'question_date' => $questionDate, 'customer_name' => $q['customerName'] ?? null,
                    'status' => $hasAnswer ? 'answered' : 'waiting',
                    'answer_text' => $hasAnswer ? $answerText : null,
                    'answer_date' => $hasAnswer ? $answerDate : null,
                    'synced_at' => date('Y-m-d H:i:s'),
                ]);
                $synced++;
            }
            $offset += $limit;
        } while (count($questions) >= $limit && $offset < 5000);
        return $synced;
    }
}
