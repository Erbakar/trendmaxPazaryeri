<?php
/**
 * OzyConnect Panel — VariantPublishService
 * Varyantlı ürünleri pazaryerlerine gruplayarak gönderen servis.
 * Mevcut ProductPublishService'den BAĞIMSIZ — onu çağırmaz, bozmaz.
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 */
declare(strict_types=1);

namespace App\Services;

use App\Core\Container;
use App\Core\Database;
use App\Core\Logger;
use App\Models\BrandMarketplaceMapping;
use App\Models\CategoryMarketplaceMapping;
use App\Models\Marketplace;
use App\Models\MarketplaceProduct;
use App\Models\Product;
use App\Models\ProductAttributeValue;
use App\Models\SyncLog;
use RuntimeException;

final class VariantPublishService
{
    private const SLUG_MAP = [
        'trendyol'    => \App\Services\Marketplace\TrendyolService::class,
        'n11'         => \App\Services\Marketplace\N11Service::class,
        'hepsiburada' => \App\Services\Marketplace\HepsiburadaService::class,
        'pazarama'    => \App\Services\Marketplace\PazaramaService::class,
        'ciceksepeti' => \App\Services\Marketplace\CiceksepetiService::class,
        'pttavm'      => \App\Services\Marketplace\PttavmService::class,
        'idefix'      => \App\Services\Marketplace\IdefixService::class,
        'amazon'      => \App\Services\Marketplace\AmazonService::class,
    ];

    public function __construct(
        private readonly Container $container,
        private readonly Database $db,
        private readonly Product $productModel,
        private readonly MarketplaceProduct $mpProductModel,
        private readonly CategoryMarketplaceMapping $catMappingModel,
        private readonly BrandMarketplaceMapping $brandMappingModel,
        private readonly ProductAttributeValue $pAttrValueModel,
        private readonly PriceRuleEngine $priceEngine,
        private readonly SyncLog $syncLogModel,
        private readonly Marketplace $marketplaceModel,
        private readonly Logger $logger,
    ) {}

    /**
     * Ana ürün ID → tüm varyantları çek → pazaryerine gönder
     *
     * @return array{success: bool, sent: int, failed: int, errors: array}
     */
    public function publishVariantGroup(int $parentProductId, int $marketplaceId): array
    {
        $marketplace = $this->marketplaceModel->find($marketplaceId);
        if ($marketplace === false) {
            return $this->fail('Pazaryeri bulunamadı');
        }

        $slug = $marketplace['slug'] ?? '';
        $group = $this->productModel->getVariantGroup($parentProductId);
        $parent = $group['parent'];
        $variants = $group['variants'];

        if ($parent === false) {
            return $this->fail('Ana ürün bulunamadı');
        }

        if ((int) ($parent['has_variants'] ?? 0) !== 1) {
            return $this->fail('Bu ürünün varyantı yok (has_variants=0)');
        }

        if (empty($variants)) {
            return $this->fail('Varyant ürünler bulunamadı');
        }

        // Kategori + marka eşleştirmesi (parent'tan alınır)
        $catMapping = $this->catMappingModel->findMapping((int) ($parent['category_id'] ?? 0), $marketplaceId);
        $brandMapping = $this->brandMappingModel->findMapping((int) ($parent['brand_id'] ?? 0), $marketplaceId);
        if ($catMapping === false) {
            return $this->fail('Kategori pazaryeri eslestirmesi yapilmamis');
        }
        $leafStatus = $this->catMappingModel->getMarketplaceCategoryLeafStatus(
            $marketplaceId,
            (string) ($catMapping['marketplace_category_id'] ?? '')
        );
        if ($leafStatus !== null && !$leafStatus['is_leaf']) {
            $categoryLabel = $leafStatus['full_path'] !== ''
                ? $leafStatus['full_path']
                : ($leafStatus['name'] !== '' ? $leafStatus['name'] : (string) ($catMapping['marketplace_category_id'] ?? ''));
            return $this->fail('Kategori pazaryeri eslestirmesi ara kategoriye bagli. En alt/final kategori secin: ' . $categoryLabel);
        }
        if ($brandMapping === false) {
            return $this->fail('Marka pazaryeri eslestirmesi yapilmamis');
        }

        // Her varyant için fiyat hesapla
        $variantItems = [];
        foreach ($variants as $variant) {
            $price = $this->priceEngine->calculatePrice($variant, $marketplaceId);
            $attrs = $this->pAttrValueModel->getByProduct((int) $variant['id']);

            $variantItems[] = [
                'product'    => $variant,
                'price'      => $price,
                'attributes' => $attrs,
            ];
        }

        // Pazaryerine özel payload oluştur
        $payload = $this->buildVariantGroupPayload(
            $parent, $variantItems, $slug, $catMapping, $brandMapping
        );

        if (empty($payload)) {
            return $this->fail("Pazaryeri '{$slug}' için varyant payload oluşturulamadı");
        }

        // API çağrısı
        $service = $this->resolveService($slug);
        if ($service === null) {
            return $this->fail("Pazaryeri servisi bulunamadı: {$slug}");
        }

        if (!method_exists($service, 'createVariantProducts')) {
            return $this->fail("Pazaryeri '{$slug}' henüz createVariantProducts desteklemiyor");
        }

        try {
            $apiResult = $service->createVariantProducts($payload);
        } catch (\Throwable $e) {
            $this->logger->error("Varyant publish hatası ({$slug}): " . $e->getMessage(), 'VariantPublish');
            return $this->fail('API hatası: ' . $e->getMessage());
        }

        // DB kayıtları güncelle
        $sent = 0;
        $failed = 0;
        if ($apiResult['success'] ?? false) {
            foreach ($variants as $variant) {
                try {
                    $this->mpProductModel->upsertByProductAndMarketplace((int) $variant['id'], $marketplaceId, [
                        'is_listed'               => 1,
                        'sync_error'              => null,
                        'last_synced_at'          => date('Y-m-d H:i:s'),
                        'marketplace_category_id' => $catMapping['marketplace_category_id'] ?? null,
                        'marketplace_brand_id'    => $brandMapping['marketplace_brand_id'] ?? null,
                    ]);
                    $sent++;
                } catch (\Throwable $e) {
                    $failed++;
                    $this->logger->error("Varyant DB hatası (#{$variant['id']}): " . $e->getMessage(), 'VariantPublish');
                }
            }
        } else {
            $failed = count($variants);
        }

        // Sync log
        $this->syncLogModel->create([
            'marketplace_id'    => $marketplaceId,
            'sync_type'         => 'variant_push',
            'status'            => $failed === 0 ? 'success' : ($sent > 0 ? 'partial' : 'failed'),
            'records_fetched'   => count($variants),
            'records_processed' => $sent,
            'records_failed'    => $failed,
            'error_details'     => !empty($apiResult['errors']) ? json_encode($apiResult['errors'], JSON_UNESCAPED_UNICODE) : null,
            'started_at'        => date('Y-m-d H:i:s'),
            'finished_at'       => date('Y-m-d H:i:s'),
            'triggered_by'      => 'manual',
        ]);

        $this->logger->info(
            "Varyant publish tamamlandı ({$slug}): parent=#{$parentProductId}, sent={$sent}, failed={$failed}",
            'VariantPublish'
        );

        return [
            'success' => $sent > 0,
            'sent'    => $sent,
            'failed'  => $failed,
            'errors'  => $apiResult['errors'] ?? [],
        ];
    }

    /**
     * Pazaryerine özel varyant payload oluştur
     *
     * @param array<string, mixed> $parent
     * @param array<int, array{product: array, price: array, attributes: array}> $variantItems
     * @return array<string, mixed>
     */
    private function buildVariantGroupPayload(
        array $parent,
        array $variantItems,
        string $slug,
        array|false $catMapping,
        array|false $brandMapping,
    ): array {
        $groupId = $parent['sku']; // Parent SKU = productMainId / groupCode

        $items = [];
        foreach ($variantItems as $vi) {
            $product = $vi['product'];
            $price = $vi['price'];
            $rawAttrs = $vi['attributes'];

            // Görseller (child'dan, yoksa parent'tan)
            $images = $this->extractImages($product, $parent);

            // Attribute'lar
            $attributes = [];
            foreach ($rawAttrs as $pa) {
                if (!empty($pa['custom_value'])) {
                    $attributes[] = [
                        'attributeId'          => (int) $pa['attribute_id'],
                        'customAttributeValue' => $pa['custom_value'],
                    ];
                } elseif (!empty($pa['attribute_value_id'])) {
                    $attributes[] = [
                        'attributeId'      => (int) $pa['attribute_id'],
                        'attributeValueId' => (int) $pa['attribute_value_id'],
                    ];
                }
            }

            $items[] = [
                'barcode'           => $product['barcode'] ?? '',
                'title'             => $product['name'] ?? $parent['name'],
                'productMainId'     => $groupId,
                'groupCode'         => $groupId,
                'stockCode'         => $product['sku'] ?? $product['barcode'] ?? '',
                'brandId'           => (int) ($brandMapping['marketplace_brand_id'] ?? 0),
                'categoryId'        => (int) ($catMapping['marketplace_category_id'] ?? 0),
                'quantity'          => max(0, (int) ($product['stock_qty'] ?? 0)),
                'description'       => $product['description'] ?? $parent['description'] ?? $parent['name'],
                'currencyType'      => 'TRY',
                'listPrice'         => $price['list_price'] ?? 0,
                'salePrice'         => $price['sale_price'] ?? 0,
                'vatRate'           => (int) ($product['tax_rate'] ?? $parent['tax_rate'] ?? 20),
                'dimensionalWeight' => (float) ($product['desi'] ?? $parent['desi'] ?? 1),
                'images'            => $images,
                'attributes'        => $attributes,
                'preparingDay'      => 3,
                'shipmentTemplate'  => '1',
            ];
        }

        return [
            'slug'        => $slug,
            'groupId'     => $groupId,
            'parentSku'   => $parent['sku'],
            'parentName'  => $parent['name'],
            'categoryId'  => (int) ($catMapping['marketplace_category_id'] ?? 0),
            'brandId'     => (int) ($brandMapping['marketplace_brand_id'] ?? 0),
            'items'       => $items,
        ];
    }

    /**
     * Ürün görsellerini çıkar (child → parent fallback)
     *
     * @return array<int, array{url: string}>
     */
    private function extractImages(array $product, array $parent): array
    {
        $images = [];
        $json = $product['images_json'] ?? $parent['images_json'] ?? '[]';
        $parsed = json_decode($json, true);

        if (is_array($parsed)) {
            foreach ($parsed as $img) {
                $url = $img['url'] ?? ($img['src'] ?? '');
                if ($url !== '') {
                    $images[] = ['url' => $url];
                }
            }
        }

        if (empty($images)) {
            $mainImage = $product['main_image'] ?? $parent['main_image'] ?? '';
            if ($mainImage !== '') {
                $images[] = ['url' => $mainImage];
            }
        }

        return $images;
    }

    /**
     * Marketplace servisini çözümle
     */
    private function resolveService(string $slug): ?object
    {
        $class = self::SLUG_MAP[$slug] ?? null;
        if ($class === null) {
            return null;
        }
        return $this->container->get($class);
    }

    /**
     * Hata döndürme helper
     * @return array{success: false, sent: 0, failed: 0, errors: array}
     */
    private function fail(string $message): array
    {
        return ['success' => false, 'sent' => 0, 'failed' => 0, 'errors' => [['error' => $message]]];
    }
}
