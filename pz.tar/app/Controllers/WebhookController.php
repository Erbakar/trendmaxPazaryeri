<?php
/**
 * OzyConnect Panel — WebhookController (pazaryeri/e-ticaret platform webhook ALICISI)
 *
 * Public + CSRF muaf (sunucu-sunucu). URL: POST /webhooks/{slug}/{token}
 *  - {token}: marketplaces.webhook_token ile eşleşir → pazaryerini bulur.
 *  - Mağaza: o pazaryerine AKTİF yetkili (store_marketplaces) ilk mağaza → tenant set edilir.
 *  - İmza: platforma özgü doğrulanır (Shopify: X-Shopify-Hmac-Sha256, app secret ile).
 *  - orders/* topic → sipariş ANINDA sisteme işlenir (OrderSyncService::ingestWebhookOrder).
 *
 * NOT: Webhook public HTTPS gerektirir → localhost'ta tetiklenmez; canlı sunucuda çalışır.
 *
 * @package OzyConnect
 */
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Logger;
use App\Core\Request;
use App\Core\TenantContext;
use App\Models\Marketplace;
use App\Services\Marketplace\ShopifyService;
use App\Services\Marketplace\WooCommerceService;
use App\Services\Marketplace\OpenCartService;
use App\Services\Sync\OrderSyncService;

final class WebhookController
{
    public function __construct(
        private readonly Database $db,
        private readonly Marketplace $marketplaceModel,
        private readonly OrderSyncService $orderSync,
        private readonly ShopifyService $shopify,
        private readonly WooCommerceService $woocommerce,
        private readonly OpenCartService $opencart,
        private readonly TenantContext $tenant,
        private readonly Logger $logger,
    ) {}

    public function handle(Request $request, string $slug, string $token): void
    {
        $rawBody = file_get_contents('php://input');
        $rawBody = $rawBody === false ? '' : $rawBody;

        // Token → pazaryeri (boş token kabul edilmez)
        $token = trim($token);
        if ($token === '') { $this->respond(404, 'no token'); return; }
        $mp = $this->db->fetchOne(
            "SELECT * FROM marketplaces WHERE slug = :s AND webhook_token = :t AND webhook_token <> '' LIMIT 1",
            ['s' => $slug, 't' => $token]
        );
        if ($mp === false) { $this->respond(404, 'not found'); return; }
        $marketplaceId = (int) $mp['id'];

        // Mağaza: bu pazaryerine aktif yetkili ilk mağaza (tek-bağlantı modeli)
        $storeId = (int) ($this->db->fetchOne(
            "SELECT store_id FROM store_marketplaces
             WHERE marketplace_id = :m AND status = 'active'
               AND (expires_at IS NULL OR expires_at > NOW())
             ORDER BY store_id LIMIT 1",
            ['m' => $marketplaceId]
        )['store_id'] ?? 0);
        if ($storeId === 0) { $this->respond(200, 'no active store'); return; }
        $this->tenant->setStoreId($storeId);

        try {
            if ($slug === 'shopify') {
                $hmac = (string) ($_SERVER['HTTP_X_SHOPIFY_HMAC_SHA256'] ?? '');
                if (!$this->shopify->verifyWebhookHmac($rawBody, $hmac)) {
                    $this->logger->warning('Shopify webhook imza doğrulanamadı', 'Webhook', ['mp' => $marketplaceId]);
                    $this->respond(401, 'bad hmac');
                    return;
                }
                $topic   = (string) ($_SERVER['HTTP_X_SHOPIFY_TOPIC'] ?? '');
                $payload = json_decode($rawBody, true);
                if (is_array($payload) && str_starts_with($topic, 'orders/')) {
                    $normalized = $this->shopify->normalizeWebhookOrder($payload);
                    $this->orderSync->ingestWebhookOrder($marketplaceId, $normalized);
                    $this->logger->info("Shopify webhook işlendi: {$topic} #" . ($normalized['marketplace_order_id'] ?? '?'), 'Webhook', ['store' => $storeId]);
                }
            } elseif ($slug === 'woocommerce') {
                $sig = (string) ($_SERVER['HTTP_X_WC_WEBHOOK_SIGNATURE'] ?? '');
                if (!$this->woocommerce->verifyWebhookHmac($rawBody, $sig)) {
                    $this->logger->warning('WooCommerce webhook imza doğrulanamadı', 'Webhook', ['mp' => $marketplaceId]);
                    $this->respond(401, 'bad signature');
                    return;
                }
                $topic   = (string) ($_SERVER['HTTP_X_WC_WEBHOOK_TOPIC'] ?? '');
                $payload = json_decode($rawBody, true);
                if (is_array($payload) && str_starts_with($topic, 'order')) {
                    $normalized = $this->woocommerce->normalizeWebhookOrder($payload);
                    $this->orderSync->ingestWebhookOrder($marketplaceId, $normalized);
                    $this->logger->info("WooCommerce webhook işlendi: {$topic} #" . ($normalized['marketplace_order_id'] ?? '?'), 'Webhook', ['store' => $storeId]);
                }
            } elseif ($slug === 'opencart') {
                // OpenCart event eklentisi sadece order_id gönderir; auth = URL'deki gizli webhook_token (OC imza üretemez).
                $payload = json_decode($rawBody, true);
                $orderId = (int) ($payload['order_id'] ?? 0);
                if ($orderId > 0) {
                    $normalized = $this->opencart->fetchOrderById($orderId);
                    if ($normalized !== null) {
                        $this->orderSync->ingestWebhookOrder($marketplaceId, $normalized);
                        $this->logger->info("OpenCart webhook işlendi: #" . ($normalized['marketplace_order_id'] ?? $orderId), 'Webhook', ['store' => $storeId]);
                    }
                }
            } else {
                $this->respond(200, 'unsupported slug');
                return;
            }
        } catch (\Throwable $e) {
            $this->logger->error('Webhook işleme hatası: ' . $e->getMessage(), 'Webhook', ['slug' => $slug, 'mp' => $marketplaceId]);
            // Shopify hata kodunda yeniden dener — geçici hatada 500, kalıcıda 200 mantıklı; biz 200 ile yutuyoruz (log var).
        } finally {
            $this->tenant->clear();
        }

        $this->respond(200, 'OK');
    }

    private function respond(int $code, string $body): void
    {
        http_response_code($code);
        header('Content-Type: text/plain; charset=utf-8');
        echo $body;
    }
}
