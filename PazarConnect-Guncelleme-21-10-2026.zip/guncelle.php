<?php
/**
 * PazarConnect — Güncelleme Yardımcısı
 *
 * MEVCUT (canlı) kurulumlar içindir. Veriyi SİLMEZ, tabloları SIFIRLAMAZ.
 * Yalnızca veritabanında eksik kalan şema güncellemelerini uygular.
 *
 * Kullanım:  https://siteniz.com/guncelle.php?anahtar=XXXX
 * Bittiğinde bu dosyayı sunucudan SİLİN.
 */
declare(strict_types=1);

const GUNCELLE_ANAHTAR = '48e31cd7bb34543c';

ini_set('display_errors', '1');
error_reporting(E_ALL);
set_time_limit(0);
header('Content-Type: text/html; charset=utf-8');

/* ── Anahtar denetimi ────────────────────────────────────────────────── */
if (!hash_equals(GUNCELLE_ANAHTAR, (string) ($_GET['anahtar'] ?? ''))) {
    http_response_code(403);
    exit('<!doctype html><meta charset="utf-8"><p style="font:15px system-ui;padding:24px">Erişim anahtarı geçersiz.</p>');
}

function installer_split_sql(string $sql): array
{
    $statements = [];
    $buffer = '';
    $length = strlen($sql);
    $inSingle = $inDouble = $inBacktick = $inLineComment = $inBlockComment = false;

    for ($i = 0; $i < $length; $i++) {
        $char = $sql[$i];
        $next = $i + 1 < $length ? $sql[$i + 1] : '';

        if ($inLineComment) {
            $buffer .= $char;
            if ($char === "\n") {
                $inLineComment = false;
            }
            continue;
        }
        if ($inBlockComment) {
            $buffer .= $char;
            if ($char === '*' && $next === '/') {
                $buffer .= $next;
                $i++;
                $inBlockComment = false;
            }
            continue;
        }
        if ($inSingle) {
            $buffer .= $char;
            if ($char === '\\' && $next !== '') {
                $buffer .= $next;
                $i++;
            } elseif ($char === "'") {
                $inSingle = false;
            }
            continue;
        }
        if ($inDouble) {
            $buffer .= $char;
            if ($char === '\\' && $next !== '') {
                $buffer .= $next;
                $i++;
            } elseif ($char === '"') {
                $inDouble = false;
            }
            continue;
        }
        if ($inBacktick) {
            $buffer .= $char;
            if ($char === '`') {
                $inBacktick = false;
            }
            continue;
        }

        if ($char === '-' && $next === '-') {
            $inLineComment = true;
            $buffer .= $char;
            continue;
        }
        if ($char === '#') {
            $inLineComment = true;
            $buffer .= $char;
            continue;
        }
        if ($char === '/' && $next === '*') {
            $inBlockComment = true;
            $buffer .= $char;
            continue;
        }
        if ($char === "'") {
            $inSingle = true;
            $buffer .= $char;
            continue;
        }
        if ($char === '"') {
            $inDouble = true;
            $buffer .= $char;
            continue;
        }
        if ($char === '`') {
            $inBacktick = true;
            $buffer .= $char;
            continue;
        }
        if ($char === ';') {
            $statement = trim($buffer);
            if ($statement !== '') {
                $statements[] = $statement;
            }
            $buffer = '';
            continue;
        }
        $buffer .= $char;
    }

    $statement = trim($buffer);
    if ($statement !== '') {
        $statements[] = $statement;
    }

    return $statements;
}

function installer_execute_sql_file(PDO $pdo, string $path): int
{
    if (!is_file($path) || !is_readable($path)) {
        throw new RuntimeException('SQL dosyası okunamadı: ' . basename($path));
    }

    $sql = file_get_contents($path);
    if ($sql === false) {
        throw new RuntimeException('SQL dosyası yüklenemedi: ' . basename($path));
    }

    $count = 0;
    foreach (installer_split_sql($sql) as $statement) {
        $pdo->exec($statement);
        $count++;
    }
    return $count;
}


/* ── .env oku ────────────────────────────────────────────────────────── */
function guncelle_env(string $kok): array
{
    $yol = $kok . '/.env';
    if (!is_file($yol)) {
        throw new RuntimeException('.env dosyası bulunamadı: ' . $yol);
    }
    $out = [];
    foreach (file($yol, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $satir) {
        $satir = trim($satir);
        if ($satir === '' || str_starts_with($satir, '#')) { continue; }
        $p = strpos($satir, '=');
        if ($p === false) { continue; }
        $k = trim(substr($satir, 0, $p));
        $v = trim(substr($satir, $p + 1));
        if (strlen($v) > 1 && ($v[0] === '"' || $v[0] === "'") && $v[strlen($v) - 1] === $v[0]) {
            $v = substr($v, 1, -1);
        }
        $out[$k] = $v;
    }
    return $out;
}

/* ── Migration listesi — installer.php ile AYNI kurallar ─────────────── */
function guncelle_liste(string $kok): array
{
    $dosyalar = [];
    $legacyToExecute = [
        'create_support_tickets_tables.sql',
        'create_app_updates_tables.sql',
        'signup_password.sql',
    ];
    foreach (glob($kok . '/database/migrations/*.{sql,php}', GLOB_BRACE) ?: [] as $path) {
        if (basename($path) === '_guard.php') { continue; }
        $dosyalar[] = [
            'key'  => 'database/migrations/' . basename($path),
            'path' => $path,
            'mode' => in_array(basename($path), $legacyToExecute, true)
                ? 'execute'
                : (basename($path) === 'create_question_canned_responses_table.php' ? 'question_table' : 'baseline'),
        ];
    }
    foreach (glob($kok . '/migrations/*.{sql,php}', GLOB_BRACE) ?: [] as $path) {
        $dosyalar[] = ['key' => 'migrations/' . basename($path), 'path' => $path, 'mode' => 'baseline'];
    }
    usort($dosyalar, static fn(array $a, array $b): int => strnatcasecmp($a['key'], $b['key']));

    $fazlar = glob($kok . '/database/migrations/phase*', GLOB_ONLYDIR) ?: [];
    usort($fazlar, static function (string $a, string $b): int {
        preg_match('/phase(\d+)$/', str_replace('\\', '/', $a), $ma);
        preg_match('/phase(\d+)$/', str_replace('\\', '/', $b), $mb);
        return ((int) ($ma[1] ?? 0)) <=> ((int) ($mb[1] ?? 0));
    });
    foreach ($fazlar as $faz) {
        $f = glob($faz . '/*.sql') ?: [];
        natsort($f);
        foreach ($f as $path) {
            $dosyalar[] = [
                'key'  => 'database/migrations/' . basename($faz) . '/' . basename($path),
                'path' => $path,
                'mode' => 'execute',
            ];
        }
    }
    return $dosyalar;
}

$kok = __DIR__;
$hataMesaji = '';
$rapor = [];
$uygulandi = [];
$basarisiz = [];
$uygulaModu = ($_POST['islem'] ?? '') === 'uygula';

try {
    $env = guncelle_env($kok);
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        $env['DB_HOST'] ?? 'localhost',
        (int) ($env['DB_PORT'] ?? 3306),
        $env['DB_NAME'] ?? ($env['DB_DATABASE'] ?? '')
    );
    $pdo = new PDO($dsn, $env['DB_USER'] ?? ($env['DB_USERNAME'] ?? 'root'), $env['DB_PASS'] ?? ($env['DB_PASSWORD'] ?? ''), [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `schema_migrations` (
            `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
            `filename` varchar(255) NOT NULL,
            `checksum` char(64) NOT NULL,
            `applied_at` datetime NOT NULL DEFAULT current_timestamp(),
            `duration_ms` int(10) UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            UNIQUE KEY `filename` (`filename`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $mevcut = array_flip($pdo->query('SELECT filename FROM schema_migrations')->fetchAll(PDO::FETCH_COLUMN));
    foreach (guncelle_liste($kok) as $m) {
        if (isset($mevcut[$m['key']])) { continue; }
        $rapor[] = $m;
    }

    if ($uygulaModu && $rapor !== []) {
        $kayit = $pdo->prepare('INSERT INTO schema_migrations (filename, checksum, duration_ms) VALUES (:filename, :checksum, :duration)');
        foreach ($rapor as $m) {
            $basla = microtime(true);
            try {
                if ($m['mode'] === 'execute') {
                    installer_execute_sql_file($pdo, $m['path']);
                } elseif ($m['mode'] === 'question_table') {
                    $pdo->exec(
                        "CREATE TABLE IF NOT EXISTS `question_canned_responses` (
                            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                            `store_id` INT UNSIGNED NOT NULL,
                            `title` VARCHAR(120) NOT NULL,
                            `body` TEXT NOT NULL,
                            `sort_order` INT NOT NULL DEFAULT 0,
                            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            PRIMARY KEY (`id`),
                            KEY `idx_qcr_store` (`store_id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                    );
                }
                $kayit->execute([
                    'filename' => $m['key'],
                    'checksum' => hash_file('sha256', $m['path']),
                    'duration' => (int) round((microtime(true) - $basla) * 1000),
                ]);
                $uygulandi[] = $m['key'];
            } catch (Throwable $e) {
                $basarisiz[] = ['key' => $m['key'], 'hata' => $e->getMessage()];
            }
        }
    }
} catch (Throwable $e) {
    $hataMesaji = $e->getMessage();
}

$e = static fn($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PazarConnect — Güncelleme</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#f8fafc;color:#0f172a;font:15px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
.k{max-width:860px;margin:40px auto;padding:0 20px}
.kart{background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin-bottom:16px}
h1{font-size:22px;margin:0 0 6px}
h2{font-size:16px;margin:0 0 12px}
p{margin:0 0 12px;color:#475569}
.uyari{background:#fffbeb;border-color:#fcd34d}
.hata{background:#fef2f2;border-color:#fecaca;color:#b91c1c}
.ok{background:#ecfdf5;border-color:#a7f3d0;color:#047857}
ul{margin:0;padding-left:20px}
li{font-family:ui-monospace,Consolas,monospace;font-size:13px;margin:2px 0}
.btn{display:inline-block;border:0;background:#2563eb;color:#fff;font:600 15px/1 inherit;
  padding:14px 22px;border-radius:8px;cursor:pointer}
.btn:hover{background:#1d4ed8}
.rozet{display:inline-block;background:#eff6ff;color:#2563eb;border-radius:999px;
  padding:2px 10px;font-size:12px;font-weight:600;margin-left:6px}
</style></head><body><div class="k">

<h1>PazarConnect — Güncelleme</h1>
<p>Bu araç veriyi silmez. Yalnızca veritabanında eksik kalan şema güncellemelerini uygular.</p>

<?php if ($hataMesaji !== ''): ?>
  <div class="kart hata"><h2>Bağlantı hatası</h2><p><?= $e($hataMesaji) ?></p>
  <p>.env dosyasındaki veritabanı bilgilerini kontrol edin.</p></div>

<?php elseif ($uygulaModu): ?>
  <?php if ($uygulandi !== []): ?>
    <div class="kart ok"><h2>✓ <?= count($uygulandi) ?> güncelleme uygulandı</h2>
    <ul><?php foreach ($uygulandi as $u): ?><li><?= $e($u) ?></li><?php endforeach; ?></ul></div>
  <?php endif; ?>
  <?php if ($basarisiz !== []): ?>
    <div class="kart hata"><h2>✕ <?= count($basarisiz) ?> güncelleme uygulanamadı</h2>
    <ul><?php foreach ($basarisiz as $b): ?><li><?= $e($b['key']) ?> — <?= $e($b['hata']) ?></li><?php endforeach; ?></ul>
    <p>Bu listeyi bize iletin; geri kalan güncellemeler uygulandı, sistem çalışır durumda.</p></div>
  <?php endif; ?>
  <?php if ($uygulandi === [] && $basarisiz === []): ?>
    <div class="kart ok"><h2>✓ Zaten güncel</h2><p>Uygulanacak yeni güncelleme yok.</p></div>
  <?php endif; ?>
  <div class="kart uyari"><h2>Son adım</h2>
  <p><b>guncelle.php</b> dosyasını sunucudan silin. İşlem tamamlandı.</p></div>

<?php elseif ($rapor === []): ?>
  <div class="kart ok"><h2>✓ Veritabanı zaten güncel</h2>
  <p>Uygulanacak eksik güncelleme bulunmadı. Dosyaları kopyaladıysanız işlem tamamdır.</p></div>
  <div class="kart uyari"><p><b>guncelle.php</b> dosyasını sunucudan silin.</p></div>

<?php else: ?>
  <div class="kart"><h2>Uygulanacak güncellemeler <span class="rozet"><?= count($rapor) ?> adet</span></h2>
  <p>Aşağıdakiler veritabanınızda eksik. Hiçbiri veri silmez; tablo ve sütun ekler.</p>
  <ul><?php foreach ($rapor as $m): ?>
    <li><?= $e($m['key']) ?><?= $m['mode'] === 'baseline' ? ' (yalnızca kayıt)' : '' ?></li>
  <?php endforeach; ?></ul></div>
  <div class="kart">
    <h2>Başlamadan önce</h2>
    <p>Hosting panelinizden <b>veritabanı yedeği</b> alın. İşlem birkaç saniye sürer.</p>
    <form method="post"><input type="hidden" name="islem" value="uygula">
    <button class="btn" type="submit">Güncellemeleri uygula</button></form>
  </div>
<?php endif; ?>

</div></body></html>
