<?php
/** Mağaza girişi — kurumsal tema split (site_auth layout). Form sözleşmesi (action/name/_csrf) DEĞİŞMEZ. */
$e = static fn($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
$csrf    = $data['_csrf'] ?? ($_csrf ?? '');
$flash   = $data['_flash'] ?? ($_flash ?? []);
$error   = $flash['error'] ?? '';
$success = $flash['success'] ?? '';
$siteName = brand('site_name');
$logo    = trim((string) brand('logo_url', ''));
$shot    = asset('img/login.png');
?>
<style>
/* "Ana sayfaya dön" + logo alt alta (yan yana değil) */
.auth2 .auth2-back{display:flex;width:fit-content;}
.auth2 .auth2-brand{display:flex;}
</style>
<div class="auth2">
  <!-- Form -->
  <div class="auth2-form-side">
    <div class="auth2-card">
      <?php if (!empty($publicSiteEnabled)): ?>
      <a href="<?= url('/') ?>" class="auth2-back"><i data-lucide="arrow-left"></i> Ana sayfaya dön</a>
      <?php endif; ?>

      <div class="auth2-brand">
        <?php if ($logo !== ''): ?>
          <img src="<?= $e($logo) ?>" alt="<?= $e($siteName) ?>">
        <?php else: ?>
          <span class="auth2-brand-mark"><?= $e(mb_substr($siteName, 0, 1)) ?></span>
          <span class="auth2-brand-name"><?= $e($siteName) ?></span>
        <?php endif; ?>
      </div>

      <h1 class="auth2-title">Hesabınıza giriş yapın</h1>
      <p class="auth2-sub">Sipariş, kargo, iade ve fatura akışını yönetmek için bilgilerinizle oturum açın.</p>

      <?php if ($success !== ''): ?>
      <div class="auth2-alert auth2-alert-ok" style="margin-top:22px"><i data-lucide="check-circle"></i><span><?= $e($success) ?></span></div>
      <?php endif; ?>
      <?php if ($error !== ''): ?>
      <div class="auth2-alert auth2-alert-error" style="margin-top:22px"><i data-lucide="alert-triangle"></i><span><?= $e($error) ?></span></div>
      <?php endif; ?>

      <form method="POST" action="<?= url('/login') ?>" id="loginForm" class="auth2-form">
        <input type="hidden" name="_csrf_token" value="<?= $e($csrf) ?>">

        <div class="auth2-field">
          <label class="auth2-label" for="emailInput">E-posta adresi</label>
          <div class="auth2-input-wrap">
            <i data-lucide="mail"></i>
            <input type="email" id="emailInput" name="email" class="auth2-input" placeholder="ornek@firma.com" autocomplete="email" required autofocus>
          </div>
        </div>

        <div class="auth2-field">
          <label class="auth2-label" for="pwInput">Şifre</label>
          <div class="auth2-input-wrap">
            <i data-lucide="lock"></i>
            <input type="password" id="pwInput" name="password" class="auth2-input" placeholder="Şifrenizi girin" autocomplete="current-password" required>
            <button type="button" class="auth2-toggle" id="pwToggle" aria-label="Şifreyi göster"><i data-lucide="eye" id="pwIcon"></i></button>
          </div>
        </div>

        <div class="auth2-meta">
          <label class="auth2-remember"><input type="checkbox" name="remember" value="1"><span>Beni hatırla</span></label>
          <a href="<?= url('/password/forgot') ?>">Şifremi unuttum</a>
        </div>

        <button type="submit" class="auth2-submit" id="loginBtn"><i data-lucide="log-in"></i> Giriş Yap</button>
      </form>

      <p class="auth2-foot">
        Hesabınız yok mu? <a href="<?= url('/magaza-olustur') ?>">Mağaza oluşturun</a><br>
        Güvenli oturum, oran sınırlama ve CSRF koruması ile korunmaktadır.
      </p>
    </div>
  </div>

  <!-- Visual -->
  <aside class="auth2-visual" aria-hidden="true">
    <div class="auth2-visual-inner">
      <div class="auth2-shot">
        <div class="auth2-shot-bar"><span class="b-dot r"></span><span class="b-dot y"></span><span class="b-dot g"></span></div>
        <img src="<?= $e($shot) ?>" alt="<?= $e($siteName) ?> Panel">
      </div>
      <h2>Tüm Pazaryerleri Tek Panelde</h2>
      <p>Trendyol, Hepsiburada, Amazon, n11, Pazarama, PttAVM, ÇiçekSepeti ve İdefix akışını tek operasyon ekranında yönetin.</p>
      <div class="auth2-visual-badges">
        <span class="auth2-visual-badge"><i data-lucide="shield-check"></i> AES-256 Şifreleme</span>
        <span class="auth2-visual-badge"><i data-lucide="zap"></i> %99.9 Uptime</span>
        <span class="auth2-visual-badge"><i data-lucide="refresh-cw"></i> 7/24 Sync</span>
      </div>
    </div>
  </aside>
</div>

<script>
(function(){
  var f = document.getElementById('loginForm'), btn = document.getElementById('loginBtn');
  var pw = document.getElementById('pwInput'), tg = document.getElementById('pwToggle'), ic = document.getElementById('pwIcon');
  if (tg) tg.addEventListener('click', function(){
    var show = pw.type === 'password';
    pw.type = show ? 'text' : 'password';
    tg.setAttribute('aria-label', show ? 'Şifreyi gizle' : 'Şifreyi göster');
    ic.setAttribute('data-lucide', show ? 'eye-off' : 'eye');
    if (window.lucide) lucide.createIcons();
  });
  if (f) f.addEventListener('submit', function(){
    btn.disabled = true;
    btn.innerHTML = '<i data-lucide="loader-circle" style="width:16px;height:16px;animation:a2spin 1s linear infinite"></i> Giriş yapılıyor...';
    if (window.lucide) lucide.createIcons({ nodes: [btn] });
  });
})();
</script>
