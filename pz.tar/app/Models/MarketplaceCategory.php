<?php
declare(strict_types=1);

namespace App\Models;

/**
 * Pazaryeri Kategori Cache — Her pazaryerinden çekilen kategorileri saklar
 */
final class MarketplaceCategory extends BaseModel
{
    protected string $table = 'marketplace_categories';
    protected bool $tenantScoped = false; // GLOBAL referans (D2): platform kategori katalogu

    /**
     * Pazaryeri + kategori ID ile bul
     */
    public function findByMpCatId(int $marketplaceId, string $mpCategoryId): array|false
    {
        return $this->rawQueryOne(
            "SELECT * FROM marketplace_categories WHERE marketplace_id = :mid AND mp_category_id = :cid LIMIT 1",
            ['mid' => $marketplaceId, 'cid' => $mpCategoryId]
        );
    }

    /**
     * Pazaryeri kategorisini kaydet veya güncelle (upsert)
     */
    public function upsert(int $marketplaceId, string $mpCategoryId, string $name, ?string $parentMpId = null, ?string $fullPath = null, bool $isLeaf = false): int
    {
        $existing = $this->findByMpCatId($marketplaceId, $mpCategoryId);

        if ($existing !== false) {
            $this->update((int)$existing['id'], [
                'name'         => $name,
                'parent_mp_id' => $parentMpId,
                'full_path'    => $fullPath,
                'is_leaf'      => $isLeaf ? 1 : 0,
                'synced_at'    => date('Y-m-d H:i:s'),
            ]);
            return (int)$existing['id'];
        }

        return $this->create([
            'marketplace_id' => $marketplaceId,
            'mp_category_id' => $mpCategoryId,
            'name'           => $name,
            'parent_mp_id'   => $parentMpId,
            'full_path'      => $fullPath,
            'is_leaf'        => $isLeaf ? 1 : 0,
        ]);
    }

    /**
     * Pazaryerindeki tüm kategorileri getir
     */
    public function getAllByMarketplace(int $marketplaceId): array
    {
        return $this->rawQuery(
            "SELECT * FROM marketplace_categories WHERE marketplace_id = :mid ORDER BY name ASC",
            ['mid' => $marketplaceId]
        );
    }

    /**
     * İsimle arama (fuzzy — LIKE ile, birden çok pazaryeri destekli)
     */
    /**
     * Arama cümlesini anlamlı kelimelere ayır.
     *
     * Kelime bulunamazsa cümlenin tamamı tek terim olarak kullanılır.
     *
     * @return array<int, string>
     */
    private function searchPool(string $name): array
    {
        $parcalar = preg_split('/[^\p{L}\p{N}]+/u', trim($name), -1, PREG_SPLIT_NO_EMPTY) ?: [];

        $kelimeler = array_values(array_unique(array_filter(
            $parcalar,
            static fn(string $t): bool => mb_strlen($t) > 2
        )));

        // En fazla 6 kelime — sorgu şişmesin
        return $kelimeler === [] ? [trim($name)] : array_slice($kelimeler, 0, 6);
    }

    public function searchByName(string $name, ?int $marketplaceId = null, bool $leafOnly = true): array
    {
        // Cümlenin tamamını aramak yerine KELİMELERİ ara: "Kalem ve Yazı
        // Gereçleri" sorgusu bugün hiçbir sonuç vermiyordu çünkü hiçbir
        // pazaryeri kategorisi bu cümlenin tamamını içermez.
        $kelimeler = $this->searchPool($name);

        $kosullar = [];
        $params = [];
        foreach ($kelimeler as $i => $kelime) {
            $kosullar[] = "mc.name LIKE :k{$i}";
            $params["k{$i}"] = '%' . $kelime . '%';
        }

        $sql = "SELECT mc.*, m.slug as marketplace_slug, m.display_name as marketplace_name
                FROM marketplace_categories mc
                JOIN marketplaces m ON mc.marketplace_id = m.id
                WHERE (" . implode(' OR ', $kosullar) . ")";

        if ($marketplaceId !== null) {
            $sql .= " AND mc.marketplace_id = :mid";
            $params['mid'] = $marketplaceId;
        }

        if ($leafOnly) {
            $sql .= " AND mc.is_leaf = 1";
        }

        $sql .= " ORDER BY mc.name ASC LIMIT 300";

        return $this->rawQuery($sql, $params);
    }

    /**
     * Tam isim eşleşmesi (case-insensitive, belirli pazaryeri)
     */
    public function findExactMatch(string $name, int $marketplaceId, bool $leafOnly = true): array|false
    {
        $sql = "SELECT * FROM marketplace_categories
                WHERE LOWER(name) = LOWER(:name) AND marketplace_id = :mid";
        if ($leafOnly) {
            $sql .= " AND is_leaf = 1";
        }
        $sql .= " LIMIT 1";

        return $this->rawQueryOne($sql, ['name' => $name, 'mid' => $marketplaceId]);
    }

    /**
     * Belirli pazaryerideki toplam kategori sayısı
     */
    public function countByMarketplace(int $marketplaceId): int
    {
        $row = $this->rawQueryOne(
            "SELECT COUNT(*) as cnt FROM marketplace_categories WHERE marketplace_id = :mid",
            ['mid' => $marketplaceId]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public function deleteByMarketplace(int $marketplaceId): int
    {
        $stmt = $this->db->query(
            "DELETE FROM marketplace_categories WHERE marketplace_id = :mid",
            ['mid' => $marketplaceId]
        );
        return $stmt->rowCount();
    }

    /**
     * Paginated search with mapping status — for marketplace tab listing
     * @return array{items: array, total: int}
     */
    public function paginatedWithMappingStatus(
        int $marketplaceId,
        string $search = '',
        bool $leafOnly = false,
        int $page = 1,
        int $perPage = 50
    ): array {
        $offset = ($page - 1) * $perPage;

        $where = 'mc.marketplace_id = :mid';
        $params = ['mid' => $marketplaceId];

        if ($search !== '') {
            $where .= ' AND mc.name LIKE :q';
            $params['q'] = '%' . $search . '%';
        }
        if ($leafOnly) {
            $where .= ' AND mc.is_leaf = 1';
        }

        $countRow = $this->db->fetchOne(
            "SELECT COUNT(*) as cnt FROM marketplace_categories mc WHERE {$where}", $params
        );
        $total = (int)($countRow['cnt'] ?? 0);

        $items = $this->db->fetchAll(
            "SELECT mc.*,
                    cmm.id as mapping_id,
                    cmm.category_id as system_category_id,
                    c.name as system_category_name
             FROM marketplace_categories mc
             LEFT JOIN category_marketplace_mapping cmm
                 ON mc.mp_category_id = cmm.marketplace_category_id AND cmm.marketplace_id = mc.marketplace_id
             LEFT JOIN categories c ON cmm.category_id = c.id
             WHERE {$where}
             ORDER BY mc.name ASC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return ['items' => $items, 'total' => $total];
    }

    /**
     * Tree listing: root veya belirli parent'ın children'ları (mapping status ile)
     * Paginated for performance — correlated subquery replaced with LEFT JOIN aggregation
     */
    public function treeList(int $marketplaceId, ?string $parentMpId = null, string $search = '', int $page = 1, int $perPage = 100): array
    {
        $where = 'mc.marketplace_id = :mid';
        $params = ['mid' => $marketplaceId];

        if ($search !== '') {
            $where .= ' AND mc.name LIKE :q';
            $params['q'] = '%' . $search . '%';
        } else {
            if ($parentMpId === null) {
                $where .= ' AND (mc.parent_mp_id IS NULL OR mc.parent_mp_id = "")';
            } else {
                $where .= ' AND mc.parent_mp_id = :pid';
                $params['pid'] = $parentMpId;
            }
        }

        $countRow = $this->db->fetchOne(
            "SELECT COUNT(*) as cnt FROM marketplace_categories mc WHERE {$where}", $params
        );
        $total = (int)($countRow['cnt'] ?? 0);

        $offset = ($page - 1) * $perPage;

        $items = $this->db->fetchAll(
            "SELECT mc.*,
                    cmm.id as mapping_id,
                    cmm.category_id as system_category_id,
                    c.name as system_category_name,
                    IFNULL(cc.child_count, 0) as child_count
             FROM marketplace_categories mc
             LEFT JOIN category_marketplace_mapping cmm
                 ON mc.mp_category_id = cmm.marketplace_category_id AND cmm.marketplace_id = mc.marketplace_id
             LEFT JOIN categories c ON cmm.category_id = c.id
             LEFT JOIN (
                 SELECT marketplace_id, parent_mp_id, COUNT(*) as child_count
                 FROM marketplace_categories
                 WHERE marketplace_id = :mid_cc
                 GROUP BY marketplace_id, parent_mp_id
             ) cc ON cc.marketplace_id = mc.marketplace_id AND cc.parent_mp_id = mc.mp_category_id
             WHERE {$where}
             ORDER BY mc.name ASC
             LIMIT {$perPage} OFFSET {$offset}",
            array_merge($params, ['mid_cc' => $marketplaceId])
        );

        return [
            'items' => $items,
            'total' => $total,
            'page'  => $page,
            'per_page' => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }
}
