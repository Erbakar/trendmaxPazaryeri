<?php
/**
 * OzyConnect Panel — HepsiburadaService (Hepsiburada API Entegrasyonu)
 *
 * SIT (Test) ortamı hazır. Canlıya geçişte config/marketplaces.php'deki
 * URL'lerden "-sit" kaldırılması yeterlidir.
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    2.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Services\Marketplace;

use App\Core\Logger;
use App\Services\CryptoService;
use App\Models\Marketplace;
use RuntimeException;

final class HepsiburadaService extends AbstractMarketplace
{
    /** Katalog detay haritası disk önbelleği ömrü (saniye) */
    private const CATALOG_CACHE_TTL = 3600;


    private const SLUG = 'hepsiburada';

    private string $apiSecret = '';
    private string $merchantId = '';
    private string $integratorUsername = '';
    /** @var array<string, mixed> */
    private array $extraConfig = [];

    /** @var array<string, mixed> */
    private array $config;

    /** @var array<string, array<string, mixed>> */
    private array $orderDetailCache = [];

    /** @var array<string, string> Modül bazlı base URL'ler */
    private array $baseUrls = [];

    /** @var string 'sit' veya 'production' */
    private string $environment = 'sit';

    /** Listeleme yüklemesi sonucu için azami sorgu denemesi */
    private const UPLOAD_POLL_ATTEMPTS = 5;

    /** Yükleme durumu sorguları arası bekleme (ms) */
    private const UPLOAD_POLL_DELAY_MS = 2000;

    /** Yükleme hâlâ işleniyor anlamına gelen durumlar (boşluk/tire temizlenmiş) */
    private const UPLOAD_PENDING_STATES = ['NEW', 'PROCESSING', 'INPROGRESS', 'WAITING', 'PENDING', 'QUEUED', 'STARTED', 'RUNNING'];

    /** Yükleme başarısız anlamına gelen durumlar */
    private const UPLOAD_FAILED_STATES = ['FAILED', 'FAIL', 'ERROR', 'REJECTED', 'CANCELLED'];

    public function __construct(
        Logger $logger,
        private readonly CryptoService $crypto,
        private readonly Marketplace $marketplaceModel,
    ) {
        parent::__construct($logger);

        $marketplacesConfig = require BASE_PATH . '/config/marketplaces.php';
        $this->config = $marketplacesConfig[self::SLUG] ?? [];

        // Ortam seçimi (sit = test, production = canlı)
        $this->environment = $this->config['environment'] ?? 'sit';

        // Ortama göre base URL'leri belirle
        $urlKey = $this->environment === 'production' ? 'base_urls_production' : 'base_urls_sit';
        $this->baseUrls = $this->config[$urlKey] ?? $this->config['base_urls'] ?? [];

        $this->baseUrl             = $this->baseUrls['catalog'] ?? $this->config['base_url'] ?? 'https://mpop-sit.hepsiburada.com';
        $this->timeout             = $this->config['api']['timeout_seconds'] ?? 60;
        $this->maxRetries          = $this->config['api']['max_retries'] ?? 3;
        $this->retryBaseDelayMs    = $this->config['api']['retry_base_delay_ms'] ?? 1000;
        $this->rateLimitPerSecond  = $this->config['api']['rate_limit_per_second'] ?? 5;
    }

    /**
     * Mevcut ortamı döndür ('sit' veya 'production')
     */
    public function getEnvironment(): string
    {
        return $this->environment;
    }

    /**
     * API bilgilerini veritabanından yükle
     */
    public function loadCredentials(): void
    {
        $marketplace = $this->marketplaceModel->findBySlug(self::SLUG);
        if ($marketplace === false) {
            throw new RuntimeException('Hepsiburada pazaryeri kaydı bulunamadı');
        }

        if (empty($marketplace['api_secret_encrypted'])) {
            throw new RuntimeException('Hepsiburada şifresi (Servis Anahtarı) henüz girilmemiş');
        }

        $this->apiSecret = $this->crypto->decrypt($marketplace['api_secret_encrypted']);

        $this->extraConfig = json_decode($marketplace['extra_config_json'] ?? '{}', true) ?: [];
        $this->merchantId = (string) ($this->extraConfig['merchant_id'] ?? '');
        $this->integratorUsername = (string) (
            $this->config['developer_username']
            ?? $this->extraConfig['integrator_username']
            ?? 'oziyweb_dev'
        );

        if ($this->merchantId === '') {
            throw new RuntimeException('Hepsiburada Merchant ID (Mağaza ID) girilmemiş');
        }

        if ($this->integratorUsername === '') {
            throw new RuntimeException('Hepsiburada Entegratör Kullanıcı Adı girilmemiş');
        }
    }

    /**
     * Auth header'ı oluştur (Basic Auth)
     *
     * HB dokümantasyonu: Username = MerchantId, Password = SecretKey
     * User-Agent = Developer Username (entegratör kullanıcı adı)
     *
     * @return array<int, string>
     */
    private function authHeaders(): array
    {
        $token = base64_encode($this->merchantId . ':' . $this->apiSecret);
        return [
            "Authorization: Basic {$token}",
            "User-Agent: {$this->integratorUsername}",
            "Accept: application/json",
            "Content-Type: application/json",
        ];
    }

    /**
     * Modüle göre base URL al
     */
    private function getBaseUrl(string $module = 'catalog'): string
    {
        return $this->baseUrls[$module] ?? $this->baseUrl;
    }

    /**
     * Endpoint URL'ini oluştur
     */
    private function buildUrl(string $endpoint, string $module = 'catalog'): string
    {
        $path = str_replace('{merchantId}', $this->merchantId, $endpoint);
        return $this->getBaseUrl($module) . $path;
    }

    // ═══════════════════════════════════════════════════════
    // BAĞLANTI TESTİ
    // ═══════════════════════════════════════════════════════

    public function testConnection(): array
    {
        try {
            $this->loadCredentials();

            // Doğrudan curl ile test — hata detaylarını yakalamak için
            $url = $this->getBaseUrl('listing')
                 . '/listings/merchantid/' . $this->merchantId . '?offset=0&limit=1';

            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4, // flaky IPv6 DNS'i bypass et (Could not resolve host)
                CURLOPT_HTTPHEADER     => $this->authHeaders(),
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($response === false) {
                return [
                    'success' => false,
                    'message' => 'Bağlantı hatası: ' . $curlError,
                ];
            }

            // Başarılı
            if ($httpCode >= 200 && $httpCode < 300) {
                return [
                    'success' => true,
                    'message' => 'Hepsiburada bağlantısı başarılı! (Ortam: ' . strtoupper($this->environment) . ')',
                ];
            }

            // HB hata mesajını parse et
            $body = json_decode((string) $response, true);
            $hbMessage = $body['message'] ?? $body['error'] ?? (string) $response;

            // 401/403 = auth reddedildi
            if ($httpCode === 401 || $httpCode === 403) {
                return [
                    'success' => false,
                    'message' => 'Kimlik doğrulama başarısız (' . $httpCode . '). '
                        . 'HB yanıtı: ' . $hbMessage . ' — '
                        . 'Entegratör kullanıcı adı ve servis anahtarını kontrol edin. '
                        . 'Not: Yeni entegratör yetkilendirmesi 2 saate kadar sürebilir.',
                ];
            }

            // 5xx = sunucu hatası
            if ($httpCode >= 500) {
                return [
                    'success' => false,
                    'message' => 'Hepsiburada SIT sunucusu geçici olarak hata döndürdü (' . $httpCode . '). '
                        . 'Yanıt: ' . $hbMessage . ' — Lütfen birkaç dakika sonra tekrar deneyin.',
                ];
            }

            return [
                'success' => false,
                'message' => 'Beklenmeyen yanıt (' . $httpCode . '): ' . $hbMessage,
            ];

        } catch (\Throwable $e) {
            return [
                'success' => false,
                'message' => 'Bağlantı hatası: ' . $e->getMessage(),
            ];
        }
    }

    // ═══════════════════════════════════════════════════════
    // SİPARİŞ İŞLEMLERİ
    // ═══════════════════════════════════════════════════════

    public function fetchOrders(array $filters = []): array
    {
        $this->loadCredentials();

        $allOrders = [];
        $limit = max(1, (int) ($filters['limit'] ?? $this->config['api']['page_size'] ?? 100));

        $endTs = !empty($filters['end_date']) ? strtotime((string) $filters['end_date']) : time();
        if ($endTs === false) {
            $endTs = time();
        }

        $days = max(1, (int) ($filters['timespan'] ?? 30));
        $startTs = !empty($filters['begin_date'])
            ? strtotime((string) $filters['begin_date'])
            : strtotime("-{$days} days", $endTs);
        if ($startTs === false) {
            $startTs = strtotime("-30 days", $endTs);
        }

        $scopes = [
            ['key' => 'orders', 'endpoint' => '/orders/merchantid/{merchantId}', 'status' => 'Open', 'date_filter' => false],
            ['key' => 'packages', 'endpoint' => '/packages/merchantid/{merchantId}', 'status' => 'Packaged', 'date_filter' => true],
            ['key' => 'packages_unpacked', 'endpoint' => '/packages/merchantid/{merchantId}/status/unpacked', 'status' => 'UnPacked', 'date_filter' => true],
            ['key' => 'packages_shipped', 'endpoint' => '/packages/merchantid/{merchantId}/shipped', 'status' => 'Shipped', 'date_filter' => false],
            ['key' => 'packages_delivered', 'endpoint' => '/packages/merchantid/{merchantId}/delivered', 'status' => 'Delivered', 'date_filter' => false],
            ['key' => 'packages_undelivered', 'endpoint' => '/packages/merchantid/{merchantId}/undelivered', 'status' => 'UnDelivered', 'date_filter' => false],
            ['key' => 'orders_cancelled', 'endpoint' => '/orders/merchantid/{merchantId}/cancelled', 'status' => 'Cancelled', 'date_filter' => false],
        ];

        foreach ($this->buildHbDateWindows($startTs, $endTs) as $window) {
            foreach ($scopes as $scope) {
                if (($scope['date_filter'] ?? true) === false) {
                    continue;
                }

                $endpoint = $this->config['endpoints'][$scope['key']] ?? $scope['endpoint'];

                try {
                    $orders = $this->fetchOrdersPaginated(
                        $endpoint,
                        $limit,
                        $window['begin'],
                        $window['end'],
                        $scope['status'],
                        $startTs,
                        $endTs
                    );
                    array_push($allOrders, ...$orders);
                } catch (\Throwable $e) {
                    $this->logger->warning(
                        "HB siparis kapsami atlandi: {$scope['key']} - {$e->getMessage()}",
                        'HepsiburadaService',
                        ['endpoint' => $endpoint, 'begin' => $window['begin'], 'end' => $window['end']]
                    );
                }
            }
        }

        foreach ($scopes as $scope) {
            if (($scope['date_filter'] ?? true) !== false) {
                continue;
            }

            $endpoint = $this->config['endpoints'][$scope['key']] ?? $scope['endpoint'];

            try {
                $orders = $this->fetchOrdersPaginated(
                    $endpoint,
                    $limit,
                    null,
                    null,
                    $scope['status'],
                    $startTs,
                    $endTs
                );
                array_push($allOrders, ...$orders);
            } catch (\Throwable $e) {
                $this->logger->warning(
                    "HB siparis kapsami atlandi: {$scope['key']} - {$e->getMessage()}",
                    'HepsiburadaService',
                    ['endpoint' => $endpoint, 'begin' => date('Y-m-d', $startTs), 'end' => date('Y-m-d', $endTs)]
                );
            }
        }

        return $this->deduplicateHbOrders($allOrders);


    }

    /**
     * Siparişleri sayfalanmış şekilde çek
     */
    private function fetchOrdersPaginated(
        string $endpoint,
        int $limit,
        ?string $beginDate,
        ?string $endDate,
        ?string $status,
        ?int $filterStartTs = null,
        ?int $filterEndTs = null
    ): array
    {
        $allOrders = [];
        $offset = 0;
        $this->startPaging('hb.orders');

        do {
            $queryParams = [
                'offset' => $offset,
                'limit'  => $limit,
            ];

            if ($beginDate !== null && $endDate !== null) {
                $queryParams['begindate'] = $beginDate;
                $queryParams['enddate'] = $endDate;
            }

            $url = $this->buildUrl($endpoint, 'order') . '?' . http_build_query($queryParams);

            $response = $this->httpGet($url, $this->authHeaders());
            $items = $this->extractHbItems($response);

            if (empty($items)) {
                $totalCount = (int) ($response['totalCount'] ?? $response['totalElements'] ?? $response['total'] ?? 0);
                if ($totalCount > 0) {
                    $this->logger->warning(
                        "HB siparis sayfasi bos geldi fakat toplam kayit var",
                        'HepsiburadaService',
                        ['endpoint' => $endpoint, 'offset' => $offset, 'limit' => $limit, 'totalCount' => $totalCount]
                    );
                }
                break;
            }

            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $item = $this->enrichHbOrderSummary($item);

                foreach ($this->expandHbOrderRows($item, $status) as $order) {
                    if (!$this->hbOrderInDateRange($order, $filterStartTs, $filterEndTs)) {
                        continue;
                    }

                    $allOrders[] = $order;
                }
            }

            $offset += $limit;
            $totalCount = (int) ($response['totalCount'] ?? $response['totalElements'] ?? $response['total'] ?? 0);
            if ($totalCount > 0 && $offset >= $totalCount) {
                break;
            }
        } while (count($items) === $limit && $this->keepPaging('hb.orders', (int) ($offset / max(1, $limit)), $items));

        return $allOrders;
    }

    /**
     * HB'nin kargoda/teslim/iptal paket listeleri sadece paket ozeti dondurebiliyor.
     * Siparis detayi musteri, adres, urun ve fiyat alanlarini tasir.
     *
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    private function enrichHbOrderSummary(array $raw): array
    {
        if (!$this->needsHbOrderDetail($raw)) {
            return $raw;
        }

        $orderNumber = $this->extractHbOrderNumber($raw);
        if ($orderNumber === '') {
            return $raw;
        }

        try {
            $detail = $this->fetchOrderDetailCached($orderNumber);
        } catch (\Throwable $e) {
            $this->logger->warning(
                "HB siparis detayi alinamadi: {$orderNumber} - {$e->getMessage()}",
                'HepsiburadaService'
            );
            return $raw;
        }

        if ($detail === []) {
            return $raw;
        }

        $merged = array_replace($detail, $raw);

        if (!empty($detail['items']) && is_array($detail['items'])) {
            $merged['items'] = [];
            foreach ($detail['items'] as $line) {
                $merged['items'][] = is_array($line) ? array_replace($raw, $line) : $line;
            }
        }

        if (!empty($detail['deliveryAddress']) && empty($merged['shippingAddress'])) {
            $merged['shippingAddress'] = $detail['deliveryAddress'];
        }

        return $merged;
    }

    /**
     * @param array<string, mixed> $raw
     */
    private function needsHbOrderDetail(array $raw): bool
    {
        $hasItems = false;
        foreach (['lineItems', 'items', 'orderItems', 'packageItems', 'packageLines', 'lines'] as $key) {
            if (!empty($raw[$key]) && is_array($raw[$key])) {
                $hasItems = true;
                break;
            }
        }

        $hasCustomer = !empty($raw['customer'])
            || !empty($raw['customerName'])
            || !empty($raw['customerFullName'])
            || !empty($raw['recipientName']);

        $hasAmount = $this->extractAmount(
            $raw['totalPrice'] ?? $raw['TotalPrice'] ?? $raw['lineTotal'] ?? $raw['LineTotal'] ?? $raw['price'] ?? $raw['Price'] ?? 0
        ) > 0;

        return !$hasItems || !$hasCustomer || !$hasAmount;
    }

    /**
     * @param array<string, mixed> $raw
     */
    private function extractHbOrderNumber(array $raw): string
    {
        $orderNumber = (string) ($raw['orderNumber'] ?? $raw['OrderNumber'] ?? $raw['orderId'] ?? $raw['OrderId'] ?? '');
        if ($orderNumber !== '') {
            return $orderNumber;
        }

        $orderNumbers = $raw['orderNumbers'] ?? $raw['OrderNumbers'] ?? [];
        if (is_array($orderNumbers) && !empty($orderNumbers[0])) {
            return (string) $orderNumbers[0];
        }

        return '';
    }

    /**
     * @return array<string, mixed>
     */
    private function fetchOrderDetailCached(string $orderNumber): array
    {
        if (!array_key_exists($orderNumber, $this->orderDetailCache)) {
            $this->orderDetailCache[$orderNumber] = $this->fetchOrderDetail($orderNumber);
        }

        return $this->orderDetailCache[$orderNumber];
    }

    /**
     * HB sipariş verisini normalize et
     *
     * HB "Ödemesi Tamamlanmış Siparişleri Listeleme" endpoint'i item bazlı döner.
     * Her item bir sipariş kalemidir (lineItem). Aynı orderNumber'a sahip kalemler
     * OrderSyncService tarafından gruplanır.
     *
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    /**
     * @param array<string, mixed> $response
     * @return array<int, mixed>
     */
    private function extractHbItems(array $response): array
    {
        foreach (['items', 'content', 'data', 'orders', 'packages'] as $key) {
            if (isset($response[$key]) && is_array($response[$key])) {
                return $response[$key];
            }
        }

        return $this->isListArray($response) ? $response : [];
    }

    /**
     * @param array<string, mixed> $raw
     * @return array<int, array<string, mixed>>
     */
    private function expandHbOrderRows(array $raw, ?string $status): array
    {
        foreach (['lineItems', 'items', 'orderItems', 'packageItems', 'packageLines', 'lines'] as $key) {
            if (empty($raw[$key]) || !is_array($raw[$key])) {
                continue;
            }

            $rows = [];
            foreach ($raw[$key] as $line) {
                if (!is_array($line)) {
                    continue;
                }

                $package = $raw;
                unset($package[$key]);
                $rows[] = $this->normalizeOrder(array_replace($package, $line), $status);
            }

            return $rows;
        }

        return [$this->normalizeOrder($raw, $status)];
    }

    /**
     * @param array<int, array<string, mixed>> $orders
     * @return array<int, array<string, mixed>>
     */
    private function deduplicateHbOrders(array $orders): array
    {
        $deduped = [];

        foreach ($orders as $order) {
            $orderId = (string) ($order['marketplace_order_id'] ?? '');
            $firstItem = $order['items'][0] ?? [];
            $lineId = is_array($firstItem)
                ? (string) ($firstItem['marketplace_item_id'] ?? $firstItem['sku'] ?? $firstItem['barcode'] ?? '')
                : '';
            $key = $orderId . '|' . $lineId;

            if (!isset($deduped[$key])) {
                $deduped[$key] = $order;
                continue;
            }

            if ($this->hbStatusPriority((string) ($order['status'] ?? '')) >= $this->hbStatusPriority((string) ($deduped[$key]['status'] ?? ''))) {
                $deduped[$key] = $order;
            }
        }

        return array_values($deduped);
    }

    private function hbStatusPriority(string $status): int
    {
        return [
            'yeni' => 10,
            'hazirlaniyor' => 20,
            'bolundu' => 30,
            'kargoda' => 40,
            'teslim_edilemedi' => 50,
            'iptal' => 60,
            'teslim_edildi' => 70,
        ][$status] ?? 0;
    }

    private function hbOrderInDateRange(array $order, ?int $startTs, ?int $endTs): bool
    {
        if ($startTs === null || $endTs === null) {
            return true;
        }

        $raw = is_array($order['raw_data'] ?? null) ? $order['raw_data'] : [];
        $rangeStart = strtotime(date('Y-m-d 00:00:00', $startTs));
        $rangeEnd = strtotime(date('Y-m-d 23:59:59', $endTs));

        foreach ([
            'ShippedDate', 'shippedDate',
            'DeliveredDate', 'deliveredDate',
            'UndeliveredDate', 'undeliveredDate',
            'CancelDate', 'cancelDate',
            'lastStatusUpdateDate', 'LastStatusUpdateDate',
            'orderDate', 'OrderDate',
            'createdDate', 'CreatedDate',
        ] as $key) {
            if (empty($raw[$key])) {
                continue;
            }

            $eventTs = strtotime((string) $raw[$key]);
            if ($eventTs !== false && $eventTs >= $rangeStart && $eventTs <= $rangeEnd) {
                return true;
            }
        }

        $orderedAt = (string) ($order['ordered_at'] ?? '');
        $orderTs = $orderedAt !== '' ? strtotime($orderedAt) : false;
        if ($orderTs === false) {
            return true;
        }

        return $orderTs >= $rangeStart && $orderTs <= $rangeEnd;
    }

    /**
     * @return array<int, array{begin: string, end: string}>
     */
    private function buildHbDateWindows(int $startTs, int $endTs): array
    {
        if ($startTs > $endTs) {
            [$startTs, $endTs] = [$endTs, $startTs];
        }

        $windows = [];
        $cursor = strtotime(date('Y-m-d', $startTs));
        $endTs = strtotime(date('Y-m-d', $endTs));

        while ($cursor <= $endTs) {
            $windowEnd = min(strtotime('+29 days', $cursor), $endTs);
            $windows[] = [
                'begin' => date('Y-m-d', $cursor),
                'end'   => date('Y-m-d', $windowEnd),
            ];
            $cursor = strtotime('+1 day', $windowEnd);
        }

        return $windows;
    }

    /**
     * @param array<mixed> $value
     */
    private function isListArray(array $value): bool
    {
        $index = 0;
        foreach ($value as $key => $_) {
            if ($key !== $index++) {
                return false;
            }
        }
        return true;
    }

    private function normalizeOrder(array $raw, ?string $statusOverride = null): array
    {
        $statusMapping = $this->config['status_mapping'] ?? [];

        $hbStatus = $statusOverride ?? (string) ($raw['status'] ?? $raw['Status'] ?? $raw['orderStatus'] ?? $raw['OrderStatus'] ?? $raw['packageStatus'] ?? $raw['PackageStatus'] ?? 'Open');
        $status = $statusMapping[$hbStatus] ?? $hbStatus;

        // Müşteri bilgileri
        $customerData = is_array($raw['customer'] ?? null) ? $raw['customer'] : [];
        $shippingAddr = $raw['shippingAddress'] ?? $raw['deliveryAddress'] ?? $raw['shippingAddressDetail'] ?? '';
        $invoiceData  = $raw['invoice'] ?? $raw['invoiceAddress'] ?? $raw['invoiceDetail'] ?? [];
        $invoiceAddressData = is_array($invoiceData) && is_array($invoiceData['address'] ?? null)
            ? $invoiceData['address']
            : [];

        $customerName = (string) ($raw['customerName'] ?? $raw['customerFullName'] ?? $customerData['name'] ?? $raw['recipientName'] ?? (is_array($shippingAddr) ? ($shippingAddr['name'] ?? '') : '') ?? '');
        $phone = (string) ($raw['phoneNumber'] ?? $raw['customerPhone'] ?? $raw['recipientPhone'] ?? $customerData['phone'] ?? (is_array($shippingAddr) ? ($shippingAddr['phoneNumber'] ?? $shippingAddr['alternatePhoneNumber'] ?? '') : '') ?? $invoiceAddressData['phoneNumber'] ?? '');
        $email = (string) ($raw['email'] ?? $raw['customerEmail'] ?? $customerData['email'] ?? (is_array($shippingAddr) ? ($shippingAddr['email'] ?? '') : '') ?? $invoiceAddressData['email'] ?? '');

        // TC / Vergi bilgileri
        $idNo = '';
        $taxOffice = '';
        $taxNumber = '';
        if (is_array($invoiceData)) {
            $idNo = (string) ($invoiceData['turkishIdentityNumber'] ?? '');
            $taxOffice = (string) ($invoiceData['taxOffice'] ?? '');
            $taxNumber = (string) ($invoiceData['taxNumber'] ?? '');
            if (in_array($idNo, ['11111111111', '00000000000', ''], true)) {
                $idNo = $taxNumber;
            }
        }

        // Fiyat — HB Amount/Currency objesi veya direkt float
        $unitPrice  = $this->extractAmount($raw['unitPrice'] ?? $raw['UnitPrice'] ?? $raw['price'] ?? $raw['Price'] ?? $raw['itemPrice'] ?? $raw['ItemPrice'] ?? 0);
        $totalPrice = $this->extractAmount($raw['totalPrice'] ?? $raw['TotalPrice'] ?? $raw['lineTotal'] ?? $raw['LineTotal'] ?? $raw['price'] ?? $raw['Price'] ?? 0);
        $vatRate    = (float) ($raw['vatRate'] ?? $raw['VatRate'] ?? $raw['vat'] ?? $raw['Vat'] ?? 0);
        $qty        = max(1, (int) ($raw['quantity'] ?? $raw['Quantity'] ?? $raw['qty'] ?? $raw['Qty'] ?? 1));
        if ($totalPrice <= 0 && $unitPrice > 0) {
            $totalPrice = $unitPrice * $qty;
        }

        $discount = 0;
        if (isset($raw['totalmerchantDiscount']['amount'])) {
            $discount += (float) $raw['totalmerchantDiscount']['amount'];
        }
        if (isset($raw['totalHBDiscount']['amount'])) {
            $discount += (float) $raw['totalHBDiscount']['amount'];
        }

        $taxAmount = ($totalPrice > 0 && $vatRate > 0)
            ? round($totalPrice * $vatRate / (100 + $vatRate), 2)
            : 0;

        $items = [
            [
                'marketplace_item_id' => (string) ($raw['id'] ?? $raw['Id'] ?? $raw['lineItemId'] ?? $raw['LineItemId'] ?? $raw['orderLineId'] ?? $raw['OrderLineId'] ?? $raw['orderItemId'] ?? $raw['OrderItemId'] ?? ''),
                'sku'                 => (string) ($raw['merchantSku'] ?? $raw['MerchantSku'] ?? $raw['merchantSKU'] ?? $raw['MerchantSKU'] ?? $raw['stockCode'] ?? $raw['StockCode'] ?? $raw['merchant_sku'] ?? $raw['sku'] ?? $raw['Sku'] ?? ''),
                'barcode'             => (string) ($raw['productBarcode'] ?? $raw['ProductBarcode'] ?? $raw['barcode'] ?? $raw['Barcode'] ?? $raw['sku'] ?? $raw['Sku'] ?? $raw['hbSku'] ?? $raw['HbSku'] ?? $raw['HepsiburadaSku'] ?? ''),
                'name'                => (string) ($raw['productName'] ?? $raw['ProductName'] ?? $raw['name'] ?? $raw['Name'] ?? $raw['product_name'] ?? ''),
                'qty'                 => $qty,
                'unit_price'          => $unitPrice,
                'discount'            => $discount,
                'tax_rate'            => $vatRate,
                'line_total'          => $totalPrice,
            ],
        ];

        // Teslimat adresi
        $shippingAddress = [
            'name'         => (string) ($raw['recipientName'] ?? $customerName),
            'address'      => is_string($shippingAddr) ? $shippingAddr : (string) ($shippingAddr['address'] ?? ''),
            'city'         => (string) ($raw['shippingCity'] ?? (is_array($shippingAddr) ? ($shippingAddr['city'] ?? $shippingAddr['cityName'] ?? '') : '')),
            'district'     => (string) ($raw['shippingDistrict'] ?? (is_array($shippingAddr) ? ($shippingAddr['district'] ?? $shippingAddr['town'] ?? '') : '')),
            'postal_code'  => (string) ($raw['shippingPostalCode'] ?? (is_array($shippingAddr) ? ($shippingAddr['postalCode'] ?? '') : '')),
            'phone'        => $phone,
            'neighborhood' => (string) ($raw['shippingTown'] ?? (is_array($shippingAddr) ? ($shippingAddr['neighborhood'] ?? '') : '')),
        ];

        // Fatura adresi
        $invoiceAddress = is_array($invoiceData) ? ($invoiceData['address'] ?? []) : [];
        $billingAddress = [
            'name'        => (string) ($raw['companyName'] ?? (is_array($invoiceAddress) ? ($invoiceAddress['name'] ?? '') : '') ?: $customerName),
            'address'     => (string) ($raw['billingAddress'] ?? (is_array($invoiceAddress) ? ($invoiceAddress['address'] ?? '') : '')),
            'city'        => (string) ($raw['billingCity'] ?? (is_array($invoiceAddress) ? ($invoiceAddress['city'] ?? '') : '')),
            'district'    => (string) ($raw['billingDistrict'] ?? (is_array($invoiceAddress) ? ($invoiceAddress['district'] ?? '') : '')),
            'postal_code' => (string) ($raw['billingPostalCode'] ?? ''),
            'company'     => (string) ($raw['companyName'] ?? ''),
            'tax_office'  => $taxOffice,
            'tax_number'  => $taxNumber,
        ];

        // Kargo bilgisi
        $cargoCompany = (string) ($raw['cargoCompany'] ?? $raw['cargoCompanyName'] ?? '');
        if (empty($cargoCompany) && !empty($raw['cargoCompanyModel'])) {
            $cargoCompany = (string) ($raw['cargoCompanyModel']['name'] ?? '');
        }
        $cargoTrackingNo = (string) ($raw['trackingInfoCode'] ?? $raw['trackingNumber'] ?? $raw['cargoTrackingNumber'] ?? '');

        // Sipariş tarihi
        $orderedAt = $this->parseHbDate($raw['orderDate'] ?? $raw['OrderDate'] ?? $raw['createdDate'] ?? $raw['CreatedDate'] ?? $raw['packageDate'] ?? $raw['PackageDate'] ?? $raw['lastModifiedDate'] ?? $raw['LastModifiedDate'] ?? $raw['shippedDate'] ?? $raw['ShippedDate'] ?? $raw['deliveredDate'] ?? $raw['DeliveredDate'] ?? $raw['undeliveredDate'] ?? $raw['UndeliveredDate'] ?? $raw['cancelDate'] ?? $raw['CancelDate'] ?? '');

        return [
            'marketplace_order_id' => (string) ($raw['orderNumber'] ?? $raw['OrderNumber'] ?? $raw['orderId'] ?? $raw['OrderId'] ?? $raw['packageNumber'] ?? $raw['PackageNumber'] ?? ''),
            'status'               => $status,
            'customer_name'        => $customerName,
            'customer_email'       => $email,
            'customer_phone'       => $phone,
            'customer_id_no'       => $idNo,
            'customer_tax_office'  => $taxOffice,
            'notes'                => '',
            'billing_address'      => $billingAddress,
            'shipping_address'     => $shippingAddress,
            'subtotal'             => round($totalPrice - $taxAmount, 2),
            'tax_total'            => round($taxAmount, 2),
            'discount_total'       => round($discount, 2),
            'total_amount'         => round($totalPrice, 2),
            'cargo_company'        => $cargoCompany,
            'cargo_tracking_no'    => $cargoTrackingNo,
            'cargo_sent_at'        => $this->parseHbDate($raw['shippedDate'] ?? $raw['ShippedDate'] ?? ''),
            'ordered_at'           => $orderedAt,
            'items'                => $items,
            'raw_data'             => $raw,
        ];
    }

    public function updateOrderStatus(string $orderId, string $status, array $extra = []): bool
    {
        $this->loadCredentials();

        $endpointKey = match ($status) {
            'intransit', 'kargoda'         => 'package_intransit',
            'deliver', 'teslim_edildi'     => 'package_deliver',
            'undeliver', 'teslim_edilemedi' => 'package_undeliver',
            'unpack', 'bolundu'            => 'package_unpack',
            default => throw new RuntimeException("Desteklenmeyen sipariş durumu: {$status}"),
        };

        $endpoint = $this->config['endpoints'][$endpointKey] ?? '';
        $url = str_replace('{packageNumber}', $orderId, $this->buildUrl($endpoint, 'order'));

        $this->httpPost($url, $extra, $this->authHeaders());
        return true;
    }

    public function updateCargoInfo(string $orderId, string $trackingNo, string $cargoCompany): bool
    {
        return $this->updateOrderStatus($orderId, 'intransit', [
            'trackingNumber' => $trackingNo,
            'cargoCompany'   => $cargoCompany,
        ]);
    }

    /**
     * Paket oluştur (Kalem veya Kalemleri Paketleme)
     *
     * @param array<int, array{id: string, quantity: int}> $lineItems
     * @return array<string, mixed>
     */
    public function createPackage(array $lineItems): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_create'] ?? '/packages/merchantid/{merchantId}';
        $url = $this->buildUrl($endpoint, 'order');

        $payload = [
            'lineItemRequests' => array_map(fn(array $item) => [
                'id'       => $item['id'],
                'quantity' => $item['quantity'],
            ], $lineItems),
        ];

        return $this->httpPost($url, $payload, $this->authHeaders());
    }

    /**
     * Paket bilgilerini listele
     */
    public function fetchPackages(array $filters = []): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packages'] ?? '/packages/merchantid/{merchantId}';
        $url = $this->buildUrl($endpoint, 'order');

        $queryParams = [];
        $endDate = !empty($filters['end_date']) ? (string) $filters['end_date'] : date('Y-m-d');
        $beginDate = !empty($filters['begin_date'])
            ? (string) $filters['begin_date']
            : date('Y-m-d', strtotime('-' . max(1, (int) ($filters['timespan'] ?? 30)) . ' days'));
        $queryParams['begindate'] = $this->formatHbDateParam($beginDate);
        $queryParams['enddate'] = $this->formatHbDateParam($endDate);
        $queryParams['offset'] = $filters['offset'] ?? 0;
        $queryParams['limit']  = $filters['limit'] ?? 10;

        $url .= '?' . http_build_query($queryParams);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Fatura linki gönder
     */
    public function sendInvoice(string $packageNumber, string $invoiceUrl): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_invoice']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}/invoice';
        $url = str_replace('{packageNumber}', rawurlencode($packageNumber), $this->buildUrl($endpoint, 'order'));

        // HB linki KENDİ sunucusundan indirir: adres .pdf/.html ile bitmeli ve
        // ilgili Content-Type ile dönmelidir. Aksi halde "Url is not correct format"
        // hatası verir. Gönderim öncesi biçim kontrolü yapılır.
        if (!preg_match('#^https?://#i', $invoiceUrl)) {
            throw new RuntimeException('Fatura adresi http(s) ile başlamalı: ' . $invoiceUrl);
        }
        if (!preg_match('#\.(pdf|html?)($|\?)#i', $invoiceUrl)) {
            throw new RuntimeException(
                'Hepsiburada fatura adresi .pdf veya .html ile bitmelidir. Gönderilen: ' . $invoiceUrl
            );
        }

        $this->httpPut($url, ['invoiceLink' => $invoiceUrl], $this->authHeaders());
        return true;
    }

    /**
     * Sipariş kalemi iptal et (sadece Open statüde)
     */
    public function cancelOrderLine(string $lineId): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['cancel_line']
            ?? '/lineitems/merchantid/{merchantId}/id/{lineId}/cancelbymerchant';
        $url = str_replace('{lineId}', $lineId, $this->buildUrl($endpoint, 'order'));

        $this->httpPost($url, null, $this->authHeaders());
        return true;
    }

    /**
     * Test siparişi oluştur (sadece SIT ortamında çalışır)
     *
     * @param array<int, array{Sku: string, Quantity?: int, Price?: float}> $lineItems
     */
    public function createTestOrder(string $orderNumber, array $lineItems): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['test_order_create']
            ?? '/orders/merchantid/{merchantId}';
        $url = $this->environment === 'sit'
            ? 'https://oms-stub-external-sit.hepsiburada.com/orders/merchantId/' . $this->merchantId
            : $this->buildUrl($endpoint, 'order');

        $payload = [
            'OrderNumber' => $orderNumber,
            'OrderDate'   => date('Y-m-d\TH:i:s'),
            'PaymentStatus' => 'Paid',
            'Customer'    => [
                'CustomerId' => 'test-customer-' . uniqid(),
                'Name'       => 'Test Kullanıcı',
            ],
            'DeliveryAddress' => [
                'AddressId'    => 'test-addr-' . uniqid(),
                'Name'         => 'Test Adresi',
                'AddressDetail'=> 'Test Mahallesi, Test Sokak No:1',
                'Email'        => 'test@example.com',
                'CountryCode'  => 'TR',
                'PhoneNumber'  => '905001234567',
                'Town'         => 'Kadıköy',
                'District'     => 'Fenerbahçe',
                'City'         => 'İstanbul',
            ],
            'LineItems' => array_map(fn(array $item) => [
                'Sku'              => $item['Sku'],
                'MerchantId'       => $this->merchantId,
                'Quantity'         => $item['Quantity'] ?? 1,
                'Price'            => ['Amount' => $item['Price'] ?? 100, 'Currency' => 'TRY'],
                'Vat'              => 0,
                'TotalPrice'       => ['Amount' => ($item['Price'] ?? 100) * ($item['Quantity'] ?? 1), 'Currency' => 'TRY'],
                'CargoCompanyId'   => 1,
                'DeliveryOptionId' => 1,
            ], $lineItems),
        ];

        return $this->httpPost($url, $payload, $this->authHeaders());
    }

    /**
     * Ortak barkod / etiket oluştur
     */
    public function getPackageLabels(string $packageNumber, string $format = 'pdf'): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_labels']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}/labels';
        $url = str_replace('{packageNumber}', $packageNumber, $this->buildUrl($endpoint, 'order'));
        $url .= '?format=' . urlencode($format);

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // ÜRÜN İŞLEMLERİ
    // ═══════════════════════════════════════════════════════

    public function fetchProducts(int $page = 0, int $size = 100): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['products_all'] ?? '/product/api/products/all-products-of-merchant/{merchantId}';
        $url = $this->buildUrl($endpoint, 'catalog');
        $url .= '?' . http_build_query(['page' => $page, 'size' => $size]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Listing kimliğini çöz: HB listeleme servisleri HepsiburadaSku ve/veya
     * MerchantSku bekler. Barkod HB SKU'su DEĞİLDİR — barkodu HepsiburadaSku
     * olarak göndermek güncellemenin sessizce düşmesine yol açıyordu.
     *
     * @param array<string, mixed> $item
     * @return array<string, string>
     */
    private function resolveListingKeys(array $item): array
    {
        $keys = [];

        $hbSku = trim((string) ($item['hbSku'] ?? $item['HepsiburadaSku'] ?? $item['marketplace_product_id'] ?? ''));
        if ($hbSku !== '') {
            $keys['HepsiburadaSku'] = $hbSku;
        }

        // MerchantSku satıcının kendi stok kodudur; HB büyük/küçük harfe duyarlıdır,
        // bu yüzden strtoupper YAPILMAZ.
        $merchantSku = trim((string) ($item['sku'] ?? $item['MerchantSku'] ?? $item['merchant_sku'] ?? ''));
        if ($merchantSku !== '') {
            $keys['MerchantSku'] = $merchantSku;
        }

        return $keys;
    }

    /**
     * HB listeleme güncellemeleri XML gövde ister (Content-Type: application/xml).
     *
     * @param array<int, array<string, string|int>> $listings
     */
    private function buildListingXml(array $listings): string
    {
        $xml = '<?xml version="1.0" encoding="utf-8"?>' . "\n" . '<listings>' . "\n";

        foreach ($listings as $listing) {
            $xml .= '  <listing>' . "\n";
            foreach ($listing as $field => $value) {
                $safeField = preg_replace('/[^A-Za-z0-9_]/', '', (string) $field) ?? '';
                if ($safeField === '') {
                    continue;
                }
                $xml .= '    <' . $safeField . '>'
                     . htmlspecialchars((string) $value, ENT_XML1 | ENT_QUOTES, 'UTF-8')
                     . '</' . $safeField . '>' . "\n";
            }
            $xml .= '  </listing>' . "\n";
        }

        return $xml . '</listings>';
    }

    /**
     * XML gövdeli listeleme yükleme isteği için header seti.
     *
     * @return array<int, string>
     */
    private function listingXmlHeaders(): array
    {
        $headers = [];
        foreach ($this->authHeaders() as $header) {
            if (stripos($header, 'content-type:') === 0) {
                continue;
            }
            $headers[] = $header;
        }
        $headers[] = 'Content-Type: application/xml';

        return $headers;
    }

    /**
     * Listeleme yükleme isteği gönder ve SONUCUNU DOĞRULA.
     *
     * @param array<int, array<string, string|int>> $listings
     * @param array<int, array<string, mixed>> $preErrors
     * @return array{success: int, failed: int, errors: array, uploadId: ?string, trackingId: ?string, pending?: bool, notice?: string}
     */
    private function submitListingUpload(string $type, array $listings, array $preErrors = []): array
    {
        if ($listings === []) {
            return [
                'success'    => 0,
                'failed'     => count($preErrors),
                'errors'     => $preErrors,
                'uploadId'   => null,
                'trackingId' => null,
            ];
        }

        $this->loadCredentials();

        $endpointKey = "listing_{$type}";
        $endpoint = $this->config['endpoints'][$endpointKey]
            ?? "/listings/merchantid/{merchantId}/{$type}-uploads";
        $url = $this->getBaseUrl('listing') . str_replace('{merchantId}', $this->merchantId, $endpoint);

        $chunkSize = (int) ($this->config['api']['batch_limit'] ?? 4000);
        $chunks    = array_chunk($listings, max(1, $chunkSize));

        $success  = 0;
        $failed   = count($preErrors);
        $errors   = $preErrors;
        $uploadId = null;
        $pending  = false;
        $notice   = '';

        foreach ($chunks as $chunk) {
            try {
                $response = $this->httpPostRaw($url, $this->buildListingXml($chunk), $this->listingXmlHeaders());
                $chunkUploadId = $this->extractUploadId($response);

                if ($chunkUploadId === null) {
                    $failed += count($chunk);
                    $errors[] = ['error' => 'Hepsiburada yükleme kimliği (uploadId) dönmedi: '
                        . json_encode($response, JSON_UNESCAPED_UNICODE)];
                    continue;
                }

                $uploadId = $chunkUploadId;

                $status = $this->waitForListingUpload($type, $chunkUploadId, count($chunk));
                $success += $status['success'];
                $failed  += $status['failed'];
                foreach ($status['errors'] as $error) {
                    $errors[] = $error;
                }
                if (!empty($status['pending'])) {
                    $pending = true;
                    $notice  = (string) ($status['notice'] ?? '');
                }
            } catch (\Throwable $e) {
                $failed += count($chunk);
                $errors[] = ['error' => $e->getMessage()];
            }
        }

        $result = [
            'success'    => $success,
            'failed'     => $failed,
            'errors'     => $errors,
            'uploadId'   => $uploadId,
            'trackingId' => $uploadId,
        ];

        if ($pending) {
            $result['pending'] = true;
            $result['notice']  = $notice;
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $response
     */
    private function extractUploadId(array $response): ?string
    {
        $candidates = [
            $response['id'] ?? null,
            $response['Id'] ?? null,
            $response['data']['id'] ?? null,
            $response['inventoryUploadId'] ?? null,
            $response['uploadId'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            if (is_string($candidate) && trim($candidate) !== '') {
                return trim($candidate);
            }
            if (is_int($candidate) && $candidate > 0) {
                return (string) $candidate;
            }
        }

        // Bazı yanıtlar düz metin (GUID) döner
        $raw = trim((string) ($response['raw_response'] ?? ''));
        if ($raw !== '' && preg_match('/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i', $raw, $m)) {
            return $m[0];
        }

        return null;
    }

    /**
     * Yükleme tamamlanana kadar durum sorgula.
     *
     * @return array{success: int, failed: int, errors: array, pending: bool, notice?: string}
     */
    private function waitForListingUpload(string $type, string $uploadId, int $expected): array
    {
        $lastError = '';

        for ($attempt = 1; $attempt <= self::UPLOAD_POLL_ATTEMPTS; $attempt++) {
            try {
                $response = $this->checkUploadStatus($type, $uploadId);

                $parsed = $this->parseUploadStatus($response, $uploadId, $expected);
                if (!$parsed['pending']) {
                    return $parsed;
                }
            } catch (\Throwable $e) {
                // İşlenmekte olan yükleme sorgusu geçici olarak hata dönebilir.
                // İstek HB tarafından KABUL EDİLDİ (uploadId var); sorgu hatasını
                // "gönderim başarısız" saymak yanlış olur.
                $lastError = $e->getMessage();
                $this->logger->warning(
                    "Hepsiburada {$type} yükleme durumu sorgulanamadı ({$uploadId}): {$lastError}",
                    'HepsiburadaService'
                );
            }

            // Toplu yayınlamada istek başına bekleme bütçesi aşılmasın
            if ($attempt < self::UPLOAD_POLL_ATTEMPTS && !$this->pollWait(self::UPLOAD_POLL_DELAY_MS)) {
                $lastError = $lastError !== '' ? $lastError : 'bekleme bütçesi doldu (yükleme işleniyor)';
                break;
            }
        }

        $notice = "Hepsiburada {$type} yüklemesi hâlâ işleniyor (id: {$uploadId})."
            . ($lastError !== '' ? " Son sorgu hatası: {$lastError}" : '');
        $this->logger->info($notice, 'HepsiburadaService');

        return [
            'success' => $expected,
            'failed'  => 0,
            'errors'  => [],
            'pending' => true,
            'notice'  => $notice,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function checkUploadStatus(string $type, string $uploadId): array
    {
        $endpoint = $this->config['endpoints']["listing_{$type}_check"]
            ?? "/listings/merchantid/{merchantId}/{$type}-uploads/id/{uploadId}";

        $path = str_replace(
            ['{merchantId}', '{uploadId}'],
            [$this->merchantId, rawurlencode($uploadId)],
            $endpoint
        );

        return $this->httpGet($this->getBaseUrl('listing') . $path, $this->authHeaders());
    }

    /**
     * HB yükleme durumu yanıtını sayısal sonuca çevir.
     *
     * @param array<string, mixed> $response
     * @return array{success: int, failed: int, errors: array, pending: bool}
     */
    private function parseUploadStatus(array $response, string $uploadId, int $expected): array
    {
        $data = is_array($response['data'] ?? null) ? $response['data'] : $response;

        $status = strtoupper(trim((string) (
            $data['status'] ?? $data['Status'] ?? $data['state'] ?? $response['status'] ?? ''
        )));
        $normalizedStatus = str_replace([' ', '-', '_'], '', $status);

        $errorRows = [];
        foreach (['errors', 'Errors', 'validationErrors', 'failedItems', 'errorList'] as $key) {
            if (!empty($data[$key]) && is_array($data[$key])) {
                $errorRows = $data[$key];
                break;
            }
        }

        $failed = 0;
        $errors = [];
        foreach ($errorRows as $row) {
            if (is_string($row)) {
                $failed++;
                $errors[] = ['error' => $row];
                continue;
            }
            if (!is_array($row)) {
                continue;
            }

            $failed++;
            $sku = (string) ($row['sku'] ?? $row['merchantSku'] ?? $row['hepsiburadaSku'] ?? '');
            $msg = (string) ($row['message'] ?? $row['error'] ?? $row['description'] ?? $row['errorMessage']
                ?? json_encode($row, JSON_UNESCAPED_UNICODE));
            $errors[] = ['sku' => $sku, 'error' => trim($sku . ': ' . $msg, ': ')];
        }

        if ($normalizedStatus !== '' && in_array($normalizedStatus, self::UPLOAD_PENDING_STATES, true)) {
            return ['success' => 0, 'failed' => 0, 'errors' => [], 'pending' => true];
        }

        if ($normalizedStatus !== '' && in_array($normalizedStatus, self::UPLOAD_FAILED_STATES, true) && $errors === []) {
            return [
                'success' => 0,
                'failed'  => $expected,
                'errors'  => [['error' => "Hepsiburada yüklemesi başarısız (id: {$uploadId}, durum: {$status})"]],
                'pending' => false,
            ];
        }

        // Durum bilgisi yoksa ve hata listesi de yoksa yükleme henüz işlenmemiş olabilir.
        if ($normalizedStatus === '' && $errors === [] && !array_key_exists('id', $data) && !array_key_exists('Id', $data)) {
            return ['success' => 0, 'failed' => 0, 'errors' => [], 'pending' => true];
        }

        return [
            'success' => max(0, $expected - $failed),
            'failed'  => $failed,
            'errors'  => $errors,
            'pending' => false,
        ];
    }

    public function updateStock(array $items): array
    {
        $listings  = [];
        $preErrors = [];

        foreach ($items as $item) {
            $keys = $this->resolveListingKeys($item);
            if ($keys === []) {
                $preErrors[] = ['error' => 'Hepsiburada SKU bilgisi yok (HB SKU veya satıcı stok kodu gerekli) — stok gönderilemedi'];
                continue;
            }

            $listings[] = $keys + ['AvailableStock' => max(0, (int) ($item['quantity'] ?? 0))];
        }

        return $this->submitListingUpload('stock', $listings, $preErrors);
    }

    public function updatePrice(array $items): array
    {
        $listings  = [];
        $preErrors = [];

        foreach ($items as $item) {
            $keys = $this->resolveListingKeys($item);
            if ($keys === []) {
                $preErrors[] = ['error' => 'Hepsiburada SKU bilgisi yok (HB SKU veya satıcı stok kodu gerekli) — fiyat gönderilemedi'];
                continue;
            }

            $price = (float) ($item['salePrice'] ?? $item['price'] ?? 0);
            if ($price <= 0) {
                $preErrors[] = ['error' => 'Geçersiz fiyat (0) — Hepsiburada güncellemesi atlandı: '
                    . implode('/', $keys)];
                continue;
            }

            // HB listeleme XML'inde fiyat ondalığı VİRGÜL ile ayrılır (118,97).
            $listings[] = $keys + ['Price' => number_format($price, 2, ',', '')];
        }

        return $this->submitListingUpload('price', $listings, $preErrors);
    }

    /**
     * Ürün bilgisi gönder (JSON dosyası form-data olarak upload)
     *
     * @param array<int, array<string, mixed>> $products HB formatında ürün dizisi
     * @return array{trackingId: string|null, success: bool, message: string}
     */
    public function uploadProduct(array $products): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_upload'] ?? '/product/api/products/import';
        $url = $this->getBaseUrl('catalog') . $endpoint;

        // JSON dosyasını temp olarak oluştur
        $tmpDir = BASE_PATH . '/storage/tmp';
        if (!is_dir($tmpDir)) {
            mkdir($tmpDir, 0755, true);
        }
        $tmpFile = $tmpDir . '/hb_product_upload_' . uniqid() . '.json';

        try {
            $jsonContent = json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            if ($jsonContent === false) {
                throw new RuntimeException('Ürün verileri JSON\'a dönüştürülemedi');
            }
            file_put_contents($tmpFile, $jsonContent);

            $response = $this->httpPostMultipart($url, $tmpFile, 'file', $this->authHeaders());

            $trackingId = $response['data']['trackingId'] ?? $response['trackingId'] ?? null;

            return [
                'trackingId' => $trackingId,
                'success'    => !empty($trackingId),
                'message'    => $response['message'] ?? 'Ürün yükleme isteği gönderildi',
            ];
        } finally {
            if (file_exists($tmpFile)) {
                unlink($tmpFile);
            }
        }
    }

    /**
     * Ürün oluştur (toplu) — ProductPublishService'in beklediği ortak sözleşme.
     * Hepsiburada ürün açma, mpop import (JSON dosya yükleme) ile çalışır;
     * dönen trackingId batch takibi için batchRequestId yerine kullanılır.
     *
     * @param array<int, array<string, mixed>> $items
     * @return array{success: bool, trackingId: ?string, errors: array}
     */
    public function createProducts(array $items): array
    {
        $products = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $images = [];
            foreach ((array) ($item['images'] ?? []) as $img) {
                $url = is_array($img) ? (string) ($img['url'] ?? '') : (string) $img;
                if ($url !== '') {
                    $images[] = $url;
                }
            }

            $name = (string) ($item['productName'] ?? $item['title'] ?? $item['name'] ?? '');

            $products[] = [
                'categoryId'         => (int) ($item['categoryId'] ?? 0),
                'merchant_sku'       => (string) ($item['merchant_sku'] ?? $item['stockCode'] ?? $item['sku'] ?? $item['barcode'] ?? ''),
                'barcode'            => (string) ($item['barcode'] ?? ''),
                'HepsiburadaSku'     => (string) ($item['HepsiburadaSku'] ?? $item['barcode'] ?? ''),
                'productName'        => $name,
                'productDescription' => (string) ($item['description'] ?? $name),
                'price'              => (float) ($item['price'] ?? $item['salePrice'] ?? 0),
                'listPrice'          => (float) ($item['listPrice'] ?? $item['price'] ?? $item['salePrice'] ?? 0),
                'availableStock'     => max(0, (int) ($item['availableStock'] ?? $item['quantity'] ?? 0)),
                'vatRate'            => (int) ($item['vatRate'] ?? 20),
                'images'             => $images,
                'attributes'         => (array) ($item['attributes'] ?? []),
            ];
        }

        if ($products === []) {
            return ['success' => false, 'trackingId' => null, 'errors' => [['error' => 'Gönderilecek ürün yok']]];
        }

        try {
            $result = $this->uploadProduct($products);

            return [
                'success'    => $result['success'] ?? false,
                'trackingId' => $result['trackingId'] ?? null,
                'errors'     => ($result['success'] ?? false)
                    ? []
                    : [['error' => (string) ($result['message'] ?? 'Hepsiburada ürün yükleme başarısız')]],
            ];
        } catch (\Throwable $e) {
            return ['success' => false, 'trackingId' => null, 'errors' => [['error' => $e->getMessage()]]];
        }
    }

    /**
     * Hepsiburada'ya varyantlı ürün grubu gönder
     * Aynı variant_group_id ile gönderilen ürünler tek kart altında gruplanır.
     *
     * @param array{items: array, groupId: string} $variantGroup
     * @return array{success: bool, trackingId: ?string, errors: array}
     */
    public function createVariantProducts(array $variantGroup): array
    {
        $this->loadCredentials();

        $products = [];
        foreach ($variantGroup['items'] ?? [] as $item) {
            $products[] = [
                'categoryId'     => $item['categoryId'],
                'merchant_sku'   => $item['stockCode'] ?? $item['barcode'],
                'barcode'        => $item['barcode'],
                'HepsiburadaSku' => $item['barcode'],
                'productName'    => $item['title'],
                'price'          => $item['salePrice'],
                'listPrice'      => $item['listPrice'] ?? $item['salePrice'],
                'availableStock' => $item['quantity'],
                'vatRate'        => $item['vatRate'] ?? 20,
                'images'         => array_map(fn($img) => $img['url'] ?? '', $item['images'] ?? []),
                'variantGroupId' => $variantGroup['groupId'],
                'attributes'     => $item['attributes'] ?? [],
            ];
        }

        try {
            $result = $this->uploadProduct($products);
            return [
                'success'    => $result['success'] ?? false,
                'trackingId' => $result['trackingId'] ?? null,
                'errors'     => $result['success'] ? [] : [['error' => $result['message'] ?? 'Upload failed']],
            ];
        } catch (\Throwable $e) {
            return [
                'success'    => false,
                'trackingId' => null,
                'errors'     => [['error' => $e->getMessage()]],
            ];
        }
    }

    /**
     * Ürün durumu sorgula (trackingId ile)
     */
    public function checkProductStatus(string $trackingId, int $page = 0, int $size = 100): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_tracking']
            ?? '/product/api/products/tracking/{trackingId}';
        $url = str_replace('{trackingId}', $trackingId, $this->getBaseUrl('catalog') . $endpoint);
        $url .= '?' . http_build_query(['page' => $page, 'size' => $size]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * TrackingId geçmişini sorgula
     */
    public function fetchTrackingHistory(int $page = 0, int $size = 20): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_tracking_list']
            ?? '/product/api/products/tracking-list';
        $url = $this->getBaseUrl('catalog') . $endpoint;
        $url .= '?' . http_build_query(['page' => $page, 'size' => $size]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Ürüne ait statü bilgisi çek
     */
    public function fetchProductStatuses(): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_status']
            ?? '/product/api/products/status/{merchantId}';
        $url = $this->buildUrl($endpoint, 'catalog');

        return $this->httpPost($url, null, $this->authHeaders());
    }

    /**
     * Statü bazlı ürün bilgisi çek
     *
     * @param string $productStatus WAITING|MISSING_INFO|MATCHED|PRE_MATCHED|REJECTED|MATCHED_WITH_STAGED|CREATED
     */
    public function fetchProductsByStatus(string $productStatus, int $page = 0, int $size = 100): array
    {
        $this->loadCredentials();

        // Doğru endpoint: products-by-merchant-and-status (merchantId + productStatus QUERY paramı).
        // Eski yol /product/api/products/{merchantId}/products/{status} HB'de 404 veriyordu.
        $endpoint = $this->config['endpoints']['product_by_status']
            ?? '/product/api/products/products-by-merchant-and-status';
        $url = $this->buildUrl($endpoint, 'catalog');
        $url .= '?' . http_build_query([
            'merchantId'    => $this->merchantId,
            'productStatus' => $productStatus,
            'page'          => $page,
            'size'          => $size,
        ]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Eşleşen statü onay (pre-match approve)
     */
    public function approvePreMatch(string $merchantSku, string $hbSku): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_prematch_approve']
            ?? '/product/api/products/prematch-approve';
        $url = $this->getBaseUrl('catalog') . $endpoint;

        $this->httpPost($url, [
            'merchantSku' => $merchantSku,
            'hbSku'       => $hbSku,
            'merchantId'  => $this->merchantId,
        ], $this->authHeaders());

        return true;
    }

    /**
     * Eşleşen statü red (pre-match reject)
     */
    public function rejectPreMatch(string $merchantSku): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_prematch_reject']
            ?? '/product/api/products/prematch-reject';
        $url = $this->getBaseUrl('catalog') . $endpoint;

        $this->httpPost($url, [
            'merchantSku' => $merchantSku,
            'merchantId'  => $this->merchantId,
        ], $this->authHeaders());

        return true;
    }

    /**
     * Aksiyon bekleyen ürünleri sil
     *
     * @param array<int, string> $merchantSkus
     */
    public function deleteActionPendingProducts(array $merchantSkus): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_delete']
            ?? '/product/api/products/{merchantId}/delete';
        $url = $this->buildUrl($endpoint, 'catalog');

        return $this->httpPost($url, ['merchantSkuList' => $merchantSkus], $this->authHeaders());
    }

    /**
     * Ürün silme işlem durumu kontrol
     */
    public function checkDeleteStatus(string $trackingId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_delete_status']
            ?? '/product/api/products/{merchantId}/delete/{trackingId}';
        $url = str_replace('{trackingId}', $trackingId, $this->buildUrl($endpoint, 'catalog'));

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // LİSTELEME İŞLEMLERİ
    // ═══════════════════════════════════════════════════════

    /**
     * Listing aktivasyonu (satışa aç)
     *
     * @param array<int, string> $hbSkus
     */
    public function activateListing(array $hbSkus): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_activate']
            ?? '/listings/merchantid/{merchantId}/sku/{sku}/activate';

        return $this->changeListingActivation($hbSkus, $endpoint);
    }

    /**
     * Listing deaktivasyonu (satıştan kapat)
     *
     * @param array<int, string> $hbSkus
     */
    public function deactivateListing(array $hbSkus): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_deactivate']
            ?? '/listings/merchantid/{merchantId}/sku/{sku}/deactivate';

        return $this->changeListingActivation($hbSkus, $endpoint);
    }

    /**
     * @param array<int, string> $hbSkus
     */
    private function changeListingActivation(array $hbSkus, string $endpoint): array
    {
        $success = 0;
        $failed = 0;
        $errors = [];

        foreach (array_values(array_unique(array_filter($hbSkus))) as $sku) {
            $path = str_replace(
                ['{merchantId}', '{sku}'],
                [$this->merchantId, rawurlencode((string) $sku)],
                $endpoint
            );
            $url = $this->getBaseUrl('listing') . $path;

            try {
                $this->httpPost($url, null, $this->authHeaders());
                $success++;
            } catch (\Throwable $e) {
                $failed++;
                $errors[] = ['sku' => (string) $sku, 'error' => $e->getMessage()];
            }
        }

        return [
            'success' => $success,
            'failed'  => $failed,
            'errors'  => $errors,
        ];
    }

    /**
     * Ürünü Hepsiburada'da satışa aç / satıştan kaldır.
     *
     * Pazaryeri servislerinin ORTAK sözleşmesi: setListingStatus(items, active).
     *
     * İki yol denenir:
     *  1) Listing activate/deactivate uç noktası (varsa en temiz yol),
     *  2) HB dokümanının resmî yöntemi: satışa kapatmak için stok 0 gönderilir,
     *     açarken paneldeki gerçek stok geri yazılır.
     *
     * @param array<int, array<string, mixed>|string> $items
     * @return array{success: int, failed: int, errors: array, method: string}
     */
    public function setListingStatus(array $items, bool $active): array
    {
        $this->loadCredentials();

        $normalizedItems = [];
        $errors = [];
        $hbSkus = [];

        foreach ($items as $item) {
            $row = is_array($item) ? $item : ['hbSku' => (string) $item];
            $keys = $this->resolveListingKeys($row);

            if ($keys === []) {
                $errors[] = ['error' => 'Hepsiburada SKU bilgisi yok — satış durumu değiştirilemedi'];
                continue;
            }

            $normalizedItems[] = $row;
            if (!empty($keys['HepsiburadaSku'])) {
                $hbSkus[] = $keys['HepsiburadaSku'];
            }
        }

        if ($normalizedItems === []) {
            return ['success' => 0, 'failed' => count($errors), 'errors' => $errors, 'method' => 'none'];
        }

        // 1) Dedike uç nokta (tüm SKU'ların HB SKU'su varsa denenir)
        if ($hbSkus !== [] && count($hbSkus) === count($normalizedItems)) {
            $endpointResult = $active
                ? $this->activateListing($hbSkus)
                : $this->deactivateListing($hbSkus);

            if (($endpointResult['failed'] ?? 0) === 0 && ($endpointResult['success'] ?? 0) > 0) {
                return [
                    'success' => (int) $endpointResult['success'],
                    'failed'  => count($errors),
                    'errors'  => $errors,
                    'method'  => $active ? 'listing-activate' : 'listing-deactivate',
                ];
            }

            $this->logger->warning(
                'Hepsiburada activate/deactivate uç noktası sonuç vermedi, stok yöntemine düşülüyor: '
                . json_encode($endpointResult['errors'] ?? [], JSON_UNESCAPED_UNICODE),
                'HepsiburadaService'
            );
        }

        // 2) Resmî yöntem: stok 0 = satışa kapalı, stok > 0 = satışta
        $stockItems = [];
        foreach ($normalizedItems as $row) {
            $quantity = $active ? max(1, (int) ($row['quantity'] ?? 0)) : 0;

            if ($active && (int) ($row['quantity'] ?? 0) <= 0) {
                $errors[] = [
                    'error' => 'Satışa açmak için stok 0 olamaz — panelde stok girin: '
                        . implode('/', $this->resolveListingKeys($row)),
                ];
                continue;
            }

            $stockItems[] = $row + ['quantity' => $quantity];
        }

        if ($stockItems === []) {
            return ['success' => 0, 'failed' => count($errors), 'errors' => $errors, 'method' => 'stock-upload'];
        }

        $result = $this->updateStock($stockItems);

        return [
            'success' => (int) $result['success'],
            'failed'  => (int) $result['failed'] + count($errors),
            'errors'  => array_merge($errors, $result['errors']),
            'method'  => 'stock-upload',
        ];
    }

    /**
     * Listing silme (DELETE)
     *
     * HB uç noktası hem HB SKU'sunu hem satıcı stok kodunu ister:
     * /listings/merchantid/{merchantId}/sku/{sku}/merchantsku/{merchantSku}
     */
    public function deleteListing(string $hbSku, string $merchantSku = ''): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_delete']
            ?? '/listings/merchantid/{merchantId}/sku/{sku}/merchantsku/{merchantSku}';

        $path = str_replace(
            ['{merchantId}', '{sku}', '{hbSku}', '{merchantSku}'],
            [$this->merchantId, rawurlencode($hbSku), rawurlencode($hbSku), rawurlencode($merchantSku !== '' ? $merchantSku : $hbSku)],
            $endpoint
        );

        $this->httpDelete($this->getBaseUrl('listing') . $path, $this->authHeaders());
        return true;
    }

    /**
     * Listing bilgilerini sorgula
     */
    public function fetchListings(int $offset = 0, int $limit = 100): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listings'] ?? '/listings/merchantid/{merchantId}';
        $url = $this->buildUrl($endpoint, 'listing');
        $url .= '?' . http_build_query(['offset' => $offset, 'limit' => $limit]);

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // ÜRÜN İÇE AKTARMA
    // ═══════════════════════════════════════════════════════

    public function importProducts(int $page = 0, int $size = 100): array
    {
        // HB'de satışta + tükenmiş TÜM ürünler LISTINGS endpoint'inde bulunur.
        // (catalog/all-products-of-merchant yalnız satıcının kendi kataloğunu = az ürün döndürür.)
        // Caller page/size verir; HB listings offset/limit ister.
        $offset = max(0, $page) * $size;
        $response = $this->fetchListings($offset, $size);

        $rawProducts = (isset($response['listings']) && is_array($response['listings']))
            ? $response['listings']
            : $this->extractHbItems($response);

        $totalElements = (int) ($response['totalCount']
            ?? $response['totalElements']
            ?? $response['totalNumberOfElements']
            ?? count($rawProducts));
        $totalPages = ($size > 0) ? max(1, (int) ceil($totalElements / $size)) : 1;

        // Listings yanıtı yalnız sku/fiyat/stok taşır; ad/barkod/görsel/kategori
        // satıcının katalog ürünlerinden (eşleşiyorsa) tamamlanır.
        $detailMap = $this->loadCatalogDetailMap();

        $products = [];
        foreach ($rawProducts as $raw) {
            if (!is_array($raw)) {
                continue;
            }

            // Detay eşleştir (listings → catalog): hbSku / merchantSku / productId
            foreach ([$raw['hepsiburadaSku'] ?? null, $raw['hbSku'] ?? null, $raw['merchantSku'] ?? null, $raw['productId'] ?? null] as $lookup) {
                $lookup = (string) ($lookup ?? '');
                if ($lookup !== '' && isset($detailMap[$lookup])) {
                    // Yalnız listings'te olmayan detay alanlarını ekle (fiyat/stok ezilmez)
                    $raw += $detailMap[$lookup];
                    break;
                }
            }

            // Ad boşsa SKU'yu fallback yap ki ürün listesinde boş kalmasın
            if ((string) ($raw['productName'] ?? $raw['name'] ?? $raw['UrunAdi'] ?? '') === '') {
                $raw['productName'] = (string) ($raw['merchantSku'] ?? $raw['hepsiburadaSku'] ?? $raw['hbSku'] ?? 'HB Ürün');
            }

            $products[] = $this->normalizeImportProduct($raw);
        }

        return [
            'products'      => $products,
            'totalPages'    => $totalPages,
            'totalElements' => $totalElements,
        ];
    }

    /**
     * Satıcı katalog ürünlerinden detay haritası (barkod/görsel/kategori/marka).
     * Listings endpoint'i bu alanları taşımaz; all-products-of-merchant tüm sayfaları
     * bir kez gezilir ve hbSku + merchantSku ile indekslenir. Eşleşen listing'ler
     * bu detayla tamamlanır. (HB paylaşımlı katalog ürünlerinde detay satıcı API'sinde
     * bulunmayabilir; o ürünler sku/fiyat/stok ile gelir.)
     *
     * @return array<string, array<string, mixed>>
     */
    private function loadCatalogDetailMap(): array
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        // Süreç-içi static önbellek TEK istekte işe yarar; sihirbaz her ürün sayfasını
        // AYRI HTTP isteğinde çektiği için harita her seferinde sıfırdan kuruluyordu:
        // sayfa başına 50 ek API çağrısı (rate limit ile ~10 sn). Disk önbelleği bu
        // maliyeti koşum başına BİR kez ödetir.
        $diskCache = $this->catalogCachePath();
        if ($diskCache !== '' && is_file($diskCache) && (time() - (int) @filemtime($diskCache)) < self::CATALOG_CACHE_TTL) {
            $kayitli = json_decode((string) @file_get_contents($diskCache), true);
            if (is_array($kayitli)) {
                $cache = $kayitli;
                return $cache;
            }
        }

        $cache = [];
        $page = 0;
        $size = 100;
        $totalPages = 1;

        try {
            do {
                $resp  = $this->fetchProducts($page, $size);
                $items = $this->extractHbItems($resp);
                $totalPages = (int) ($resp['totalPages'] ?? 1);

                foreach ($items as $item) {
                    if (!is_array($item)) {
                        continue;
                    }
                    $detail = [];
                    foreach (['barcode', 'images', 'productName', 'brand', 'categoryId', 'categoryName', 'variantGroupId', 'description'] as $f) {
                        if (isset($item[$f]) && $item[$f] !== '' && $item[$f] !== []) {
                            $detail[$f] = $item[$f];
                        }
                    }
                    if ($detail === []) {
                        continue;
                    }
                    foreach ([$item['hbSku'] ?? null, $item['merchantSku'] ?? null] as $key) {
                        $key = (string) ($key ?? '');
                        if ($key !== '') {
                            $cache[$key] = $detail;
                        }
                    }
                }

                $page++;
            } while ($page < $totalPages && $page < 50);
        } catch (\Throwable $e) {
            // Detay zenginleştirme başarısız olsa bile listings importu sürmeli
            $this->logger->warning('HB katalog detay haritası yüklenemedi: ' . $e->getMessage(), 'Hepsiburada');
        }

        if ($cache !== [] && $diskCache !== '') {
            @file_put_contents($diskCache, json_encode($cache, JSON_UNESCAPED_UNICODE), LOCK_EX);
        }

        return $cache;
    }

    /**
     * Katalog detay haritasının disk önbellek yolu (mağaza + merchant bazında).
     * Yol üretilemezse '' döner ve önbellek devre dışı kalır.
     */
    private function catalogCachePath(): string
    {
        if (!defined('BASE_PATH') || $this->merchantId === '') {
            return '';
        }

        $dizin = BASE_PATH . '/storage/cache';
        if (!is_dir($dizin)) {
            @mkdir($dizin, 0755, true);
        }
        if (!is_dir($dizin) || !is_writable($dizin)) {
            return '';
        }

        return $dizin . '/hb_catalog_' . substr(sha1($this->merchantId), 0, 16) . '.json';
    }

    /**
     * HB ürün verisini normalize et (Mağaza Bazlı Ürün Bilgisi Listeleme)
     *
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    private function normalizeImportProduct(array $raw): array
    {
        // Görseller — HB Image1-Image5 formatı
        $images = [];
        for ($i = 1; $i <= 5; $i++) {
            $imgUrl = (string) ($raw["Image{$i}"] ?? $raw["image{$i}"] ?? '');
            if ($imgUrl !== '') {
                $images[] = [
                    'url'      => $imgUrl,
                    'is_cover' => $i === 1,
                    'sort'     => $i,
                ];
            }
        }
        // Alternatif: images array formatı
        if (empty($images) && !empty($raw['images'])) {
            foreach ($raw['images'] as $idx => $img) {
                $url = is_string($img) ? $img : (string) ($img['url'] ?? '');
                if ($url !== '') {
                    $images[] = [
                        'url'      => $url,
                        'is_cover' => $idx === 0,
                        'sort'     => $idx + 1,
                    ];
                }
            }
        }

        // Özellikler
        $attributes = [];
        if (!empty($raw['attributes']) && is_array($raw['attributes'])) {
            foreach ($raw['attributes'] as $attrKey => $attrVal) {
                if (is_array($attrVal)) {
                    $attributes[] = [
                        'name'  => (string) ($attrVal['name'] ?? $attrKey),
                        'value' => (string) ($attrVal['value'] ?? ''),
                    ];
                } else {
                    $attributes[] = [
                        'name'  => (string) $attrKey,
                        'value' => (string) $attrVal,
                    ];
                }
            }
        }

        // Marka — HB'de attribute olarak gelir
        $brandName = (string) ($raw['Marka'] ?? $raw['brand'] ?? $raw['brandName'] ?? '');
        if (empty($brandName)) {
            foreach ($attributes as $attr) {
                if (in_array(strtolower($attr['name']), ['marka', 'brand'], true)) {
                    $brandName = $attr['value'];
                    break;
                }
            }
        }

        $normalized = [
            'marketplace_sku'        => (string) ($raw['merchantSku'] ?? $raw['merchantsku'] ?? ''),
            'marketplace_product_id' => (string) ($raw['hbSku'] ?? $raw['hepsiburadaSku'] ?? ''),
            'barcode'                => (string) ($raw['Barcode'] ?? $raw['barcode'] ?? ''),
            'name'                   => (string) ($raw['UrunAdi'] ?? $raw['productName'] ?? $raw['name'] ?? ''),
            'category_name'          => (string) ($raw['categoryName'] ?? ''),
            'category_id'            => (string) ($raw['categoryId'] ?? ''),
            'brand_name'             => $brandName,
            'brand_id'               => '',
            'price'                  => (float) ($raw['price'] ?? 0),
            'list_price'             => (float) ($raw['listPrice'] ?? $raw['price'] ?? 0),
            'currency'               => 'TRY',
            'is_active'              => (isset($raw['isSuspended']) || isset($raw['isFrozen']))
                ? !(($raw['isSuspended'] ?? false) || ($raw['isFrozen'] ?? false)) // tükenmiş ama askıda değilse aktif kalsın
                : (bool) ($raw['isSalable'] ?? $raw['isActive'] ?? true),
            'group_id'               => (string) ($raw['variantGroupId'] ?? $raw['productCode'] ?? ''),
            'images'                 => $images,
            'attributes'             => $attributes,
            'raw'                    => $raw,
        ];

        if (array_key_exists('availableStock', $raw)) {
            $normalized['stock'] = (int) $raw['availableStock'];
        } elseif (array_key_exists('stock', $raw)) {
            $normalized['stock'] = (int) $raw['stock'];
        }

        return $normalized;
    }

    // ═══════════════════════════════════════════════════════
    // KATEGORİ / MARKA / ÖZELLİKLER
    // ═══════════════════════════════════════════════════════

    public function fetchCategories(int $parentId = 0): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['category_list']
            ?? '/product/api/categories/get-all-categories';
        $baseUrl = $this->getBaseUrl('catalog') . $endpoint;

        $allCategories = [];
        $page = 0;
        $size = 2000;
        $this->startPaging('hb.categories');

        do {
            $url = $baseUrl . '?' . http_build_query(['page' => $page, 'size' => $size]);
            $response = $this->httpGet($url, $this->authHeaders());

            $items = $response['data'] ?? [];
            if (empty($items)) {
                break;
            }

            foreach ($items as $item) {
                $allCategories[] = [
                    'id'   => (string) ($item['categoryId'] ?? ''),
                    'name' => $item['name'] ?? $item['displayName'] ?? '',
                    'parentId' => !empty($item['parentCategoryId']) ? (string) $item['parentCategoryId'] : null,
                    'leaf' => (bool) ($item['leaf'] ?? false),
                    'paths' => $item['paths'] ?? [],
                ];
            }

            $totalPages = $response['totalPages'] ?? 1;
            $page++;
        } while ($page < $totalPages && $this->keepPaging('hb.categories', $page, $items));

        return $allCategories;
    }

    public function fetchBrands(string $search = ''): array
    {
        // HB'de ayrı marka API'si yok — ürünlerden unique markaları çıkar
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['products_all']
            ?? '/product/api/products/all-products-of-merchant/{merchantId}';
        $baseUrl = $this->getBaseUrl('catalog') . str_replace('{merchantId}', $this->merchantId, $endpoint);

        $brands = [];
        $page = 0;
        $size = 500;

        // HB'de marka API'si yok; markalar ÜRÜN kataloğundan çıkarılıyor. Katalog
        // büyükse (ya da API sayfalamayı yok sayıyorsa) bu döngü binlerce isteğe
        // kadar sürer ve süreci kilitler — 2026-08-25'te 4.735 sayfa / 60 dakika.
        // Bu yüzden dar bir bütçe uygulanır; sonuç kısmi olabilir.
        $this->startPaging('hb.brands', 25, 30.0);

        do {
            $url = $baseUrl . '?' . http_build_query(['page' => $page, 'size' => $size]);

            try {
                $response = $this->httpGet($url, $this->authHeaders());
            } catch (\Throwable $e) {
                break;
            }

            $items = $response['data'] ?? [];
            if (empty($items)) {
                break;
            }

            foreach ($items as $item) {
                $brandName = (string) ($item['brand'] ?? $item['Marka'] ?? '');
                if ($brandName === '') {
                    // baseAttributes'ten çıkar
                    foreach ($item['baseAttributes'] ?? [] as $attr) {
                        if (in_array(strtolower($attr['name'] ?? ''), ['marka', 'brand'], true)) {
                            $brandName = (string) ($attr['value'] ?? '');
                            break;
                        }
                    }
                }
                if ($brandName !== '' && ($search === '' || stripos($brandName, $search) !== false)) {
                    $key = mb_strtolower($brandName);
                    if (!isset($brands[$key])) {
                        $brands[$key] = [
                            'id'   => md5('hb_brand_' . $key),
                            'name' => $brandName,
                        ];
                    }
                }
            }

            $totalPages = $response['totalPages'] ?? 1;
            $page++;
        } while ($page < $totalPages && $this->keepPaging('hb.brands', $page, $items));

        if ($this->pagingStopped('hb.brands')) {
            $this->logger->info(
                sprintf('HB marka listesi kısmi çıkarıldı: %d marka (%d sayfa tarandı).', count($brands), $page),
                'HepsiburadaService'
            );
        }

        return array_values($brands);
    }

    public function fetchCategoryAttributes(string $marketplaceCategoryId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['categories']
            ?? '/product/api/categories/{categoryId}/attributes';
        $url = str_replace('{categoryId}', $marketplaceCategoryId, $this->getBaseUrl('catalog') . $endpoint);

        $response = $this->httpGet($url, $this->authHeaders());

        return $response['data'] ?? $response ?? [];
    }

    /**
     * Özellik değerlerini al (enum type özellikler için)
     *
     * @return array<int, array{id: string, value: string}>
     */
    public function fetchAttributeValues(string $categoryId, string $attributeId, int $page = 0, int $limit = 1000): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['attribute_values']
            ?? '/product/api/categories/{categoryId}/attributes/{attributeId}/values';
        $url = str_replace(
            ['{categoryId}', '{attributeId}'],
            [$categoryId, $attributeId],
            $this->getBaseUrl('catalog') . $endpoint
        );
        $url .= '?' . http_build_query(['page' => $page, 'limit' => $limit]);

        $response = $this->httpGet($url, $this->authHeaders());

        return $response['data'] ?? $response ?? [];
    }

    // ═══════════════════════════════════════════════════════
    // İADE (TALEP) İŞLEMLERİ
    // ═══════════════════════════════════════════════════════

    public function fetchReturns(array $filters = []): array
    {
        $this->loadCredentials();

        $allClaims = [];
        $limit = (int) ($this->config['api']['page_size'] ?? 100);
        $statuses = !empty($filters['status'])
            ? [(string) $filters['status']]
            : [''];

        foreach ($statuses as $status) {
            $offset = 0;
            $this->startPaging('hb.claims.' . $status);
            do {
                if ($status !== '') {
                $statusEndpoint = $this->config['endpoints']['claims_by_status']
                    ?? '/claims/merchantid/{merchantId}/status/{status}';
                $url = str_replace('{status}', $status, $this->buildUrl($statusEndpoint, 'claim'));
            } else {
                $endpoint = $this->config['endpoints']['claims'] ?? '/claims/merchantid/{merchantId}';
                $url = $this->buildUrl($endpoint, 'claim');
            }

            $queryParams = ['offset' => $offset, 'limit' => $limit];

            // Tarih filtreleri
            if (!empty($filters['begin_date'])) {
                $queryParams['begindate'] = $this->formatHbDateParam($filters['begin_date']);
            }
            if (!empty($filters['end_date'])) {
                $queryParams['enddate'] = $this->formatHbDateParam($filters['end_date']);
            }

            $url .= '?' . http_build_query($queryParams);

            $response = $this->httpGet($url, $this->authHeaders());

            $claims = $this->extractHbItems($response);
            if (empty($claims)) {
                break;
            }

            $allClaims = array_merge($allClaims, $claims);
            $offset += $limit;

            } while (count($claims) === $limit
                && $this->keepPaging('hb.claims.' . $status, (int) ($offset / max(1, $limit)), $claims));
        }

        return $this->deduplicateHbClaims($allClaims);
    }

    private function formatHbDateParam(mixed $value): string
    {
        $raw = (string) $value;
        $ts = strtotime($raw);

        return $ts !== false ? date('Y-m-d', $ts) : $raw;
    }

    private function deduplicateHbClaims(array $claims): array
    {
        $deduped = [];
        foreach ($claims as $claim) {
            if (!is_array($claim)) {
                continue;
            }
            $key = (string) ($claim['claimNumber'] ?? $claim['claimId'] ?? $claim['id'] ?? md5(json_encode($claim)));
            $deduped[$key] = $claim;
        }

        return array_values($deduped);
    }

    public function approveReturn(string $returnId): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['claim_accept'] ?? '/claims/number/{claimNumber}/accept';
        $url = str_replace('{claimNumber}', $returnId, $this->getBaseUrl('claim') . $endpoint);

        $this->httpPost($url, null, $this->authHeaders());
        return true;
    }

    public function rejectReturn(string $returnId, string $reason = ''): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['claim_reject'] ?? '/claims/number/{claimNumber}/reject';
        $url = str_replace('{claimNumber}', $returnId, $this->getBaseUrl('claim') . $endpoint);

        $body = [];
        if ($reason !== '') {
            $body['ClaimRejectionReason'] = $reason;
        }

        $this->httpPost($url, !empty($body) ? $body : null, $this->authHeaders());
        return true;
    }

    // ═══════════════════════════════════════════════════════
    // MUHASEBE
    // ═══════════════════════════════════════════════════════

    /**
     * Muhasebe kayıtlarını al
     */
    public function fetchTransactions(array $filters = []): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['transactions']
            ?? '/transactions/merchantid/{merchantId}';
        $url = $this->buildUrl($endpoint, 'finance');

        $queryParams = [];
        // HB finans API'si begindate/enddate yerine timespan (gün) bekliyor
        if (!empty($filters['begin_date']) && !empty($filters['end_date'])) {
            $startTs = strtotime($filters['begin_date']);
            $endTs   = strtotime($filters['end_date']);
            if ($startTs !== false && $endTs !== false) {
                $days = max(1, (int) ceil(($endTs - $startTs) / 86400));
                $queryParams['timespan'] = $days;
            }
        } elseif (!empty($filters['timespan'])) {
            $queryParams['timespan'] = (int) $filters['timespan'];
        }
        $queryParams['offset'] = $filters['offset'] ?? 0;
        $queryParams['limit']  = $filters['limit'] ?? 100;

        $url .= '?' . http_build_query($queryParams);

        try {
            return $this->httpGet($url, $this->authHeaders());
        } catch (\Throwable $e) {
            $this->logger->warning(
                "HB finans/transactions API erişilemiyor: {$e->getMessage()}",
                'HepsiburadaService'
            );
            return [];
        }
    }

    /**
     * Soru listesini al
     */
    public function fetchQuestions(array $filters = []): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['questions']
            ?? '/merchantid/{merchantId}/questions';
        $url = $this->buildUrl($endpoint, 'question');

        $queryParams = [];
        if (!empty($filters['status'])) {
            $queryParams['status'] = $filters['status'];
        }
        $queryParams['offset'] = $filters['offset'] ?? 0;
        $queryParams['limit']  = $filters['limit'] ?? 50;

        $url .= '?' . http_build_query($queryParams);

        try {
            return $this->httpGet($url, $this->authHeaders());
        } catch (\Throwable $e) {
            $this->logger->warning(
                "HB soru/cevap API erişilemiyor: {$e->getMessage()}",
                'HepsiburadaService'
            );
            return [];
        }
    }

    /**
     * Soruyu cevapla
     */
    public function answerQuestion(string $questionId, string $answer): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['question_answer']
            ?? '/merchantid/{merchantId}/questions/{questionId}/answers';
        $url = str_replace('{questionId}', $questionId, $this->buildUrl($endpoint, 'question'));

        $this->httpPost($url, ['text' => $answer], $this->authHeaders());
        return true;
    }

    // ═══════════════════════════════════════════════════════
    // LİSTELEME — ENVANTER GÜNCELLEME (Fiyat+Stok+Dispatch birlikte)
    // ═══════════════════════════════════════════════════════

    /**
     * Listing envanter güncelleme (Fiyat + Stok + DispatchTime birlikte)
     *
     * HB listeleme entegrasyonundaki ana güncelleme endpoint'i.
     * Toplu güncelleme - tek seferde max 4000 SKU.
     *
     * @param array<int, array{
     *   HepsiburadaSku?: string,
     *   MerchantSku?: string,
     *   Price: string,
     *   AvailableStock: int,
     *   DispatchTime: int,
     *   CargoCompany1?: string,
     *   CargoCompany2?: string,
     *   CargoCompany3?: string,
     *   MaximumPurchasableQuantity?: int,
     *   ShippingProfileName?: string
     * }> $listings
     * @return array{uploadId: string|null, success: bool}
     */
    public function updateInventory(array $listings): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_inventory']
            ?? '/listings/merchantid/{merchantId}/inventory-uploads';
        $url = $this->getBaseUrl('listing') . str_replace('{merchantId}', $this->merchantId, $endpoint);

        // HB envanter yüklemesi de XML gövde bekler.
        $response = $this->httpPostRaw($url, $this->buildListingXml($listings), $this->listingXmlHeaders());
        $uploadId = $this->extractUploadId($response);

        return [
            'uploadId' => $uploadId,
            'success'  => $uploadId !== null,
        ];
    }

    /**
     * Listing envanter güncelleme durumu sorgulama
     */
    public function checkInventoryStatus(string $uploadId): array
    {
        $this->loadCredentials();

        return $this->checkUploadStatus('inventory', $uploadId);
    }

    /**
     * Listing stok güncelleme durumu sorgulama
     */
    public function checkStockStatus(string $uploadId): array
    {
        $this->loadCredentials();

        return $this->checkUploadStatus('stock', $uploadId);
    }

    /**
     * Listing fiyat güncelleme durumu sorgulama
     */
    public function checkPriceStatus(string $uploadId): array
    {
        $this->loadCredentials();

        return $this->checkUploadStatus('price', $uploadId);
    }

    /**
     * Listing teslimat güncelleme (DispatchTime)
     *
     * @param array<int, array{HepsiburadaSku?: string, MerchantSku?: string, DispatchTime: int}> $listings
     */
    public function updateDelivery(array $listings): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_delivery'] ?? '/listings/delivery-uploads';
        $url = $this->getBaseUrl('listing') . $endpoint;

        $response = $this->httpPost($url, ['listings' => $listings], $this->authHeaders());

        return [
            'uploadId' => $response['id'] ?? null,
            'success'  => !empty($response['id']),
        ];
    }

    /**
     * Listing teslimat güncelleme durumu sorgulama
     */
    public function checkDeliveryStatus(string $uploadId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_delivery_check']
            ?? '/listings/delivery-uploads/{uploadId}';
        $url = str_replace('{uploadId}', $uploadId, $this->getBaseUrl('listing') . $endpoint);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Listing ek bilgi güncelleme (CustomizableProperties vb.)
     *
     * @param array<int, array{HepsiburadaSku?: string, MerchantSku?: string}> $listings
     */
    public function updateExtraInfo(array $listings): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_extra_info'] ?? '/listings/extra-info-uploads';
        $url = $this->getBaseUrl('listing') . $endpoint;

        $response = $this->httpPost($url, ['listings' => $listings], $this->authHeaders());

        return [
            'uploadId' => $response['id'] ?? null,
            'success'  => !empty($response['id']),
        ];
    }

    /**
     * Listing ek bilgi güncelleme durumu sorgulama
     */
    public function checkExtraInfoStatus(string $uploadId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_extra_info_check']
            ?? '/listings/extra-info-uploads/{uploadId}';
        $url = str_replace('{uploadId}', $uploadId, $this->getBaseUrl('listing') . $endpoint);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Tekil listing güncelleme (tek SKU için fiyat/stok)
     */
    public function updateSingleListing(string $hbSku, float $price, int $stock, int $dispatchTime = 3): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_single_update'] ?? '/listings/tekil-update';
        $url = $this->getBaseUrl('listing') . $endpoint;

        $payload = [
            'listings' => [[
                'HepsiburadaSku'  => $hbSku,
                'MerchantId'      => $this->merchantId,
                'Price'           => number_format($price, 2, ',', ''),
                'AvailableStock'  => $stock,
                'DispatchTime'    => $dispatchTime,
            ]],
        ];

        return $this->httpPost($url, $payload, $this->authHeaders());
    }

    /**
     * Toplu kilit kaldırma (fiyat kilidi sonrası)
     *
     * @param array<int, string> $hbSkus
     */
    public function unlockListings(array $hbSkus): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_unlock'] ?? '/listings/unlock';
        $url = $this->getBaseUrl('listing') . $endpoint;

        $payload = ['listings' => array_map(fn(string $sku) => [
            'HepsiburadaSku' => $sku,
            'MerchantId'     => $this->merchantId,
        ], $hbSkus)];

        return $this->httpPost($url, $payload, $this->authHeaders());
    }

    /**
     * Buybox sıralama sorgulama
     *
     * @param array<int, string> $hbSkus Maksimum 10 SKU
     */
    public function fetchBuyboxInfo(array $hbSkus): array
    {
        $this->loadCredentials();

        $skuParam = implode(',', array_slice($hbSkus, 0, 10));
        $endpoint = $this->config['endpoints']['listing_buybox'] ?? '/listings/buybox';
        $url = $this->getBaseUrl('listing') . $endpoint;
        $url .= '?' . http_build_query(['sku' => $skuParam]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Komisyon bilgisi sorgulama
     *
     * @param array<int, string> $hbSkus Maksimum 50 SKU
     */
    public function fetchCommissions(array $hbSkus): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_commissions'] ?? '/listings/commissions';
        $url = $this->getBaseUrl('listing') . $endpoint;

        $skuParam = implode(',', array_slice($hbSkus, 0, 50));
        $url .= '?' . http_build_query(['merchantId' => $this->merchantId, 'sku' => $skuParam]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Listing bilgisini SKU ile sorgula
     */
    public function fetchListingBySku(string $sku, string $type = 'merchant'): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['listing_by_sku'] ?? '/listings/merchantid/{merchantId}';
        $url = $this->buildUrl($endpoint, 'listing');

        $param = $type === 'hb' ? 'hepsiburadaSku' : 'merchantSku';
        $url .= '?' . http_build_query([$param => $sku]);

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // PAKET — EK İŞLEMLER
    // ═══════════════════════════════════════════════════════

    /**
     * Faturası yüklenmemiş paketleri listele
     */
    public function fetchMissingInvoicePackages(int $offset = 0, int $limit = 50): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packages_missing_invoice']
            ?? '/packages/merchantid/{merchantId}/missing-invoice';
        $url = $this->buildUrl($endpoint, 'order');
        $url .= '?' . http_build_query(['offset' => $offset, 'limit' => $limit]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Kargoya verilmiş paketleri listele
     */
    public function fetchShippedPackages(int $offset = 0, int $limit = 50, array $filters = []): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packages_shipped']
            ?? '/packages/merchantid/{merchantId}/shipped';
        $url = $this->buildUrl($endpoint, 'order');

        $queryParams = ['offset' => $offset, 'limit' => $limit];
        if (!empty($filters['begin_date'])) {
            $queryParams['begindate'] = $this->formatHbDateParam($filters['begin_date']);
        }
        if (!empty($filters['end_date'])) {
            $queryParams['enddate'] = $this->formatHbDateParam($filters['end_date']);
        }
        $url .= '?' . http_build_query($queryParams);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Teslim edilmiş paketleri listele
     */
    public function fetchDeliveredPackages(int $offset = 0, int $limit = 50, array $filters = []): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packages_delivered']
            ?? '/packages/merchantid/{merchantId}/delivered';
        $url = $this->buildUrl($endpoint, 'order');

        $queryParams = ['offset' => $offset, 'limit' => $limit];
        if (!empty($filters['begin_date'])) {
            $queryParams['begindate'] = $this->formatHbDateParam($filters['begin_date']);
        }
        if (!empty($filters['end_date'])) {
            $queryParams['enddate'] = $this->formatHbDateParam($filters['end_date']);
        }
        $url .= '?' . http_build_query($queryParams);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Teslim edilemedi paketleri listele
     */
    public function fetchUndeliveredPackages(int $offset = 0, int $limit = 50): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packages_undelivered']
            ?? '/packages/merchantid/{merchantId}/undelivered';
        $url = $this->buildUrl($endpoint, 'order');
        $url .= '?' . http_build_query(['offset' => $offset, 'limit' => $limit]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Bozulan (unpack) paketleri listele
     */
    public function fetchUnpackedPackages(int $offset = 0, int $limit = 50): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packages_unpacked']
            ?? '/packages/merchantid/{merchantId}/status/unpacked';
        $url = $this->buildUrl($endpoint, 'order');
        $url .= '?' . http_build_query(['offset' => $offset, 'limit' => $limit]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Paket kargo bilgisi detayı
     */
    public function fetchPackageCargoInfo(string $packageNumber): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_cargo_info']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}';
        $url = str_replace('{packageNumber}', $packageNumber, $this->buildUrl($endpoint, 'order'));

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Paket için değiştirilebilir kargo firmalarını listele
     */
    public function fetchChangeableCargoCompanies(string $packageNumber): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_changeable_cargo']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}/changablecargocompanies';
        $url = str_replace('{packageNumber}', $packageNumber, $this->buildUrl($endpoint, 'order'));

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Paket kargo firmasını değiştir
     */
    public function changePackageCargo(string $packageNumber, string $cargoCompany): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_change_cargo']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}/changecargocompany';
        $url = str_replace('{packageNumber}', $packageNumber, $this->buildUrl($endpoint, 'order'));

        $this->httpPut($url, ['cargoCompany' => $cargoCompany], $this->authHeaders());
        return true;
    }

    /**
     * Paket bölme
     *
     * @param array<int, array{id: string, quantity: int}> $lineItems
     */
    public function splitPackage(string $packageNumber, array $lineItems): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_split']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}/split';
        $url = str_replace('{packageNumber}', $packageNumber, $this->buildUrl($endpoint, 'order'));

        return $this->httpPost($url, ['lineItemRequests' => $lineItems], $this->authHeaders());
    }

    /**
     * Paket depo bilgisi güncelleme
     */
    public function updatePackageWarehouse(string $packageNumber, string $warehouseId): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['package_warehouse']
            ?? '/packages/merchantid/{merchantId}/packagenumber/{packageNumber}/warehouse';
        $url = str_replace('{packageNumber}', $packageNumber, $this->buildUrl($endpoint, 'order'));

        $this->httpPut($url, ['warehouseId' => $warehouseId], $this->authHeaders());
        return true;
    }

    // ═══════════════════════════════════════════════════════
    // SATIR İŞLEMLERİ — EK
    // ═══════════════════════════════════════════════════════

    /**
     * Paketlenecek sipariş kaleminin kargo firmasını değiştir
     */
    public function changeLineCargo(string $lineItemId, string $cargoCompany): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['line_cargo_change']
            ?? '/lineitems/merchantid/{merchantId}/orderlineid/{id}/cargocompany';
        $url = str_replace('{id}', $lineItemId, $this->buildUrl($endpoint, 'order'));

        $this->httpPut($url, ['cargoCompany' => $cargoCompany], $this->authHeaders());
        return true;
    }

    /**
     * Paketlenecek sipariş kaleminin değiştirilebilir kargo firmalarını listele
     */
    public function fetchLineChangeableCargoCompanies(string $lineItemId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['line_changeable_cargo']
            ?? '/delivery/changeablecargocompanies/merchantid/{merchantId}/orderlineid/{id}';
        $url = str_replace('{id}', $lineItemId, $this->buildUrl($endpoint, 'order'));

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Sipariş kalemi işçilik maliyeti güncelleme
     */
    public function updateLineLaborCost(string $lineItemId, float $laborCost): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['line_labor_cost']
            ?? '/lineitems/merchantid/{merchantId}/orderlineid/{id}/laborcost';
        $url = str_replace('{id}', $lineItemId, $this->buildUrl($endpoint, 'order'));

        $this->httpPut($url, ['laborCost' => $laborCost], $this->authHeaders());
        return true;
    }

    /**
     * Aynı pakete konulabilecek kalemleri listele
     */
    public function fetchPackageableItems(string $lineItemId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['packageable_items']
            ?? '/lineitems/merchantid/{merchantId}/packageablewith/lineitemid/{lineItemId}';
        $url = str_replace('{lineItemId}', $lineItemId, $this->buildUrl($endpoint, 'order'));

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // PROFİL / KARGO FİRMASI / TESLİMAT PROFİLİ
    // ═══════════════════════════════════════════════════════

    /**
     * Kargo firmalarını listele
     */
    public function fetchCargoFirms(): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['cargo_firms'] ?? '/cargofirms/{merchantId}';
        $url = $this->buildUrl($endpoint, 'order');

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Teslimat profili oluştur
     *
     * @param array{
     *   name: string,
     *   cargoCompany1: string,
     *   cargoCompany2?: string,
     *   cargoCompany3?: string,
     *   city?: string,
     *   district?: string
     * } $profileData
     */
    public function createProfile(array $profileData): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['profile_create'] ?? '/profile/createByMerchantId';
        $url = $this->getBaseUrl('order') . $endpoint;

        $profileData['merchantId'] = $this->merchantId;

        return $this->httpPost($url, $profileData, $this->authHeaders());
    }

    /**
     * Teslimat profili güncelle
     */
    public function updateProfile(array $profileData): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['profile_update'] ?? '/profile/updateByMerchantId';
        $url = $this->getBaseUrl('order') . $endpoint;

        $profileData['merchantId'] = $this->merchantId;

        return $this->httpPut($url, $profileData, $this->authHeaders());
    }

    /**
     * Teslimat profillerini listele
     */
    public function fetchProfiles(): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['profile_list'] ?? '/profiles/{merchantId}';
        $url = $this->buildUrl($endpoint, 'order');

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * ShippingProfileName listele (listing bazlı)
     */
    public function fetchShippingProfiles(): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['shipping_profiles'] ?? '/listings/shipping-profiles';
        $url = $this->getBaseUrl('listing') . $endpoint;
        $url .= '?' . http_build_query(['merchantId' => $this->merchantId]);

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // SATICIYA SOR — EK İŞLEMLER
    // ═══════════════════════════════════════════════════════

    /**
     * Soru detayı çek
     */
    public function fetchQuestionDetail(string $questionId): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['question_detail']
            ?? '/merchantid/{merchantId}/questions/{questionId}';
        $url = str_replace('{questionId}', $questionId, $this->buildUrl($endpoint, 'question'));

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Soru sorun bildirme
     */
    public function reportQuestion(string $questionId, string $reason = ''): bool
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['question_report']
            ?? '/merchantid/{merchantId}/questions/{questionId}/report';
        $url = str_replace('{questionId}', $questionId, $this->buildUrl($endpoint, 'question'));

        $body = [];
        if ($reason !== '') {
            $body['reason'] = $reason;
        }

        $this->httpPost($url, !empty($body) ? $body : null, $this->authHeaders());
        return true;
    }

    /**
     * Statü bazlı soru sayılarını al
     */
    public function fetchQuestionCounts(): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['question_counts']
            ?? '/merchantid/{merchantId}/questions/counts';
        $url = $this->buildUrl($endpoint, 'question');

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // SİPARİŞ — EK SORGULAMA
    // ═══════════════════════════════════════════════════════

    /**
     * İptal edilen siparişleri listele
     */
    public function fetchCancelledOrders(int $offset = 0, int $limit = 50): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['orders_cancelled']
            ?? '/orders/merchantid/{merchantId}/cancelled';
        $url = $this->buildUrl($endpoint, 'order');
        $url .= '?' . http_build_query(['offset' => $offset, 'limit' => $limit]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Ödemesi beklenen siparişleri listele
     */
    public function fetchPaymentAwaitingOrders(int $offset = 0, int $limit = 50): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['orders_payment_awaiting']
            ?? '/orders/merchantid/{merchantId}/paymentawaiting';
        $url = $this->buildUrl($endpoint, 'order');
        $url .= '?' . http_build_query(['offset' => $offset, 'limit' => $limit]);

        return $this->httpGet($url, $this->authHeaders());
    }

    /**
     * Sipariş detayı al (orderNumber ile)
     */
    public function fetchOrderDetail(string $orderNumber): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['order_detail']
            ?? '/orders/merchantid/{merchantId}/ordernumber/{orderNumber}';
        $url = str_replace('{orderNumber}', $orderNumber, $this->buildUrl($endpoint, 'order'));

        return $this->httpGet($url, $this->authHeaders());
    }

    // ═══════════════════════════════════════════════════════
    // ÜRÜN GÜNCELLEME (Ticket sistemi)
    // ═══════════════════════════════════════════════════════

    /**
     * Ürün güncelleme isteği gönder (Katalog'da onaylanmış ürünler için)
     *
     * @param array<int, array<string, mixed>> $products
     * @return array{trackingId: string|null, success: bool, message: string}
     */
    public function updateProduct(array $products): array
    {
        $this->loadCredentials();

        $endpoint = $this->config['endpoints']['product_update'] ?? '/product/api/products/ticket-import';
        $url = $this->getBaseUrl('catalog') . $endpoint;

        // JSON dosyası form-data olarak yüklenir (uploadProduct ile aynı mantık)
        $tmpDir = BASE_PATH . '/storage/tmp';
        if (!is_dir($tmpDir)) {
            mkdir($tmpDir, 0755, true);
        }
        $tmpFile = $tmpDir . '/hb_product_update_' . uniqid() . '.json';

        try {
            $jsonContent = json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            if ($jsonContent === false) {
                throw new RuntimeException('Ürün güncelleme verileri JSON\'a dönüştürülemedi');
            }
            file_put_contents($tmpFile, $jsonContent);

            $response = $this->httpPostMultipart($url, $tmpFile, 'file', $this->authHeaders());

            $trackingId = $response['data']['trackingId'] ?? $response['trackingId'] ?? null;

            return [
                'trackingId' => $trackingId,
                'success'    => !empty($trackingId),
                'message'    => $response['message'] ?? 'Ürün güncelleme isteği gönderildi',
            ];
        } finally {
            if (file_exists($tmpFile)) {
                unlink($tmpFile);
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    // YARDIMCI METHODLAR
    // ═══════════════════════════════════════════════════════

    /**
     * HB fiyat objesinden tutarı çıkar ({Amount: x, Currency: y} veya direkt float)
     */
    private function extractAmount(mixed $value): float
    {
        if (is_array($value)) {
            return (float) ($value['amount'] ?? $value['Amount'] ?? 0);
        }
        return (float) $value;
    }

    /**
     * HB tarih formatını Y-m-d H:i:s'e çevir
     */
    private function parseHbDate(mixed $dateValue): string
    {
        if (empty($dateValue)) {
            return date('Y-m-d H:i:s');
        }

        $dateStr = (string) $dateValue;

        // Epoch ms
        if (is_numeric($dateStr) && (float) $dateStr > 10000000000) {
            return date('Y-m-d H:i:s', (int) ((float) $dateStr / 1000));
        }

        // ISO 8601
        if (str_contains($dateStr, 'T')) {
            return str_replace('T', ' ', substr($dateStr, 0, 19));
        }

        // Y-m-d H:i:s
        if (str_contains($dateStr, '-') && strlen($dateStr) >= 10) {
            return substr($dateStr, 0, 19);
        }

        return date('Y-m-d H:i:s');
    }
}
 
