<?php
/**
 * OzyConnect Panel — SyncController
 *
 * @package    OzyConnect
 * @author     OziyWeb <oziyweb@hotmail.com>
 * @copyright  © 2025 OziyWeb. Tüm Hakları Saklıdır.
 * @license    Proprietary
 * @version    2.0.0
 * @since      2025-01-01
 * @link       https://www.oziyweb.com.tr
 */
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Container;
use App\Core\Request;
use App\Models\Marketplace;
use App\Models\SyncLog;
use App\Services\Sync\OrderSyncService;
use App\Services\Sync\PriceSyncService;
use App\Services\Sync\StockSyncService;
use App\Services\Sync\ReturnSyncService;
use App\Models\Setting;

final class SyncController extends BaseController
{
    private readonly SyncLog $syncLogModel;
    private readonly Marketplace $marketplaceModel;
    private readonly OrderSyncService $orderSync;
    private readonly StockSyncService $stockSync;
    private readonly PriceSyncService $priceSync;
    private readonly ReturnSyncService $returnSync;
    private readonly Setting $settings;

    public function __construct(Container $container)
    {
        parent::__construct($container);
        $this->syncLogModel     = $container->get(SyncLog::class);
        $this->marketplaceModel = $container->get(Marketplace::class);
        $this->orderSync        = $container->get(OrderSyncService::class);
        $this->stockSync        = $container->get(StockSyncService::class);
        $this->priceSync        = $container->get(PriceSyncService::class);
        $this->returnSync       = $container->get(ReturnSyncService::class);
        $this->settings         = $container->get(Setting::class);
    }

    public function index(Request $request): void
    {
        $logs = $this->syncLogModel->getRecent(50);
        $marketplaces = $this->marketplaceModel->getActive();
        $lastSuccessful = $this->syncLogModel->getLastSuccessful();

        // Generate cron token if not exists
        $cronToken = $this->settings->get('cron_token', '');
        if (empty($cronToken)) {
            $cronToken = bin2hex(random_bytes(16));
            $this->settings->set('cron_token', $cronToken);
        }

        // Sync ayarlarını yükle
        $syncSettings = $this->settings->getByGroup('sync');
        $syncConfig = [];
        foreach ($syncSettings as $key => $s) {
            $syncConfig[$key] = $s['value'];
        }

        $this->view('sync.index', [
            'pageTitle'      => 'Senkronizasyon',
            'logs'           => $logs,
            'marketplaces'   => $marketplaces,
            'lastSuccessful' => $lastSuccessful,
            'cronToken'      => $cronToken,
            'syncConfig'     => $syncConfig,
        ]);
    }

    /**
     * Sync ayarlarını kaydet (AJAX)
     */
    public function saveSettings(Request $request): void
    {
        $data = $request->json();

        $validTypes = ['orders', 'stock', 'price', 'returns', 'questions', 'products'];
        $validIntervals = [1, 2, 5, 10, 15, 30, 60, 120, 360];

        $userId = $_SESSION['user_id'] ?? null;
        $updated = [];

        foreach ($validTypes as $type) {
            // Toggle (enabled/disabled)
            $enabledKey = "sync_{$type}_enabled";
            if (isset($data[$enabledKey])) {
                $val = $data[$enabledKey] ? '1' : '0';
                $this->settings->set($enabledKey, $val, $userId, 'bool', 'sync');
                $updated[$enabledKey] = $val;
            }

            // Interval
            $intervalKey = "sync_{$type}_interval";
            if (isset($data[$intervalKey])) {
                $interval = (int) $data[$intervalKey];
                if (in_array($interval, $validIntervals, true)) {
                    $this->settings->set($intervalKey, (string) $interval, $userId, 'int', 'sync');
                    $updated[$intervalKey] = $interval;
                }
            }
        }

        $this->success($updated, 'Senkronizasyon ayarları güncellendi');
    }

    // ─── Manual Triggers ───────────────────────────────────

    public function triggerOrders(Request $request): void
    {
        try {
            // Sipariş sync uzun sürebilir — PHP timeout'ı kaldır
            set_time_limit(0);
            $this->runSync('orders', fn() => $this->orderSync->syncAll('manual'), $request);
        } catch (\Throwable $e) {
            $this->logger->error('Order sync error: ' . $e->getMessage(), 'Sync');
            if ($request->isAjax()) {
                $this->error('Sipariş senkronizasyonu hatası: ' . $e->getMessage());
            } else {
                $this->redirectWithError('/sync', 'Sipariş senkronizasyonu hatası: ' . $e->getMessage());
            }
        }
    }

    public function triggerStock(Request $request): void
    {
        try {
            // Stok sync pazaryeri görev sorgularıyla uzayabilir — timeout kaldır
            set_time_limit(0);
            $this->runSync('stock', fn() => $this->stockSync->syncAll('manual'), $request);
        } catch (\Throwable $e) {
            $this->logger->error('Stock sync error: ' . $e->getMessage(), 'Sync');
            if ($request->isAjax()) {
                $this->error('Stok senkronizasyonu hatası: ' . $e->getMessage());
            } else {
                $this->redirectWithError('/sync', 'Stok senkronizasyonu hatası: ' . $e->getMessage());
            }
        }
    }

    public function triggerPrice(Request $request): void
    {
        try {
            // Fiyat sync pazaryeri görev sorgularıyla uzayabilir — timeout kaldır
            set_time_limit(0);
            $this->runSync('price', fn() => $this->priceSync->syncAll('manual'), $request);
        } catch (\Throwable $e) {
            $this->logger->error('Price sync error: ' . $e->getMessage(), 'Sync');
            if ($request->isAjax()) {
                $this->error('Fiyat senkronizasyonu hatası: ' . $e->getMessage());
            } else {
                $this->redirectWithError('/sync', 'Fiyat senkronizasyonu hatası: ' . $e->getMessage());
            }
        }
    }

    public function triggerProducts(Request $request): void
    {
        try {
            // Product sync = import from marketplaces
            $this->runSync('products', function () {
                // Uzun sürebilir — PHP timeout'u kaldır
                set_time_limit(0);

                $marketplaces = $this->marketplaceModel->getActive();
                $results = [];
                $totalCreated = 0;
                $totalUpdated = 0;
                
                foreach ($marketplaces as $mp) {
                    $mpId = (int) $mp['id'];
                    $slug = $mp['slug'] ?? '';
                    $mpName = $mp['display_name'] ?? $mp['name'] ?? $slug;
                    
                    try {
                        $created = 0;
                        $updated = 0;
                        
                        // Maksimum 500 tur — sonsuz döngü koruması
                        // (sayfa değeri imleç olabileceği için TUR sayısı sayılır)
                        $page = 0;
                        $iteration = 0;
                        while ($iteration < 500) {
                            $iteration++;
                            $result = $this->container->get(\App\Services\Import\InitialImportService::class)
                                ->importProductPage($mpId, $slug, $page, 100);
                            
                            $created += $result['created'] ?? 0;
                            $updated += $result['updated'] ?? 0;

                            // Son sayfa ise dur. İmleç tabanlı servisler (Shopify
                            // since_id) sonraki sayfayı kendisi bildirir; sayaç
                            // artırmak imleci bozar.
                            if (array_key_exists('done', $result)) {
                                if (!empty($result['done'])) {
                                    break;
                                }
                            } elseif (($result['pageSize'] ?? 0) === 0
                                || ($result['page'] ?? 0) >= (($result['totalPages'] ?? 1) - 1)) {
                                break;
                            }

                            $page = isset($result['nextPage']) && $result['nextPage'] !== null
                                ? (int) $result['nextPage']
                                : $page + 1;
                        }
                        
                        $totalCreated += $created;
                        $totalUpdated += $updated;
                        
                        $results[$mpName] = [
                            'created' => $created,
                            'updated' => $updated,
                            'total' => $created + $updated,
                        ];
                    } catch (\Throwable $e) {
                        $this->logger->error("Product sync error ({$mpName}): " . $e->getMessage(), 'Sync');
                        $results[$mpName] = [
                            'error' => $e->getMessage(),
                        ];
                    }
                }
                
                return [
                    'marketplaces' => $results,
                    'totalCreated' => $totalCreated,
                    'totalUpdated' => $totalUpdated,
                ];
            }, $request);
        } catch (\Throwable $e) {
            $this->logger->error('Product sync error: ' . $e->getMessage(), 'Sync');
            if ($request->isAjax()) {
                $this->error('Ürün senkronizasyonu hatası: ' . $e->getMessage());
            } else {
                $this->redirectWithError('/sync', 'Ürün senkronizasyonu hatası: ' . $e->getMessage());
            }
        }
    }

    public function triggerReturns(Request $request): void
    {
        try {
            // İade sync uzun sürebilir — PHP timeout'ı kaldır
            set_time_limit(0);
            $this->runSync('returns', fn() => $this->returnSync->syncAll('manual'), $request);
        } catch (\Throwable $e) {
            $this->logger->error('Return sync error: ' . $e->getMessage(), 'Sync');
            if ($request->isAjax()) {
                $this->error('İade senkronizasyonu hatası: ' . $e->getMessage());
            } else {
                $this->redirectWithError('/sync', 'İade senkronizasyonu hatası: ' . $e->getMessage());
            }
        }
    }

    public function triggerQuestions(Request $request): void
    {
        try {
            // Question sync — QuestionController üzerinden
            $questionCtrl = $this->container->get(\App\Controllers\QuestionController::class);
            $this->runSync('questions', function () use ($questionCtrl) {
                // QuestionController::sync iç mantığı çağır
                $marketplaces = $this->marketplaceModel->getActive();
                $results = [];

                foreach ($marketplaces as $mp) {
                    $slug = $mp['slug'] ?? '';
                    $mpName = $mp['display_name'] ?? $mp['name'] ?? $slug;
                    
                    try {
                        $service = $this->resolveMarketplaceService($slug);
                        if ($service && method_exists($service, 'fetchQuestions')) {
                            $questions = $service->fetchQuestions(['days' => 30]);
                            $results[$mpName] = [
                                'fetched' => count($questions),
                            ];
                        } else {
                            $results[$mpName] = [
                                'skipped' => true,
                                'reason' => 'Desteklenmiyor',
                            ];
                        }
                    } catch (\Throwable $e) {
                        $results[$mpName] = [
                            'error' => $e->getMessage(),
                        ];
                    }
                }

                return $results;
            }, $request);
        } catch (\Throwable $e) {
            $this->logger->error('Question sync error: ' . $e->getMessage(), 'Sync');
            if ($request->isAjax()) {
                $this->error('Soru senkronizasyonu hatası: ' . $e->getMessage());
            } else {
                $this->redirectWithError('/sync', 'Soru senkronizasyonu hatası: ' . $e->getMessage());
            }
        }
    }

    // ─── Cron Endpoints ────────────────────────────────────

    public function cronOrders(Request $request): void
    {
        if (!$this->validateCronToken($request)) return;
        if (!$this->isSyncEnabled('orders')) {
            $this->json(['success' => true, 'skipped' => true, 'reason' => 'Sipariş senkronizasyonu devre dışı']);
            return;
        }
        $this->runCron('orders', fn() => $this->orderSync->syncAll('cron'));
    }

    public function cronStock(Request $request): void
    {
        if (!$this->validateCronToken($request)) return;
        if (!$this->isSyncEnabled('stock')) {
            $this->json(['success' => true, 'skipped' => true, 'reason' => 'Stok senkronizasyonu devre dışı']);
            return;
        }
        $this->runCron('stock', fn() => $this->stockSync->syncAll('cron'));
    }

    public function cronPrice(Request $request): void
    {
        if (!$this->validateCronToken($request)) return;
        if (!$this->isSyncEnabled('price')) {
            $this->json(['success' => true, 'skipped' => true, 'reason' => 'Fiyat senkronizasyonu devre dışı']);
            return;
        }
        $this->runCron('price', fn() => $this->priceSync->syncAll('cron'));
    }

    public function cronProducts(Request $request): void
    {
        if (!$this->validateCronToken($request)) return;
        if (!$this->isSyncEnabled('products')) {
            $this->json(['success' => true, 'skipped' => true, 'reason' => 'Ürün senkronizasyonu devre dışı']);
            return;
        }
        $this->runCron('products', function () {
            $marketplaces = $this->marketplaceModel->getActive();
            $results = [];
            foreach ($marketplaces as $mp) {
                $service = $this->resolveMarketplaceService($mp['slug'] ?? '');
                if ($service && method_exists($service, 'importProducts')) {
                    $results[$mp['name']] = $service->importProducts();
                }
            }
            return $results;
        });
    }

    public function cronReturns(Request $request): void
    {
        if (!$this->validateCronToken($request)) return;
        if (!$this->isSyncEnabled('returns')) {
            $this->json(['success' => true, 'skipped' => true, 'reason' => 'İade senkronizasyonu devre dışı']);
            return;
        }
        set_time_limit(0);
        $this->runCron('returns', fn() => $this->returnSync->syncAll('cron'));
    }

    // ─── Helpers ───────────────────────────────────────────

    private function runSync(string $type, callable $action, Request $request): void
    {
        try {
            $results = $action();
            $msg = ucfirst($type) . ' senkronizasyonu tamamlandı';
            if ($request->isAjax()) {
                $this->success($results, $msg);
                return;
            }
            $this->redirectWithSuccess('/sync', $msg);
        } catch (\Throwable $e) {
            $msg = 'Hata: ' . $e->getMessage();
            if ($request->isAjax()) {
                $this->error($msg);
                return;
            }
            $this->redirectWithError('/sync', $msg);
        }
    }

    private function runCron(string $type, callable $action): void
    {
        try {
            $results = $action();
            $this->json(['success' => true, 'type' => $type, 'data' => $results, 'time' => date('Y-m-d H:i:s')]);
        } catch (\Throwable $e) {
            http_response_code(500);
            $this->json(['success' => false, 'type' => $type, 'error' => $e->getMessage()]);
        }
    }

    private function validateCronToken(Request $request): bool
    {
        $token = $request->query('token', '');
        $validToken = $this->settings->get('cron_token', '');

        if (empty($validToken) || $token !== $validToken) {
            http_response_code(403);
            $this->json(['success' => false, 'error' => 'Invalid cron token']);
            return false;
        }
        return true;
    }

    /**
     * Sync tipi aktif mi kontrol et
     */
    private function isSyncEnabled(string $type): bool
    {
        return (bool) $this->settings->get("sync_{$type}_enabled", true);
    }

    private function resolveMarketplaceService(string $slug): ?object
    {
        $map = [
            'trendyol'     => \App\Services\Marketplace\TrendyolService::class,
            'n11'          => \App\Services\Marketplace\N11Service::class,
            'hepsiburada'  => \App\Services\Marketplace\HepsiburadaService::class,
            'pazarama'     => \App\Services\Marketplace\PazaramaService::class,
            'ciceksepeti'  => \App\Services\Marketplace\CiceksepetiService::class,
        ];
        $class = $map[$slug] ?? null;
        if ($class === null) return null;
        return $this->container->get($class);
    }
}
