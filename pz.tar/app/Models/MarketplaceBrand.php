<?php
declare(strict_types=1);

namespace App\Models;

/**
 * Pazaryeri Marka Cache — Her pazaryerinden çekilen markaları saklar
 */
final class MarketplaceBrand extends BaseModel
{
    protected string $table = 'marketplace_brands';
    protected bool $tenantScoped = false; // GLOBAL referans (D2): platform marka katalogu

    /**
     * Pazaryeri + marka ID ile bul
     */
    public function findByMpBrandId(int $marketplaceId, string $mpBrandId): array|false
    {
        return $this->rawQueryOne(
            "SELECT * FROM marketplace_brands WHERE marketplace_id = :mid AND mp_brand_id = :bid LIMIT 1",
            ['mid' => $marketplaceId, 'bid' => $mpBrandId]
        );
    }

    /**
     * Upsert
     */
    public function upsert(int $marketplaceId, string $mpBrandId, string $name): int
    {
        $existing = $this->findByMpBrandId($marketplaceId, $mpBrandId);

        if ($existing !== false) {
            $this->update((int)$existing['id'], [
                'name'      => $name,
                'synced_at' => date('Y-m-d H:i:s'),
            ]);
            return (int)$existing['id'];
        }

        return $this->create([
            'marketplace_id' => $marketplaceId,
            'mp_brand_id'    => $mpBrandId,
            'name'           => $name,
        ]);
    }

    /**
     * Toplu upsert — büyük veri setleri için optimize edilmiş
     * Tek sorguda yüzlerce kayıt işler (INSERT ... ON DUPLICATE KEY UPDATE)
     *
     * @param array<int, array{mp_brand_id: string, name: string}> $brands
     * @return int İşlenen kayıt sayısı
     */
    public function bulkUpsert(int $marketplaceId, array $brands, int $chunkSize = 500): int
    {
        if ($brands === []) return 0;

        $processed = 0;
        $now = date('Y-m-d H:i:s');

        // Aynı mp_brand_id'nin chunk içinde tekrar etmemesi için tekilleştir
        $unique = [];
        foreach ($brands as $b) {
            $bid = (string)($b['mp_brand_id'] ?? '');
            $name = trim((string)($b['name'] ?? ''));
            if ($bid === '' || $name === '') continue;
            $unique[$bid] = $name;
        }

        $items = [];
        foreach ($unique as $bid => $name) {
            $items[] = ['mp_brand_id' => $bid, 'name' => $name];
        }

        foreach (array_chunk($items, $chunkSize) as $chunk) {
            $placeholders = [];
            $params = [];
            $i = 0;
            foreach ($chunk as $row) {
                $placeholders[] = "(:mid{$i}, :bid{$i}, :name{$i}, :ts{$i})";
                $params["mid{$i}"]  = $marketplaceId;
                $params["bid{$i}"]  = $row['mp_brand_id'];
                $params["name{$i}"] = $row['name'];
                $params["ts{$i}"]   = $now;
                $i++;
            }

            $sql = "INSERT INTO marketplace_brands (marketplace_id, mp_brand_id, name, synced_at) VALUES "
                . implode(',', $placeholders)
                . " ON DUPLICATE KEY UPDATE name = VALUES(name), synced_at = VALUES(synced_at)";

            $this->db->query($sql, $params);
            $processed += count($chunk);
        }

        return $processed;
    }

    /**
     * İsimle arama
     */
    public function searchByName(string $name, ?int $marketplaceId = null): array
    {
        $sql = "SELECT mb.*, m.slug as marketplace_slug, m.display_name as marketplace_name
                FROM marketplace_brands mb
                JOIN marketplaces m ON mb.marketplace_id = m.id
                WHERE mb.name LIKE :q";
        $params = ['q' => '%' . $name . '%'];

        if ($marketplaceId !== null) {
            $sql .= " AND mb.marketplace_id = :mid";
            $params['mid'] = $marketplaceId;
        }

        $sql .= " ORDER BY mb.name ASC LIMIT 300";

        return $this->rawQuery($sql, $params);
    }

    /**
     * Tam isim eşleşmesi
     */
    public function findExactMatch(string $name, int $marketplaceId): array|false
    {
        return $this->rawQueryOne(
            "SELECT * FROM marketplace_brands
             WHERE LOWER(name) = LOWER(:name) AND marketplace_id = :mid
             LIMIT 1",
            ['name' => $name, 'mid' => $marketplaceId]
        );
    }

    /**
     * Belirli pazaryerideki marka sayısı
     */
    public function countByMarketplace(int $marketplaceId): int
    {
        $row = $this->rawQueryOne(
            "SELECT COUNT(*) as cnt FROM marketplace_brands WHERE marketplace_id = :mid",
            ['mid' => $marketplaceId]
        );
        return (int)($row['cnt'] ?? 0);
    }

    /**
     * Pazaryerindeki tüm cache markalarını sil
     */
    public function deleteByMarketplace(int $marketplaceId): int
    {
        $stmt = $this->db->query(
            "DELETE FROM marketplace_brands WHERE marketplace_id = :mid",
            ['mid' => $marketplaceId]
        );
        return $stmt->rowCount();
    }
}
