<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Container;
use App\Core\Request;
use App\Models\Category;
use App\Models\Marketplace;
use App\Models\CategoryMarketplaceMapping;
use App\Models\MarketplaceCategory;
use App\Helpers\StringHelper;
use App\Services\Marketplace\TrendyolService;
use App\Services\Marketplace\N11Service;
use App\Services\Marketplace\PazaramaService;

final class CategoryController extends BaseController
{
    private readonly Category $categoryModel;
    private readonly Marketplace $marketplaceModel;
    private readonly CategoryMarketplaceMapping $mappingModel;
    private readonly MarketplaceCategory $mpCatModel;

    public function __construct(Container $container)
    {
        parent::__construct($container);
        $this->categoryModel    = $container->get(Category::class);
        $this->marketplaceModel = $container->get(Marketplace::class);
        $this->mappingModel     = $container->get(CategoryMarketplaceMapping::class);
        $this->mpCatModel       = $container->get(MarketplaceCategory::class);
    }

    public function index(Request $request): void
    {
        $marketplaces = $this->marketplaceModel->getAll();
        $flatTree     = $this->categoryModel->getFlatTree();

        $totalCategories = $this->categoryModel->count();
        $mpStats = [];
        foreach ($marketplaces as $mp) {
            $mpId = (int)$mp['id'];
            $mpStats[$mp['slug']] = $this->mpCatModel->countByMarketplace($mpId);
        }
        $totalMapped = $this->mappingModel->countMappedCategories();

        $this->view('categories.index', [
            'pageTitle'       => 'Kategoriler',
            'marketplaces'    => $marketplaces,
            'flatTree'        => $flatTree,
            'totalCategories' => $totalCategories,
            'totalMapped'     => $totalMapped,
            'totalUnmapped'   => $totalCategories - $totalMapped,
            'mpStats'         => $mpStats,
        ]);
    }

    public function ajaxList(Request $request): void
    {
        $parentId = $request->query('parent_id', '');
        $search   = trim((string)$request->query('search', ''));

        if ($search !== '') {
            $categories = $this->categoryModel->searchCategories($search);
            $this->json([
                'success' => true,
                'data'    => $this->enrichCategories($categories),
                'mode'    => 'search',
            ]);
        }

        if ($parentId === '' || $parentId === null) {
            $categories = $this->categoryModel->getRootCategories();
        } else {
            $categories = $this->categoryModel->getChildrenWithCounts((int)$parentId);
        }

        $this->json([
            'success' => true,
            'data'    => $this->enrichCategories($categories),
            'mode'    => 'tree',
        ]);
    }

    private function enrichCategories(array $categories): array
    {
        foreach ($categories as &$cat) {
            $cat['mappings'] = $this->mappingModel->getMappingsForCategory((int)$cat['id']);
            $cat['mapping_count'] = count($cat['mappings']);
        }
        return $categories;
    }

    public function syncFromMarketplace(Request $request): void
    {
        $slug = $request->post('marketplace', '');
        if ($slug === '') { $this->error('Pazaryeri belirtilmedi'); }

        $mp = $this->marketplaceModel->findBySlug($slug);
        if ($mp === false) { $this->error("'{$slug}' pazaryeri bulunamadı"); }
        $mpId = (int)$mp['id'];

        try {
            if ($slug === 'trendyol') {
                $trendyol = $this->container->get(TrendyolService::class);
                $rawCategories = $trendyol->fetchCategories();
                $flat = [];
                $trendyol->flattenCategoryTree($rawCategories, $flat);

                $saved = 0;
                $skipped = 0;

                foreach ($flat as $tCat) {
                    $name = trim($tCat['name'] ?? '');
                    $mpCatId = (string)($tCat['id'] ?? '');
                    if ($name === '' || $mpCatId === '') { $skipped++; continue; }

                    $path = $this->buildCategoryPath($flat, $tCat);
                    $parentMpId = $tCat['parent_id'] !== null ? (string)$tCat['parent_id'] : null;

                    $hasChildren = false;
                    foreach ($flat as $check) {
                        if ($check['parent_id'] !== null && (int)$check['parent_id'] === (int)$tCat['id']) {
                            $hasChildren = true;
                            break;
                        }
                    }

                    $this->mpCatModel->upsert($mpId, $mpCatId, $name, $parentMpId, $path, !$hasChildren);
                    $saved++;
                }

                $this->success([
                    'message' => "Trendyol: {$saved} kategori cache'e kaydedildi, {$skipped} atlandı (toplam " . count($flat) . ")",
                    'saved'   => $saved,
                    'skipped' => $skipped,
                    'total'   => count($flat),
                ]);
            } elseif ($slug === 'n11') {
                $n11 = $this->container->get(N11Service::class);
                $flat = $n11->fetchCategories();

                $saved = 0;
                $skipped = 0;

                foreach ($flat as $nCat) {
                    $name = trim($nCat['name'] ?? '');
                    $mpCatId = (string)($nCat['id'] ?? '');
                    if ($name === '' || $mpCatId === '') { $skipped++; continue; }

                    $path = $this->buildCategoryPath($flat, $nCat);
                    $parentMpId = ($nCat['parent_id'] ?? null) !== null && (int)$nCat['parent_id'] !== 0
                        ? (string)$nCat['parent_id']
                        : null;

                    $hasChildren = !empty($nCat['has_children']) || $this->hasChildrenInFlat($flat, $nCat);

                    $this->mpCatModel->upsert($mpId, $mpCatId, $name, $parentMpId, $path, !$hasChildren);
                    $saved++;
                }

                $this->success([
                    'message' => "N11: {$saved} kategori cache'e kaydedildi, {$skipped} atlandı (toplam " . count($flat) . ")",
                    'saved'   => $saved,
                    'skipped' => $skipped,
                    'total'   => count($flat),
                ]);
            } elseif ($slug === 'pazarama') {
                $pazarama = $this->container->get(PazaramaService::class);
                $rawCategories = $pazarama->fetchCategories();

                $flat = [];
                $this->flattenPazaramaCategoryTree($rawCategories, $flat);

                $saved = 0;
                $skipped = 0;

                foreach ($flat as $pCat) {
                    $name = trim($pCat['name'] ?? '');
                    $mpCatId = (string)($pCat['id'] ?? '');
                    if ($name === '' || $mpCatId === '') { $skipped++; continue; }

                    $path = $this->buildCategoryPath($flat, $pCat);
                    $parentMpId = ($pCat['parent_id'] ?? null) !== null && (int)$pCat['parent_id'] !== 0
                        ? (string)$pCat['parent_id']
                        : null;

                    $hasChildren = $this->hasChildrenInFlat($flat, $pCat);

                    $this->mpCatModel->upsert($mpId, $mpCatId, $name, $parentMpId, $path, !$hasChildren);
                    $saved++;
                }

                $this->success([
                    'message' => "Pazarama: {$saved} kategori cache'e kaydedildi, {$skipped} atlandı (toplam " . count($flat) . ")",
                    'saved'   => $saved,
                    'skipped' => $skipped,
                    'total'   => count($flat),
                ]);
            } elseif ($slug === 'oziygo') {
                $oziygo = $this->container->get(\App\Services\Marketplace\OziygoService::class);
                $flat = $oziygo->fetchCategories();

                $saved = 0;
                $skipped = 0;
                foreach ($flat as $cat) {
                    $name = trim($cat['name'] ?? '');
                    $mpCatId = (string)($cat['id'] ?? '');
                    if ($name === '' || $mpCatId === '') { $skipped++; continue; }

                    $parentMpId = !empty($cat['parentId']) ? (string)$cat['parentId'] : null;
                    $path = !empty($cat['paths']) && is_array($cat['paths']) ? implode(' > ', $cat['paths']) : $name;
                    $this->mpCatModel->upsert($mpId, $mpCatId, $name, $parentMpId, $path, true);
                    $saved++;
                }

                $this->success([
                    'message' => "OziyGO: {$saved} kategori cache'e kaydedildi, {$skipped} atlandi",
                    'saved'   => $saved,
                    'skipped' => $skipped,
                    'total'   => count($flat),
                ]);
            } elseif ($slug === 'ciceksepeti') {
                $ciceksepeti = $this->container->get(\App\Services\Marketplace\CiceksepetiService::class);
                $flat = $ciceksepeti->fetchCategories();

                // /Category endpoint erişilemezse (404), flat boş gelir.
                // Mevcut ürünlerden kategorileri çıkar.
                if (empty($flat)) {
                    // DB'deki ürünlerden kategorileri extract et
                    $db = $this->container->get(\App\Core\Database::class)->getConnection();
                    $stmt = $db->prepare("
                        SELECT marketplace_category_id, marketplace_category_name, COUNT(*) as cnt
                        FROM marketplace_products
                        WHERE marketplace_id = :mpId
                          AND store_id = :storeId
                          AND marketplace_category_id IS NOT NULL
                          AND marketplace_category_id != ''
                        GROUP BY marketplace_category_id, marketplace_category_name
                    ");
                    // store_id şart: filtresiz sorgu diğer bayilerin kategorilerini getiriyordu
                    $stmt->execute([':mpId' => $mpId, ':storeId' => $this->container->get(\App\Core\TenantContext::class)->currentStoreId()]);
                    $productCats = $stmt->fetchAll(\PDO::FETCH_ASSOC);

                    $saved = 0;
                    foreach ($productCats as $pc) {
                        $catId   = (string) ($pc['marketplace_category_id'] ?? '');
                        $catName = trim((string) ($pc['marketplace_category_name'] ?? ''));
                        if ($catId === '' || $catName === '') continue;

                        $this->mpCatModel->upsert($mpId, $catId, $catName, null, $catName, true);
                        $saved++;
                    }

                    if ($saved > 0) {
                        $this->success([
                            'message' => "ÇiçekSepeti /Category API erişilemedi. Mevcut ürünlerden {$saved} kategori çıkarıldı.",
                            'saved'   => $saved,
                            'skipped' => 0,
                            'total'   => $saved,
                        ]);
                    } else {
                        $this->success([
                            'message' => "ÇiçekSepeti /Category API erişilemedi. Önce ürünleri import edin — kategoriler otomatik toplanacak.",
                            'saved'   => 0,
                            'skipped' => 0,
                            'total'   => 0,
                        ]);
                    }
                    return;
                }

                $saved = 0;
                $skipped = 0;

                foreach ($flat as $csCat) {
                    $name = trim($csCat['name'] ?? '');
                    $mpCatId = (string)($csCat['id'] ?? '');
                    if ($name === '' || $mpCatId === '') { $skipped++; continue; }

                    $parentMpId = ($csCat['parent_id'] ?? null) !== null && (string)$csCat['parent_id'] !== '0' && (string)$csCat['parent_id'] !== ''
                        ? (string)$csCat['parent_id']
                        : null;

                    $path = $this->buildCategoryPath($flat, $csCat);
                    $hasChildren = $this->hasChildrenInFlat($flat, $csCat);

                    $this->mpCatModel->upsert($mpId, $mpCatId, $name, $parentMpId, $path, !$hasChildren);
                    $saved++;
                }

                $this->success([
                    'message' => "ÇiçekSepeti: {$saved} kategori cache'e kaydedildi, {$skipped} atlandı (toplam " . count($flat) . ")",
                    'saved'   => $saved,
                    'skipped' => $skipped,
                    'total'   => count($flat),
                ]);
            } else {
                // Genel dal — Amazon, Hepsiburada, İdefix, PttAVM ve sonradan eklenecek
                // pazaryerleri. Öncesinde bu dal hata veriyordu; katalog boş kaldığı için
                // bu pazaryerlerinde kategori eşleştirmesi HİÇ yapılamıyor, dolayısıyla
                // ürün gönderimi de engelleniyordu.
                [$saved, $skipped, $total] = $this->syncCategoriesGeneric($slug, $mpId);

                $this->success([
                    'message' => sprintf(
                        '%s: %d kategori kaydedildi, %d atlandı (toplam %d)',
                        $mp['display_name'] ?? $slug,
                        $saved,
                        $skipped,
                        $total
                    ),
                    'saved'   => $saved,
                    'skipped' => $skipped,
                    'total'   => $total,
                ]);
            }
        } catch (\Throwable $e) {
            $this->logger->error("Kategori sync hatası: {$e->getMessage()}", 'CategorySync');
            $this->error('Hata: ' . $e->getMessage());
        }
    }

    public function autoMatch(Request $request): void
    {
        $slug = $request->post('marketplace', '');

        try {
            if ($slug !== '') {
                $mp = $this->marketplaceModel->findBySlug($slug);
                if ($mp === false) { $this->error("'{$slug}' pazaryeri bulunamadı"); }
                $marketplaces = [$mp];
            } else {
                $marketplaces = $this->marketplaceModel->getActive();
            }

            $allCategories = $this->categoryModel->all(['is_active' => 1], 'name ASC');
            $mpResults = [];

            foreach ($marketplaces as $mp) {
                $mpId = (int)$mp['id'];
                $mpSlug = $mp['slug'] ?? '';
                $mpResult = [
                    'slug'            => $mpSlug,
                    'name'            => $mp['display_name'],
                    'mp_id'           => $mpId,
                    'matched'         => 0,
                    'already'         => 0,
                    'not_found'       => 0,
                    'not_found_names' => [],
                    'not_found_items' => [],
                ];

                $cacheCount = $this->mpCatModel->countByMarketplace($mpId);
                if ($cacheCount === 0) {
                    foreach ($allCategories as $cat) {
                        $existing = $this->mappingModel->findMapping((int)$cat['id'], $mpId);
                        if ($existing !== false) { $mpResult['already']++; continue; }
                        $mpResult['not_found']++;
                        if (count($mpResult['not_found_names']) < 10) {
                            $mpResult['not_found_names'][] = $cat['name'];
                        }
                        $mpResult['not_found_items'][] = ['id' => (int)$cat['id'], 'name' => $cat['name']];
                    }
                } else {
                    foreach ($allCategories as $cat) {
                        $existing = $this->mappingModel->findMapping((int)$cat['id'], $mpId);
                        if ($existing !== false) { $mpResult['already']++; continue; }

                        $match = $this->mpCatModel->findExactMatch($cat['name'], $mpId);
                        if ($match !== false) {
                            $this->mappingModel->saveMapping(
                                (int)$cat['id'], $mpId,
                                $match['mp_category_id'], $match['name'], $match['full_path']
                            );
                            $mpResult['matched']++;
                        } else {
                            $mpResult['not_found']++;
                            if (count($mpResult['not_found_names']) < 10) {
                                $mpResult['not_found_names'][] = $cat['name'];
                            }
                            $mpResult['not_found_items'][] = ['id' => (int)$cat['id'], 'name' => $cat['name']];
                        }
                    }
                }

                $mpResults[] = $mpResult;
            }

            $totalMatched = array_sum(array_column($mpResults, 'matched'));
            $totalNotFound = array_sum(array_column($mpResults, 'not_found'));

            $this->success([
                'message'    => "{$totalMatched} eşleştirildi, {$totalNotFound} bulunamadı",
                'matched'    => $totalMatched,
                'not_found'  => $totalNotFound,
                'mp_results' => $mpResults,
            ]);
        } catch (\Throwable $e) {
            $this->logger->error("Kategori otomatik eşleştirme hatası: {$e->getMessage()}", 'CategoryAutoMatch');
            $this->error('Hata: ' . $e->getMessage());
        }
    }

    public function deleteAllCategories(Request $request): void
    {
        try {
            $cats = $this->categoryModel->all([], 'name ASC');
            $deleted = 0;
            $skipped = 0;

            foreach ($cats as $cat) {
                $children = $this->categoryModel->getChildren((int)$cat['id']);
                if (!empty($children)) { $skipped++; continue; }
                $productCount = $this->categoryModel->getProductCount((int)$cat['id']);
                if ($productCount > 0) { $skipped++; continue; }
                $this->categoryModel->delete((int)$cat['id']);
                $deleted++;
            }

            $this->success([
                'message' => "{$deleted} kategori silindi" . ($skipped > 0 ? " ({$skipped} atlandı)" : ''),
                'deleted' => $deleted,
                'skipped' => $skipped,
            ]);
        } catch (\Throwable $e) {
            $this->error('Hata: ' . $e->getMessage());
        }
    }

    public function clearCache(Request $request): void
    {
        $slug = $request->post('marketplace', '');
        if ($slug === '') { $this->error('Pazaryeri belirtilmedi'); }

        try {
            $mp = $this->marketplaceModel->findBySlug($slug);
            if ($mp === false) { $this->error("'{$slug}' pazaryeri bulunamadı"); }

            $mpId = (int)$mp['id'];
            $this->mpCatModel->deleteByMarketplace($mpId);
            $this->mappingModel->deleteByMarketplace($mpId);

            $this->success(['message' => "{$mp['display_name']} kategori cache'i temizlendi"]);
        } catch (\Throwable $e) {
            $this->error('Hata: ' . $e->getMessage());
        }
    }

    public function searchCache(Request $request): void
    {
        $q = trim((string)$request->query('q', ''));
        $mpId = (int)$request->query('marketplace_id', 0);

        if ($q === '' || strlen($q) < 2) {
            $this->json(['success' => true, 'data' => []]);
        }

        $results = $this->mpCatModel->searchByName($q, $mpId > 0 ? $mpId : null);

        // En yakın aday üstte olsun — eşleştirme skorlayıcısıyla sırala
        $finder = $this->container->get(\App\Services\Mapping\MappingCandidateFinder::class);

        foreach ($results as $i => $row) {
            $results[$i]['match_score'] = $finder->confidenceFor(
                $q,
                '',
                (string) ($row['name'] ?? '')
            );
        }

        usort($results, static fn(array $a, array $b): int => $b['match_score'] <=> $a['match_score']);

        $this->json(['success' => true, 'data' => array_slice($results, 0, 50)]);
    }

    public function manualMap(Request $request): void
    {
        $catId = (int)$request->post('category_id', 0);
        $mpId = (int)$request->post('marketplace_id', 0);
        $mpCatId = $request->post('mp_category_id', '');
        $mpCatName = $request->post('mp_category_name', '');

        if ($catId === 0 || $mpId === 0 || $mpCatId === '') {
            $this->error('Eksik parametre');
        }

        try {
            $this->mappingModel->saveMapping($catId, $mpId, $mpCatId, $mpCatName, '');
            $this->success(['message' => 'Eşleştirme kaydedildi']);
        } catch (\Throwable $e) {
            $this->error('Hata: ' . $e->getMessage());
        }
    }

    public function store(Request $request): void
    {
        $name      = trim($request->post('name', ''));
        $parentId  = $request->post('parent_id', '');
        $sortOrder = (int)$request->post('sort_order', 0);
        $isActive  = (int)$request->post('is_active', 1);

        if ($name === '') { $this->error('Kategori adı zorunludur'); }

        $parentIdVal = ($parentId !== '' && $parentId !== '0') ? (int)$parentId : null;

        $id = $this->categoryModel->create([
            'name'       => $name,
            'slug'       => StringHelper::slugify($name),
            'parent_id'  => $parentIdVal,
            'sort_order' => $sortOrder,
            'is_active'  => $isActive,
        ]);

        $this->categoryModel->updateFullPath($id);
        $matchResult = $this->autoMatchCategoryDetailed($id, $name);

        $matchMsg = '';
        if ($matchResult['matched'] > 0) {
            $matchMsg = " ({$matchResult['matched']} pazaryeriyle eşleştirildi)";
        }

        $this->success([
            'id'                     => $id,
            'category_name'          => $name,
            'message'                => "'{$name}' kategorisi oluşturuldu{$matchMsg}",
            'matched_marketplaces'   => $matchResult['matched_list'],
            'unmatched_marketplaces' => $matchResult['unmatched_list'],
        ]);
    }

    /**
     * Tek bir kategoriyi tüm aktif pazaryerlerinde otomatik eşleştir (detaylı sonuç)
     */
    private function autoMatchCategoryDetailed(int $categoryId, string $name): array
    {
        $matched = 0;
        $matchedList = [];
        $unmatchedList = [];
        $marketplaces = $this->marketplaceModel->getActive();

        foreach ($marketplaces as $mp) {
            $mpId = (int)$mp['id'];
            $slug = $mp['slug'] ?? '';

            $existing = $this->mappingModel->findMapping($categoryId, $mpId);
            if ($existing !== false) {
                $matchedList[] = ['id' => $mpId, 'slug' => $slug, 'name' => $mp['display_name']];
                $matched++;
                continue;
            }

            $cacheCount = $this->mpCatModel->countByMarketplace($mpId);
            if ($cacheCount > 0) {
                $match = $this->mpCatModel->findExactMatch($name, $mpId);
                if ($match !== false) {
                    $this->mappingModel->saveMapping(
                        $categoryId, $mpId,
                        $match['mp_category_id'], $match['name'], $match['full_path']
                    );
                    $matchedList[] = ['id' => $mpId, 'slug' => $slug, 'name' => $mp['display_name']];
                    $matched++;
                    continue;
                }
            }

            // Cache'de bulunamadı veya cache boş
            $unmatchedList[] = [
                'id'     => $mpId,
                'slug'   => $slug,
                'name'   => $mp['display_name'],
                'reason' => $cacheCount > 0 ? 'not_found' : 'no_cache',
            ];
        }

        return [
            'matched'        => $matched,
            'matched_list'   => $matchedList,
            'unmatched_list' => $unmatchedList,
        ];
    }

    private function hasChildrenInFlat(array $flat, array $cat): bool
    {
        $catId = (int)($cat['id'] ?? 0);
        foreach ($flat as $check) {
            if (($check['parent_id'] ?? null) !== null && (int)$check['parent_id'] === $catId) {
                return true;
            }
        }
        return false;
    }

    /**
     * Pazarama kategori ağacını düzleştir (recursive)
     * Pazarama formatı: [{id, name, subCategories: [...]}]
     */
    private function flattenPazaramaCategoryTree(array $categories, array &$flat, ?int $parentId = null): void
    {
        foreach ($categories as $cat) {
            $flat[] = [
                'id'        => (int)($cat['id'] ?? $cat['categoryId'] ?? 0),
                'name'      => $cat['name'] ?? $cat['categoryName'] ?? '',
                'parent_id' => $parentId,
            ];

            $children = $cat['subCategories'] ?? $cat['children'] ?? [];
            if (!empty($children)) {
                $this->flattenPazaramaCategoryTree($children, $flat, (int)($cat['id'] ?? $cat['categoryId'] ?? 0));
            }
        }
    }

    /**
     * Pazaryerine özel dalı olmayan servisler için genel kategori senkronu.
     *
     * Servislerin fetchCategories() çıktısı düz dizidir ve anahtarlar biraz farklıdır
     * (parent_id / parentId, leaf, paths). Burada tek biçime indirgenir.
     *
     * @return array{0: int, 1: int, 2: int} [kaydedilen, atlanan, toplam]
     */
    private function syncCategoriesGeneric(string $slug, int $mpId): array
    {
        $servisler = [
            'amazon'      => \App\Services\Marketplace\AmazonService::class,
            'hepsiburada' => \App\Services\Marketplace\HepsiburadaService::class,
            'idefix'      => \App\Services\Marketplace\IdefixService::class,
            'pttavm'      => \App\Services\Marketplace\PttavmService::class,
        ];

        $sinif = $servisler[$slug] ?? null;
        if ($sinif === null) {
            $this->error("'{$slug}' pazaryeri için kategori çekme desteklenmiyor");
        }

        /** @var object $servis */
        $servis = $this->container->get($sinif);
        if (method_exists($servis, 'loadCredentials')) {
            $servis->loadCredentials();
        }

        $flat = $servis->fetchCategories();
        if (!is_array($flat) || $flat === []) {
            $this->error('Pazaryerinden kategori listesi alınamadı (boş yanıt). API bilgilerini kontrol edin.');
        }

        // Üst kategorisi olanları indeksle → yaprak tespiti O(n)
        $cocukluOlanlar = [];
        foreach ($flat as $cat) {
            $ust = $this->normalizeParentId($cat);
            if ($ust !== null) {
                $cocukluOlanlar[$ust] = true;
            }
        }

        // Ad haritası → yol kurma (id'ler METİN olarak karşılaştırılır; Amazon'da
        // kategori kimliği "SHOES" gibi metindir, int'e çevirmek hepsini 0 yapar)
        $adHaritasi = [];
        foreach ($flat as $cat) {
            $id = trim((string) ($cat['id'] ?? ''));
            if ($id !== '') {
                $adHaritasi[$id] = [
                    'name'   => trim((string) ($cat['name'] ?? '')),
                    'parent' => $this->normalizeParentId($cat),
                ];
            }
        }

        $saved = 0;
        $skipped = 0;

        foreach ($flat as $cat) {
            $mpCatId = trim((string) ($cat['id'] ?? ''));
            $name    = trim((string) ($cat['name'] ?? ''));

            if ($mpCatId === '' || $name === '') {
                $skipped++;
                continue;
            }

            $parentMpId = $this->normalizeParentId($cat);

            // Yaprak mı: servis açıkça bildirdiyse ona uy, yoksa "çocuğu var mı" ile hesapla
            $isLeaf = array_key_exists('leaf', $cat)
                ? (bool) $cat['leaf']
                : !isset($cocukluOlanlar[$mpCatId]);

            $this->mpCatModel->upsert($mpId, $mpCatId, $name, $parentMpId, $this->buildPathFromMap($adHaritasi, $mpCatId, $cat), $isLeaf);
            $saved++;
        }

        return [$saved, $skipped, count($flat)];
    }

    /**
     * parent_id / parentId anahtarlarını tek biçime indirger; kök için null döner.
     *
     * @param array<string, mixed> $cat
     */
    private function normalizeParentId(array $cat): ?string
    {
        $ham = $cat['parent_id'] ?? $cat['parentId'] ?? null;
        if ($ham === null) {
            return null;
        }

        $ust = trim((string) $ham);

        return ($ust === '' || $ust === '0') ? null : $ust;
    }

    /**
     * Kategori yolunu üst zincirinden kurar. Servis "paths" verdiyse onu kullanır.
     *
     * @param array<string, array{name: string, parent: ?string}> $harita
     * @param array<string, mixed> $cat
     */
    private function buildPathFromMap(array $harita, string $id, array $cat): string
    {
        if (!empty($cat['paths']) && is_array($cat['paths'])) {
            return implode(' > ', array_map('strval', $cat['paths']));
        }

        $parcalar = [];
        $mevcut = $id;
        $derinlik = 0;

        while ($mevcut !== null && isset($harita[$mevcut]) && $derinlik++ < 10) {
            array_unshift($parcalar, $harita[$mevcut]['name']);
            $mevcut = $harita[$mevcut]['parent'];
        }

        return implode(' > ', $parcalar);
    }

    private function buildCategoryPath(array $flat, array $cat): string
    {
        $parts = [$cat['name']];
        $parentId = $cat['parent_id'] ?? null;
        $maxDepth = 10;

        while ($parentId !== null && $maxDepth-- > 0) {
            foreach ($flat as $p) {
                if ((int)($p['id'] ?? 0) === (int)$parentId) {
                    array_unshift($parts, $p['name']);
                    $parentId = $p['parent_id'] ?? null;
                    break;
                }
            }
        }

        return implode(' > ', $parts);
    }

    public function update(Request $request, string $id): void
    {
        $cat = $this->categoryModel->find((int)$id);
        if ($cat === false) { $this->error('Kategori bulunamadı', 404); }

        $name = trim($request->post('name', ''));
        if ($name === '') { $this->error('Kategori adı zorunludur'); }

        $parentId = $request->post('parent_id', '');
        $parentIdVal = ($parentId !== '' && $parentId !== '0') ? (int)$parentId : null;

        if ($parentIdVal === (int)$id) { $this->error('Kategori kendi altına taşınamaz'); }

        $this->categoryModel->update((int)$id, [
            'name'       => $name,
            'slug'       => StringHelper::slugify($name),
            'parent_id'  => $parentIdVal,
            'sort_order' => (int)$request->post('sort_order', $cat['sort_order'] ?? 0),
            'is_active'  => (int)$request->post('is_active', 1),
        ]);

        $this->categoryModel->updateFullPath((int)$id);
        $this->success(['message' => "'{$name}' kategorisi güncellendi"]);
    }

    public function delete(Request $request, string $id): void
    {
        $cat = $this->categoryModel->find((int)$id);
        if ($cat === false) { $this->error('Kategori bulunamadı', 404); }

        $children = $this->categoryModel->getChildren((int)$id);
        if (!empty($children)) {
            $this->error('Bu kategorinin alt kategorileri var. Önce onları silin veya taşıyın.');
        }

        $productCount = $this->categoryModel->getProductCount((int)$id);
        if ($productCount > 0) {
            $this->error("Bu kategoride {$productCount} ürün var. Önce ürünleri başka kategoriye taşıyın.");
        }

        $this->categoryModel->delete((int)$id);
        $this->success(['message' => "'{$cat['name']}' kategorisi silindi"]);
    }

    /**
     * Pazaryeri sekmesi: Belirli pazaryerindeki cache'lenmiş kategorileri listele (paginated, searchable)
     */
    public function mpCategoryList(Request $request): void
    {
        $slug = $request->query('marketplace', '');
        $search = trim((string)$request->query('search', ''));
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 50;
        $leafOnly = $request->query('leaf_only', '0') === '1';

        if ($slug === '') { $this->error('Pazaryeri belirtilmedi'); }

        $mp = $this->marketplaceModel->findBySlug($slug);
        if ($mp === false) { $this->error("'{$slug}' pazaryeri bulunamadı"); }
        $mpId = (int)$mp['id'];

        $result = $this->mpCatModel->paginatedWithMappingStatus($mpId, $search, $leafOnly, $page, $perPage);

        $this->json([
            'success' => true,
            'data' => $result['items'],
            'pagination' => [
                'page' => $page,
                'per_page' => $perPage,
                'total' => $result['total'],
                'total_pages' => (int)ceil($result['total'] / $perPage),
            ],
        ]);
    }

    /**
     * Pazaryeri sekmesi: Ağaç yapısında listele (parent_mp_id bazlı)
     */
    public function mpCategoryTree(Request $request): void
    {
        $slug = $request->query('marketplace', '');
        $parentMpId = $request->query('parent_mp_id', null);
        $search = trim((string)$request->query('search', ''));
        $page = max(1, (int)$request->query('page', 1));

        if ($slug === '') { $this->error('Pazaryeri belirtilmedi'); }

        $mp = $this->marketplaceModel->findBySlug($slug);
        if ($mp === false) { $this->error("'{$slug}' pazaryeri bulunamadı"); }
        $mpId = (int)$mp['id'];

        if ($parentMpId === '' || $parentMpId === 'null') { $parentMpId = null; }

        $result = $this->mpCatModel->treeList($mpId, $parentMpId, $search, $page);

        $this->json([
            'success'    => true,
            'data'       => $result['items'],
            'pagination' => [
                'page'        => $result['page'],
                'per_page'    => $result['per_page'],
                'total'       => $result['total'],
                'total_pages' => $result['total_pages'],
            ],
        ]);
    }

    /**
     * Pazaryeri kategorisini sisteme ekle + otomatik eşleştirme
     */
    public function addToSystem(Request $request): void
    {
        $mpCatId   = $request->post('mp_category_id', '');
        $mpId      = (int)$request->post('marketplace_id', 0);
        $catName   = trim($request->post('name', ''));

        if ($mpCatId === '' || $mpId === 0) {
            $this->error('Eksik parametreler');
        }

        // MP kategori bilgisini al
        $mpCat = $this->mpCatModel->findByMpCatId($mpId, $mpCatId);
        if ($mpCat === false) { $this->error('Pazaryeri kategorisi bulunamadı'); }
        if ((int)($mpCat['is_leaf'] ?? 0) !== 1) {
            $this->error('Ara kategori secilemez. Lutfen en alt/final pazaryeri kategorisini secin.');
        }

        if ($catName === '') { $catName = $mpCat['name']; }

        // Zaten eşleşmiş mi kontrol et
        $existingMapping = $this->mappingModel->findByMarketplaceCategory($mpId, $mpCatId);
        if ($existingMapping !== false) {
            $this->success([
                'message' => "Bu kategori zaten eşleştirilmiş",
                'already_mapped' => true,
            ]);
        }

        // Sistem kategorisinde aynı isim var mı?
        $existingCat = $this->categoryModel->findBy(['name' => $catName]);

        if ($existingCat !== false) {
            // Mevcut sistem kategorisiyle eşleştir
            $sysCatId = (int)$existingCat['id'];
        } else {
            // Yeni sistem kategorisi oluştur
            $sysCatId = $this->categoryModel->create([
                'name'       => $catName,
                'slug'       => StringHelper::slugify($catName),
                'parent_id'  => null,
                'sort_order' => 0,
                'is_active'  => 1,
            ]);
            $this->categoryModel->updateFullPath($sysCatId);
        }

        // Eşleştirme kaydet
        $this->mappingModel->saveMapping(
            $sysCatId, $mpId, $mpCatId, $mpCat['name'], $mpCat['full_path'] ?? null
        );

        $this->success([
            'message'       => "'{$catName}' sisteme eklendi ve eşleştirildi",
            'category_id'   => $sysCatId,
            'is_new'        => ($existingCat === false),
        ]);
    }

    /**
     * Toplu: Birden fazla MP kategorisini sisteme ekle
     */
    public function bulkAddToSystem(Request $request): void
    {
        $items = $request->post('items', '');
        $mpId  = (int)$request->post('marketplace_id', 0);

        if ($mpId === 0) { $this->error('Pazaryeri belirtilmedi'); }

        // items: JSON array of mp_category_id's
        $itemIds = json_decode($items, true);
        if (!is_array($itemIds) || empty($itemIds)) {
            $this->error('Kategori seçilmedi');
        }

        $added = 0;
        $skipped = 0;
        $errors = [];

        foreach ($itemIds as $mpCatId) {
            $mpCatId = (string)$mpCatId;
            $mpCat = $this->mpCatModel->findByMpCatId($mpId, $mpCatId);
            if ($mpCat === false) { $errors[] = "MP #{$mpCatId} bulunamadı"; continue; }
            if ((int)($mpCat['is_leaf'] ?? 0) !== 1) {
                $errors[] = "MP #{$mpCatId} ara kategori oldugu icin atlandi";
                continue;
            }

            $existingMapping = $this->mappingModel->findByMarketplaceCategory($mpId, $mpCatId);
            if ($existingMapping !== false) { $skipped++; continue; }

            $catName = $mpCat['name'];
            $existingCat = $this->categoryModel->findBy(['name' => $catName]);

            if ($existingCat !== false) {
                $sysCatId = (int)$existingCat['id'];
            } else {
                $sysCatId = $this->categoryModel->create([
                    'name'       => $catName,
                    'slug'       => StringHelper::slugify($catName),
                    'parent_id'  => null,
                    'sort_order' => 0,
                    'is_active'  => 1,
                ]);
                $this->categoryModel->updateFullPath($sysCatId);
            }

            $this->mappingModel->saveMapping(
                $sysCatId, $mpId, $mpCatId, $mpCat['name'], $mpCat['full_path'] ?? null
            );
            $added++;
        }

        $this->success([
            'message' => "{$added} kategori eklendi, {$skipped} zaten eşleşik" . (!empty($errors) ? ', ' . count($errors) . ' hata' : ''),
            'added'   => $added,
            'skipped' => $skipped,
            'errors'  => $errors,
        ]);
    }
}
